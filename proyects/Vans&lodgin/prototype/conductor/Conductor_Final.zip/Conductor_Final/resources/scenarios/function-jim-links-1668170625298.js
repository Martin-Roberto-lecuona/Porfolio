(function(window, undefined) {

  var jimLinks = {
    "8ca64b53-2569-47b6-b107-7e6f907f5ea7" : {
    },
    "78660893-b1c8-4512-86e9-24740016471e" : {
      "Path_17" : [
        "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"
      ],
      "Path_31" : [
        "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"
      ],
      "Paragraph_4" : [
        "36f09d13-c869-41de-aad8-e2f742a2b2dc"
      ],
      "Path_6" : [
        "36f09d13-c869-41de-aad8-e2f742a2b2dc"
      ],
      "Paragraph_2" : [
        "9a82dd17-af12-48bc-9f77-4020dab258f3"
      ],
      "Path_2" : [
        "36f09d13-c869-41de-aad8-e2f742a2b2dc"
      ]
    },
    "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b" : {
      "Path_53" : [
        "03abe346-9c73-4c72-8cc6-974007b87579"
      ],
      "Paragraph_3" : [
        "dcaa4ef6-90d1-43b6-8f81-70459c373323"
      ],
      "Paragraph_4" : [
        "78660893-b1c8-4512-86e9-24740016471e"
      ],
      "Path_3" : [
        "78660893-b1c8-4512-86e9-24740016471e"
      ],
      "Path_4" : [
        "dcaa4ef6-90d1-43b6-8f81-70459c373323"
      ],
      "Paragraph_5" : [
        "cf4a22cb-2976-42a8-bb5b-c6de71aa7ee1"
      ],
      "Path_7" : [
        "cf4a22cb-2976-42a8-bb5b-c6de71aa7ee1"
      ]
    },
    "a2861469-1db5-4618-ad0b-860a323d5444" : {
      "Button_1" : [
        "8ca64b53-2569-47b6-b107-7e6f907f5ea7"
      ],
      "Paragraph_1" : [
        "b235d145-bd90-4ec5-b170-8930282c6f15"
      ]
    },
    "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3" : {
      "Button_7" : [
        "96864c05-2ce7-4f56-b85b-83cf39aa4a77",
        "2d9ea01b-9c01-41fe-8822-70505bf47b74"
      ],
      "Label_45" : [
        "2d9ea01b-9c01-41fe-8822-70505bf47b74",
        "96864c05-2ce7-4f56-b85b-83cf39aa4a77"
      ],
      "Path_17" : [
        "96864c05-2ce7-4f56-b85b-83cf39aa4a77",
        "2d9ea01b-9c01-41fe-8822-70505bf47b74"
      ]
    },
    "b235d145-bd90-4ec5-b170-8930282c6f15" : {
      "Paragraph_3" : [
        "a2861469-1db5-4618-ad0b-860a323d5444"
      ],
      "Path_1" : [
        "a2861469-1db5-4618-ad0b-860a323d5444"
      ]
    },
    "96864c05-2ce7-4f56-b85b-83cf39aa4a77" : {
      "Button_6" : [
        "2d9ea01b-9c01-41fe-8822-70505bf47b74"
      ],
      "Paragraph_2" : [
        "2b129e08-adce-485e-bfd6-475c5309a495"
      ],
      "Paragraph_3" : [
        "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"
      ],
      "Path_18" : [
        "2b129e08-adce-485e-bfd6-475c5309a495"
      ],
      "Path_4" : [
        "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"
      ]
    },
    "2d9ea01b-9c01-41fe-8822-70505bf47b74" : {
      "Paragraph_2" : [
        "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"
      ],
      "Path_18" : [
        "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"
      ],
      "Paragraph_3" : [
        "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"
      ]
    },
    "03abe346-9c73-4c72-8cc6-974007b87579" : {
      "Path_4" : [
        "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"
      ]
    },
    "9a82dd17-af12-48bc-9f77-4020dab258f3" : {
      "Path_38" : [
        "78660893-b1c8-4512-86e9-24740016471e"
      ],
      "Path_39" : [
        "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"
      ]
    },
    "dcaa4ef6-90d1-43b6-8f81-70459c373323" : {
      "Path_4" : [
        "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"
      ]
    },
    "36f09d13-c869-41de-aad8-e2f742a2b2dc" : {
      "Path_38" : [
        "78660893-b1c8-4512-86e9-24740016471e"
      ],
      "Path_39" : [
        "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"
      ],
      "Button_6" : [
        "96864c05-2ce7-4f56-b85b-83cf39aa4a77"
      ]
    },
    "2b129e08-adce-485e-bfd6-475c5309a495" : {
      "Button_7" : [
        "96864c05-2ce7-4f56-b85b-83cf39aa4a77"
      ],
      "Label_45" : [
        "96864c05-2ce7-4f56-b85b-83cf39aa4a77"
      ],
      "Path_17" : [
        "96864c05-2ce7-4f56-b85b-83cf39aa4a77"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);