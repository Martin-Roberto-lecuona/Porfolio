	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Image_1", "8ca64b53-2569-47b6-b107-7e6f907f5ea7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "8ca64b53-2569-47b6-b107-7e6f907f5ea7"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rect_8", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Path_17", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Chevron left", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_31", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_31", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Home", "s-Path_31"]; 

	widgets.descriptionMap[["s-Text_16", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Title Button", "s-Text_16"]; 

	widgets.descriptionMap[["s-Path_85", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Path_86", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_86", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Union_9", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Union_9", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Rectangle_11", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Label_36", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Label_36", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Button", "s-Label_36"]; 

	widgets.descriptionMap[["s-Label_37", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Label_37", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Button", "s-Label_37"]; 

	widgets.descriptionMap[["s-Path_9", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-e928a6ab", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-e928a6ab", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_43", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_43", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-a87a9f93", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-a87a9f93", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_44", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_44", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-56bf26d0", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-56bf26d0", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_45", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_45", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-33f15c9a", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-33f15c9a", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_46", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_46", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-335936af", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-335936af", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_47", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_47", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-df4a2612", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-df4a2612", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_48", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_48", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-4449685f", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-4449685f", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_49", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_49", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-c7cee015", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-c7cee015", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_50", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_50", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-9effc9aa", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-9effc9aa", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_51", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_51", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-cbaab1bb", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-cbaab1bb", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_52", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_52", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-a892f5ce", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-a892f5ce", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_53", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_53", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-6143dea2", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-6143dea2", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_54", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_54", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-51b09f7e", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-51b09f7e", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_55", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_55", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-c6b520d1", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-c6b520d1", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_56", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_56", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-b10b136c", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-b10b136c", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_57", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_57", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-c27d773b", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-c27d773b", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_58", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_58", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-a6cea022", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-a6cea022", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_59", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_59", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-e6a909f1", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-e6a909f1", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_60", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_60", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-b4f6bb54", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-b4f6bb54", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_61", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_61", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-95c3e00f", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-95c3e00f", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_62", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_62", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-ea0798d0", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-ea0798d0", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_63", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_63", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-acff9b5f", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-acff9b5f", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_64", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_64", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-00a5b347", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-00a5b347", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_65", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_65", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-bed305df", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-bed305df", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_66", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_66", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-289ff268", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-289ff268", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_67", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_67", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-00e0031b", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-00e0031b", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_68", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_68", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-c15e4b18", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-c15e4b18", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_69", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_69", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-91a713de", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-91a713de", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_70", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_70", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-988bebb7", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-988bebb7", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_71", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_71", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-353ca0a1", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-353ca0a1", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_72", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_72", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-87229b81", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-87229b81", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_73", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_73", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-7ae69cab", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-7ae69cab", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_74", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_74", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-7d58e5e5", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-7d58e5e5", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_75", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_75", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-0039da30", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-0039da30", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_76", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_76", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-1faf3b63", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-1faf3b63", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_77", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_77", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-b984a9c7", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-b984a9c7", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_78", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_78", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-882997f1", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-882997f1", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_79", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_79", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-f5196927", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-f5196927", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_80", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_80", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-9b9109ea", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-9b9109ea", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_81", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_81", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-f999e870", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-f999e870", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_82", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_82", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-2ceab1ff", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-2ceab1ff", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_83", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_83", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-5c1a3542", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-5c1a3542", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Text_cell_84", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_84", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Path_11", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Path_16", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Paragraph_24", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_24", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Date picker", "s-Group_19"]; 

	widgets.descriptionMap[["s-Path_18", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Chevron right", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_6", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Chevron right", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_2", "78660893-b1c8-4512-86e9-24740016471e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "78660893-b1c8-4512-86e9-24740016471e"]] = ["Chevron right", "s-Path_2"]; 

	widgets.descriptionMap[["s-Rectangle_13", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Image_19", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Image", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_6", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Settings", "s-Path_6"]; 

	widgets.descriptionMap[["s-Text_16", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Title Button", "s-Text_16"]; 

	widgets.descriptionMap[["s-Path_85", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Path_86", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_86", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Union_9", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Union_9", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Path_1", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Menu", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_53", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_53", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Person circle", "s-Path_53"]; 

	widgets.descriptionMap[["s-Input_1", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Toggle", "s-Input_1"]; 

	widgets.descriptionMap[["s-Input_2", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Toggle", "s-Input_2"]; 

	widgets.descriptionMap[["s-Category_1", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Select list", "s-Category_1"]; 

	widgets.descriptionMap[["s-Category_2", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Select list", "s-Category_2"]; 

	widgets.descriptionMap[["s-Category_3", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Category_3", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Select list", "s-Category_3"]; 

	widgets.descriptionMap[["s-Category_4", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Category_4", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Select list", "s-Category_4"]; 

	widgets.descriptionMap[["s-Path_5", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Settings", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_10", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Bus", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_8", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Circle path", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_3", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Chevron right", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Chevron right", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_9", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Menu", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_7", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Chevron right", "s-Path_7"]; 

	widgets.descriptionMap[["s-Rect_8", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "fdaa7f8d-b5d9-4a89-8665-8147440a5d8b"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Image", "a2861469-1db5-4618-ad0b-860a323d5444"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "a2861469-1db5-4618-ad0b-860a323d5444"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Button_1", "a2861469-1db5-4618-ad0b-860a323d5444"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "a2861469-1db5-4618-ad0b-860a323d5444"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Image_2", "a2861469-1db5-4618-ad0b-860a323d5444"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "a2861469-1db5-4618-ad0b-860a323d5444"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Button_7", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Small", "s-Button_7"]; 

	widgets.descriptionMap[["s-Text_16", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Title Button", "s-Text_16"]; 

	widgets.descriptionMap[["s-Path_85", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Path_86", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_86", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Union_9", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Union_9", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Category_3", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Category_3", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Select list", "s-Category_3"]; 

	widgets.descriptionMap[["s-Button_6", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Small", "s-Button_6"]; 

	widgets.descriptionMap[["s-Rectangle_8", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Alert single", "s-Group_16"]; 

	widgets.descriptionMap[["s-Label_45", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Label_45", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Button", "s-Label_45"]; 

	widgets.descriptionMap[["s-Paragraph_18", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Alert single", "s-Group_16"]; 

	widgets.descriptionMap[["s-Paragraph_19", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Alert single", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_17", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Chevron left", "s-Path_17"]; 

	widgets.descriptionMap[["s-Rect_8", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "05947f0d-e1f6-474e-bc8c-d0d1d43b46f3"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Image", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Button_1", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Image_2", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Rectangle_2", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ["Alert single", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ["Button", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ["Alert single", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_1", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "b235d145-bd90-4ec5-b170-8930282c6f15"]] = ["Chevron left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_1", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Menu", "s-Path_1"]; 

	widgets.descriptionMap[["s-Text_16", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Title Button", "s-Text_16"]; 

	widgets.descriptionMap[["s-Path_85", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Path_86", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_86", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Union_9", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Union_9", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Rect_8", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Rectangle_13", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Image_19", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Path_24", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_24", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map pin", "s-Group_11"]; 

	widgets.descriptionMap[["s-Path_25", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map pin", "s-Group_11"]; 

	widgets.descriptionMap[["s-Path_26", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_26", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map pin", "s-Group_12"]; 

	widgets.descriptionMap[["s-Path_27", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_27", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map pin", "s-Group_12"]; 

	widgets.descriptionMap[["s-Path_9", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Path_10", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Path_11", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Image", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_6", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Path_7", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Image_1", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_4", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Image", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_2", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_3", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Rectangle_3", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Paragraph_37", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_37", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Paragraph_39", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_39", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Ellipse_19", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_19", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Ellipse_20", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_20", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Line_6", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Line_6", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Map 4", "s-Map-4"]; 

	widgets.descriptionMap[["s-Input_2", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Check", "s-Input_2"]; 

	widgets.descriptionMap[["s-Input_1", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Check", "s-Input_1"]; 

	widgets.descriptionMap[["s-Button_6", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Small", "s-Button_6"]; 

	widgets.descriptionMap[["s-Path_18", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Chevron right", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_4", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Chevron right", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "96864c05-2ce7-4f56-b85b-83cf39aa4a77"]] = ["Menu", "s-Path_5"]; 

	widgets.descriptionMap[["s-Rectangle_1", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Map 4", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_1", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Map 4", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_2", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_3", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Image", "s-Image_4"]; 

	widgets.descriptionMap[["s-Path_24", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Path_24", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Map pin", "s-Group_11"]; 

	widgets.descriptionMap[["s-Path_25", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Map pin", "s-Group_11"]; 

	widgets.descriptionMap[["s-Path_1", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Menu", "s-Path_1"]; 

	widgets.descriptionMap[["s-Text_16", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Title Button", "s-Text_16"]; 

	widgets.descriptionMap[["s-Path_85", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Path_86", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Path_86", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Union_9", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Union_9", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Path_18", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Chevron right", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_3", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Menu", "s-Path_3"]; 

	widgets.descriptionMap[["s-Rect_8", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Button_6", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Small", "s-Button_6"]; 

	widgets.descriptionMap[["s-Image_5", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Image", "s-Image_5"]; 

	widgets.descriptionMap[["s-Rectangle_3", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Alert single", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Button", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Alert single", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "2d9ea01b-9c01-41fe-8822-70505bf47b74"]] = ["Alert single", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rect_8", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Paragraph_1", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Path_1", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Status bar", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_2", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Status bar", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_3", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Status bar", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_4", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Chevron left", "s-Path_4"]; 

	widgets.descriptionMap[["s-Rectangle_5", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-List-item-4_9"]; 

	widgets.descriptionMap[["s-Input_1", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-List-item-4_9"]; 

	widgets.descriptionMap[["s-Rich_text_45", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Rich_text_45", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-List-item-4_9"]; 

	widgets.descriptionMap[["s-Path_17", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-List-item-4_9"]; 

	widgets.descriptionMap[["s-Rectangle_1", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_3"]; 

	widgets.descriptionMap[["s-Input_2", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_3"]; 

	widgets.descriptionMap[["s-Paragraph_3", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_3"]; 

	widgets.descriptionMap[["s-Path_5", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_3", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_4"]; 

	widgets.descriptionMap[["s-Input_3", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_4", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_6", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_4", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_5"]; 

	widgets.descriptionMap[["s-Input_4", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_5", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_7", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_101", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_101", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Edit", "s-Path_101"]; 

	widgets.descriptionMap[["s-Path_99", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_99", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Done", "s-Path_99"]; 

	widgets.descriptionMap[["s-Rectangle_6", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_5", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Input_5", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_6"]; 

	widgets.descriptionMap[["s-Paragraph_6", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_6"]; 

	widgets.descriptionMap[["s-Path_8", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_7", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_7"]; 

	widgets.descriptionMap[["s-Input_6", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Input_6", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_7", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_7"]; 

	widgets.descriptionMap[["s-Path_9", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_7"]; 

	widgets.descriptionMap[["s-Path_11", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Edit", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_12", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Done", "s-Path_12"]; 

	widgets.descriptionMap[["s-Rectangle_8", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_8"]; 

	widgets.descriptionMap[["s-Input_7", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Input_7", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_8"]; 

	widgets.descriptionMap[["s-Paragraph_8", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_8"]; 

	widgets.descriptionMap[["s-Path_10", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_8"]; 

	widgets.descriptionMap[["s-Path_13", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Edit", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Done", "s-Path_14"]; 

	widgets.descriptionMap[["s-Rectangle_9", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_9"]; 

	widgets.descriptionMap[["s-Path_33", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_33", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Star", "s-Path_33"]; 

	widgets.descriptionMap[["s-Path_16", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Star", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_18", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Star", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_19", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Star", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_20", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Star", "s-Path_20"]; 

	widgets.descriptionMap[["s-Paragraph_9", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_9"]; 

	widgets.descriptionMap[["s-Path_15", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Table row single", "s-Group_9"]; 

	widgets.descriptionMap[["s-Path_53", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ""; 

			widgets.rootWidgetMap[["s-Path_53", "03abe346-9c73-4c72-8cc6-974007b87579"]] = ["Person circle", "s-Path_53"]; 

	widgets.descriptionMap[["s-Path_38", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_38", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ["Chevron left", "s-Path_38"]; 

	widgets.descriptionMap[["s-Path_39", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_39", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ["Home", "s-Path_39"]; 

	widgets.descriptionMap[["s-Text_16", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ["Title Button", "s-Text_16"]; 

	widgets.descriptionMap[["s-Path_85", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Path_86", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_86", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Union_9", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ""; 

			widgets.rootWidgetMap[["s-Union_9", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Rect_8", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Image_1", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Button_1", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "9a82dd17-af12-48bc-9f77-4020dab258f3"]] = ["Small", "s-Button_1"]; 

	widgets.descriptionMap[["s-Rect_8", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Paragraph_1", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Path_1", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ["Status bar", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_2", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ["Status bar", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_3", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ["Status bar", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_12", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ["Calendar", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_15", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ["Chevron down", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_4", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "dcaa4ef6-90d1-43b6-8f81-70459c373323"]] = ["Chevron left", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_38", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_38", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ["Chevron left", "s-Path_38"]; 

	widgets.descriptionMap[["s-Path_39", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_39", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ["Home", "s-Path_39"]; 

	widgets.descriptionMap[["s-Text_16", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ["Title Button", "s-Text_16"]; 

	widgets.descriptionMap[["s-Path_85", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Path_86", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_86", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Union_9", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ""; 

			widgets.rootWidgetMap[["s-Union_9", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Rect_8", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Image_1", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Button_6", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "36f09d13-c869-41de-aad8-e2f742a2b2dc"]] = ["Small", "s-Button_6"]; 

	widgets.descriptionMap[["s-Image_1", "cf4a22cb-2976-42a8-bb5b-c6de71aa7ee1"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "cf4a22cb-2976-42a8-bb5b-c6de71aa7ee1"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Category_2", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Select list", "s-Category_2"]; 

	widgets.descriptionMap[["s-Button_7", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Small", "s-Button_7"]; 

	widgets.descriptionMap[["s-Text_16", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Title Button", "s-Text_16"]; 

	widgets.descriptionMap[["s-Path_85", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Path_86", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Path_86", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Union_9", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Union_9", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Status bar", "s-statusBar_8"]; 

	widgets.descriptionMap[["s-Category_3", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Category_3", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Select list", "s-Category_3"]; 

	widgets.descriptionMap[["s-Button_6", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Small", "s-Button_6"]; 

	widgets.descriptionMap[["s-Rectangle_8", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Alert single", "s-Group_16"]; 

	widgets.descriptionMap[["s-Label_45", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Label_45", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Button", "s-Label_45"]; 

	widgets.descriptionMap[["s-Paragraph_18", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Alert single", "s-Group_16"]; 

	widgets.descriptionMap[["s-Paragraph_19", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Alert single", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_17", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Chevron left", "s-Path_17"]; 

	widgets.descriptionMap[["s-Rect_8", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "2b129e08-adce-485e-bfd6-475c5309a495"]] = ["Home indicator", "s-Rect_8"]; 

	