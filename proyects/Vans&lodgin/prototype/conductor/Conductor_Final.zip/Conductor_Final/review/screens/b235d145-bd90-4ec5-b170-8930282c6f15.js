var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668170625298.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-b235d145-bd90-4ec5-b170-8930282c6f15" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="recuperar" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/b235d145-bd90-4ec5-b170-8930282c6f15-1668170625298.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="433.0px" datasizeheight="926.0px" dataX="-4.5" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/74375e8a-d55d-4af3-9d06-2e2732d90db8.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="428.5px" datasizeheight="926.0px" datasizewidthpx="428.50000000000017" datasizeheightpx="925.9999999999998" dataX="-0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="email text firer click commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="69.4" dataY="493.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="email"  value="" maxlength="100"  tabindex="-1" placeholder="Ingresar correo electronico..."/></div></div>  </div></div></div>\
      <div id="s-Button_1" class="button multiline manualfit firer click ie-background commentable non-processed" customid="Button Filled"   datasizewidth="300.0px" datasizeheight="50.0px" dataX="69.4" dataY="559.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Recuperar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Recuperaci&oacute;n de token"   datasizewidth="198.1px" datasizeheight="20.0px" dataX="112.5" dataY="433.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Recuperaci&oacute;n de token</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Conductor"   datasizewidth="121.1px" datasizeheight="42.0px" dataX="151.5" dataY="300.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Conductor</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="210.9px" datasizeheight="212.0px" dataX="106.6" dataY="142.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/652447fb-befc-4431-808e-cec99669956f.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable hidden non-processed" customid="Pop-up viaje finalizado" datasizewidth="360.4px" datasizeheight="191.0px" dataX="31.8" dataY="418.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel 2"  datasizewidth="360.4px" datasizeheight="191.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Alert Single Actions" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Base"   datasizewidth="269.0px" datasizeheight="130.0px" datasizewidthpx="269.0" datasizeheightpx="130.0" dataX="51.0" dataY="32.5" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_2_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_3" class="richtext manualfit firer click ie-background commentable non-processed" customid="Ok"   datasizewidth="270.0px" datasizeheight="45.0px" dataX="50.0" dataY="117.5" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_3_0">OK</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Nuevo token enviado."   datasizewidth="226.0px" datasizeheight="26.0px" dataX="72.0" dataY="63.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_4_0">Nuevo token enviado.</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Volver"   datasizewidth="13.0px" datasizeheight="19.6px" dataX="33.0" dataY="60.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="12.970000267028809" height="19.59000015258789" viewBox="32.999999999999986 60.0 12.970000267028809 19.59000015258789" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-b235d" d="M32.999999999999986 69.7950002995562 C32.999999999999986 70.18147810871201 33.165144089929655 70.51279923591306 33.520827601671684 70.79989268915612 L43.40394396239999 79.21457940888986 C43.68332845107243 79.45744758462448 44.03902712502955 79.59 44.458318885815764 79.59 C45.2966157036848 79.59 45.969999999999985 79.01581309351386 45.969999999999985 78.27590211751514 C45.969999999999985 77.91153634800116 45.792078297903984 77.5912724388458 45.512693809231536 77.33722242969093 L36.60766851106451 69.7950002995562 L45.512693809231536 62.25274102445403 C45.792078297903984 61.998753922098814 45.969999999999985 61.66747113808996 45.969999999999985 61.31410027893437 C45.969999999999985 60.57422644790308 45.2966157036848 60.0 44.458318885815764 60.0 C44.03902712502955 60.0 43.68332845107243 60.13251586952048 43.40394396239999 60.37545893430233 L33.520827601671684 68.77905189013534 C33.165144089929655 69.07720256142409 32.999999999999986 69.40852249040037 32.999999999999986 69.7950002995562 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-b235d" fill="#666666" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;