var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668170625298.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-dcaa4ef6-90d1-43b6-8f81-70459c373323" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Historial_de_Viajes" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/dcaa4ef6-90d1-43b6-8f81-70459c373323-1668170625298.css" />\
      <div class="freeLayout">\
      <div id="s-Rect_8" class="path firer commentable non-processed" customid="Home Indicator"   datasizewidth="135.0px" datasizeheight="5.0px" dataX="146.5" dataY="900.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="135.0" height="5.0" viewBox="146.49999999999997 900.0 135.0 5.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Rect_8-dcaa4" d="M148.99999999999997 900.0 L279.0 900.0 C280.3714594258871 900.0 281.5 901.1285405741129 281.5 902.5 L281.5 902.5 C281.5 903.8714594258871 280.3714594258871 905.0 279.0 905.0 L148.99999999999997 905.0 C147.62854057411283 905.0 146.49999999999997 903.8714594258871 146.49999999999997 902.5 L146.49999999999997 902.5 C146.49999999999997 901.1285405741129 147.62854057411283 900.0 148.99999999999997 900.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Rect_8-dcaa4" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="479.0px" datasizeheight="138.6px" datasizewidthpx="479.0" datasizeheightpx="138.59571825934205" dataX="-27.0" dataY="-18.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Status Bar" datasizewidth="984.0px" datasizeheight="22.0px" >\
        <div id="s-Paragraph_1" class="richtext manualfit firer pageload ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Clock"   datasizewidth="50.0px" datasizeheight="20.0px" dataX="11.0" dataY="13.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">4:02</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_1" class="path firer commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Signal Icon"   datasizewidth="17.0px" datasizeheight="10.7px" dataX="335.0" dataY="18.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="17.0" height="10.66670036315918" viewBox="335.0 18.0 17.0 10.66670036315918" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-dcaa4" d="M351.0 18.0 L350.0 18.0 C349.447021484375 18.0 349.0 18.44770050048828 349.0 19.0 L349.0 27.66670036315918 C349.0 28.2189998626709 349.447021484375 28.66670036315918 350.0 28.66670036315918 L351.0 28.66670036315918 C351.552001953125 28.66670036315918 352.0 28.2189998626709 352.0 27.66670036315918 L352.0 19.0 C352.0 18.44770050048828 351.552001953125 18.0 351.0 18.0 Z M345.3330078125 20.33340072631836 L346.3330078125 20.33340072631836 C346.885009765625 20.33340072631836 347.3330078125 20.78110122680664 347.3330078125 21.33340072631836 L347.3330078125 27.66670036315918 C347.3330078125 28.2189998626709 346.885009765625 28.66670036315918 346.3330078125 28.66670036315918 L345.3330078125 28.66670036315918 C344.781005859375 28.66670036315918 344.3330078125 28.2189998626709 344.3330078125 27.66670036315918 L344.3330078125 21.33340072631836 C344.3330078125 20.78110122680664 344.781005859375 20.33340072631836 345.3330078125 20.33340072631836 Z M341.666015625 22.66670036315918 L340.666015625 22.66670036315918 C340.114013671875 22.66670036315918 339.666015625 23.11440086364746 339.666015625 23.66670036315918 L339.666015625 27.66670036315918 C339.666015625 28.2189998626709 340.114013671875 28.66670036315918 340.666015625 28.66670036315918 L341.666015625 28.66670036315918 C342.218017578125 28.66670036315918 342.666015625 28.2189998626709 342.666015625 27.66670036315918 L342.666015625 23.66670036315918 C342.666015625 23.11440086364746 342.218017578125 22.66670036315918 341.666015625 22.66670036315918 Z M337.0 24.66670036315918 L336.0 24.66670036315918 C335.447021484375 24.66670036315918 335.0 25.11440086364746 335.0 25.66670036315918 L335.0 27.66670036315918 C335.0 28.2189998626709 335.447021484375 28.66670036315918 336.0 28.66670036315918 L337.0 28.66670036315918 C337.552001953125 28.66670036315918 338.0 28.2189998626709 338.0 27.66670036315918 L338.0 25.66670036315918 C338.0 25.11440086364746 337.552001953125 24.66670036315918 337.0 24.66670036315918 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-dcaa4" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_2" class="path firer commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Wifi Icon"   datasizewidth="15.3px" datasizeheight="11.0px" dataX="360.0" dataY="18.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="15.27301025390625" height="10.965625762939453" viewBox="360.0 17.999999523162842 15.27301025390625 10.965625762939453" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_2-dcaa4" d="M367.6369934082031 20.277324199676514 C369.8529968261719 20.277425289154053 371.9840087890625 21.12892484664917 373.5899963378906 22.65562391281128 C373.71099853515625 22.77352476119995 373.90399169921875 22.772023677825928 374.02301025390625 22.652324199676514 L375.17901611328125 21.485623836517334 C375.2400207519531 21.42492437362671 375.27301025390625 21.34272527694702 375.27301025390625 21.257123470306396 C375.2720031738281 21.171523571014404 375.2380065917969 21.089725017547607 375.177001953125 21.029624462127686 C370.9620056152344 16.99012517929077 364.31201171875 16.99012517929077 360.0970153808594 21.029624462127686 C360.0360107421875 21.08962392807007 360.0010070800781 21.171424388885498 360.0 21.25702428817749 C360.0 21.342624187469482 360.03302001953125 21.42492437362671 360.093994140625 21.485623836517334 L361.25 22.652324199676514 C361.3690185546875 22.772223949432373 361.56201171875 22.773725032806396 361.6830139160156 22.65562391281128 C363.28900146484375 21.12882375717163 365.4210205078125 20.277324199676514 367.6369934082031 20.277324199676514 Z M367.6369934082031 24.0730242729187 C368.85400390625 24.072925090789795 370.02801513671875 24.525424480438232 370.9309997558594 25.342624187469482 C371.0530090332031 25.458625316619873 371.2449951171875 25.456124782562256 371.364013671875 25.337024211883545 L372.5190124511719 24.170323848724365 C372.58001708984375 24.109124660491943 372.614013671875 24.026124477386475 372.6130065917969 23.93982458114624 C372.61199951171875 23.853623867034912 372.5760192871094 23.771323680877686 372.5140075683594 23.711324214935303 C369.7660217285156 21.154923915863037 365.510009765625 21.154923915863037 362.7619934082031 23.711324214935303 C362.70001220703125 23.771323680877686 362.66400146484375 23.853623867034912 362.66400146484375 23.939923763275146 C362.6629943847656 24.02622365951538 362.697021484375 24.10922384262085 362.75799560546875 24.170323848724365 L363.9120178222656 25.337024211883545 C364.031005859375 25.456124782562256 364.2229919433594 25.458625316619873 364.3450012207031 25.342624187469482 C365.24700927734375 24.52602529525757 366.4200134277344 24.073523998260498 367.6369934082031 24.0730242729187 Z M369.95001220703125 26.626824855804443 C369.9519958496094 26.713325023651123 369.9179992675781 26.79672384262085 369.85601806640625 26.85732412338257 L367.8590087890625 28.873023509979248 C367.8000183105469 28.932223796844482 367.7200012207031 28.965625286102295 367.6369934082031 28.965625286102295 C367.55401611328125 28.965625286102295 367.4739990234375 28.932223796844482 367.4150085449219 28.873023509979248 L365.4179992675781 26.85732412338257 C365.35601806640625 26.79672384262085 365.322021484375 26.713223934173584 365.3240051269531 26.626723766326904 C365.3260192871094 26.540223598480225 365.3630065917969 26.45832395553589 365.427001953125 26.400325298309326 C366.7030029296875 25.32142400741577 368.5710144042969 25.32142400741577 369.8470153808594 26.400325298309326 C369.9110107421875 26.458425045013428 369.947998046875 26.540324687957764 369.95001220703125 26.626824855804443 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-dcaa4" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_3" class="path firer commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Battery Icon"   datasizewidth="23.8px" datasizeheight="11.3px" dataX="383.0" dataY="18.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="23.8280029296875" height="11.33331298828125" viewBox="383.0 18.0 23.8280029296875 11.33331298828125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_3-dcaa4" d="M405.5 21.5 L405.5 25.5 C406.30499267578125 25.16119384765625 406.8280029296875 24.37310791015625 406.8280029296875 23.5 C406.8280029296875 22.626800537109375 406.30499267578125 21.838714599609375 405.5 21.5 Z M386.3330078125 20.0 C385.59698486328125 20.0 385.0 20.596899032592773 385.0 21.33329963684082 L385.0 25.8125 C385.0 26.54889678955078 385.59698486328125 27.145797729492188 386.3330078125 27.145797729492188 L399.1669921875 27.145797729492188 C399.90301513671875 27.145797729492188 400.5 26.54889678955078 400.5 25.8125 L400.5 21.33329963684082 C400.5 20.596899032592773 399.90301513671875 20.0 399.1669921875 20.0 Z M402.3330078125 19.0 C403.25390625 19.0 404.0 19.7462158203125 404.0 20.666595458984375 L404.0 26.666595458984375 C404.0 27.587127685546875 403.25390625 28.33331298828125 402.3330078125 28.33331298828125 L385.6669921875 28.33331298828125 C384.74609375 28.33331298828125 384.0 27.587127685546875 384.0 26.666595458984375 L384.0 20.666595458984375 C384.0 19.7462158203125 384.74609375 19.0 385.6669921875 19.0 Z M385.6669921875 18.0 C384.19390869140625 18.0 383.0 19.19378662109375 383.0 20.666595458984375 L383.0 26.666595458984375 C383.0 28.139495849609375 384.19390869140625 29.33331298828125 385.6669921875 29.33331298828125 L402.3330078125 29.33331298828125 C403.80609130859375 29.33331298828125 405.0 28.139495849609375 405.0 26.666595458984375 L405.0 20.666595458984375 C405.0 19.19378662109375 403.80609130859375 18.0 402.3330078125 18.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-dcaa4" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Dynamic_Panel_2" class="dynamicpanel firer commentable non-processed" customid="Historial" datasizewidth="428.0px" datasizeheight="802.5px" dataX="-0.0" dataY="120.0" >\
        <div id="s-Panel_2" class="panel default firer commentable non-processed" customid="historial"  datasizewidth="428.0px" datasizeheight="802.5px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="rectNoViajes"   datasizewidth="370.0px" datasizeheight="220.5px" datasizewidthpx="370.0" datasizeheightpx="220.5" dataX="28.6" dataY="118.7" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_1_0">No tienes viajes realizados esta fecha.</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Data_grid_1" summary="" class="datagrid horizontal firer commentable non-processed" customid="gridHistorial" items="1" size="0" childWidth="362.0" childHeight="232.00000000000009" hSpacing="5" vSpacing="5" datamaster="Viaje" datasizewidth="372.0px" datasizeheight="1427.0px" dataX="28.1" dataY="100.7" originalwidth="372.0px" originalheight="1427.0000000000005px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                  	<div class="paddingLayer">\
                      <table >\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Input_7" class="date firer change pageload commentable non-processed" customid="desplegableFecha" value="1666742400000" format="dd/MM/yyyy"  datasizewidth="244.0px" datasizeheight="45.0px" dataX="92.0" dataY="33.7" ><div class="backgroundLayer">\
                  <div class="colorLayer"></div>\
                  <div class="imageLayer"></div>\
                </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date"  tabindex="-1"  /></div></div></div></div></div>\
                <div id="s-Path_12" class="path firer commentable non-processed" customid="iconoCalendario"   datasizewidth="32.0px" datasizeheight="30.0px" dataX="107.3" dataY="41.0"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="32.0" height="30.000001907348633" viewBox="107.25 41.01471471799522 32.0 30.000001907348633" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_12-dcaa4" d="M112.4209275668945 71.01471471799522 L134.06335366928153 71.01471471799522 C137.47390759363907 71.01471471799522 139.25 69.21692116543372 139.25 65.78186471540448 L139.25 46.24745586557953 C139.25 42.81247169527457 137.47390759363907 41.01471471799522 134.06335366928153 41.01471471799522 L112.4209275668945 41.01471471799522 C109.02603783324145 41.01471471799522 107.25 42.796418629765185 107.25 46.24745586557953 L107.25 65.78186471540448 C107.25 69.21692116543372 109.02603783324145 71.01471471799522 112.4209275668945 71.01471471799522 Z M112.40520880307052 67.8203619415612 C111.100678458724 67.8203619415612 110.37770656225507 67.13021075066565 110.37770656225507 65.71776043753334 L110.37770656225507 50.950429305393385 C110.37770656225507 49.53798247562128 111.100678458724 48.8477563924813 112.40520880307052 48.8477563924813 L134.07909119261532 48.8477563924813 C135.38362068425687 48.8477563924813 136.1066121929406 49.53798247562128 136.1066121929406 50.950429305393385 L136.1066121929406 65.71776043753334 C136.1066121929406 67.13021075066565 135.38362068425687 67.8203619415612 134.07909119261532 67.8203619415612 L112.40520880307052 67.8203619415612 Z M120.21656210638172 54.38548749710272 L121.14394870707673 54.38548749710272 C121.70975087211069 54.38548749710272 121.89823278355979 54.20888635969854 121.89823278355979 53.647121375915745 L121.89823278355979 52.700009669343565 C121.89823278355979 52.12217420325037 121.70975087211069 51.94575420057689 121.14394870707673 51.94575420057689 L120.21656210638172 51.94575420057689 C119.65075823593777 51.94575420057689 119.46209725644033 52.12217420325037 119.46209725644033 52.700009669343565 L119.46209725644033 53.647121375915745 C119.46209725644033 54.20888635969854 119.65075823593777 54.38548749710272 120.21656210638172 54.38548749710272 Z M125.35599757250877 54.38548749710272 L126.28338417320379 54.38548749710272 C126.8334522257239 54.38548749710272 127.02211149981136 54.20888635969854 127.02211149981136 53.647121375915745 L127.02211149981136 52.700009669343565 C127.02211149981136 52.12217420325037 126.8334522257239 51.94575420057689 126.28338417320379 51.94575420057689 L125.35599757250877 51.94575420057689 C124.79019540747481 51.94575420057689 124.60171349602572 52.12217420325037 124.60171349602572 52.700009669343565 L124.60171349602572 53.647121375915745 C124.60171349602572 54.20888635969854 124.79019540747481 54.38548749710272 125.35599757250877 54.38548749710272 Z M130.47987458335035 54.38548749710272 L131.407085526817 54.38548749710272 C131.97288598644099 54.38548749710272 132.16154867134838 54.20888635969854 132.16154867134838 53.647121375915745 L132.16154867134838 52.700009669343565 C132.16154867134838 52.12217420325037 131.97288598644099 51.94575420057689 131.407085526817 51.94575420057689 L130.47987458335035 51.94575420057689 C129.9298082362402 51.94575420057689 129.74114896215278 52.12217420325037 129.74114896215278 52.700009669343565 L129.74114896215278 53.647121375915745 C129.74114896215278 54.20888635969854 129.9298082362402 54.38548749710272 130.47987458335035 54.38548749710272 Z M115.09282664456882 59.55405382877174 L116.00440580012068 59.55405382877174 C116.57013633793531 59.55405382877174 116.75879731743274 59.37745094968744 116.75879731743274 58.79961548359425 L116.75879731743274 57.85250551870217 C116.75879731743274 57.29074053491939 116.57013633793531 57.114137655835094 116.00440580012068 57.114137655835094 L115.09282664456882 57.114137655835094 C114.52700572002503 57.114137655835094 114.33839760823712 57.29074053491939 114.33839760823712 57.85250551870217 L114.33839760823712 58.79961548359425 C114.33839760823712 59.37745094968744 114.52700572002503 59.55405382877174 115.09282664456882 59.55405382877174 Z M120.21656210638172 59.55405382877174 L121.14394870707673 59.55405382877174 C121.70975087211069 59.55405382877174 121.89823278355979 59.37745094968744 121.89823278355979 58.79961548359425 L121.89823278355979 57.85250551870217 C121.89823278355979 57.29074053491939 121.70975087211069 57.114137655835094 121.14394870707673 57.114137655835094 L120.21656210638172 57.114137655835094 C119.65075823593777 57.114137655835094 119.46209725644033 57.29074053491939 119.46209725644033 57.85250551870217 L119.46209725644033 58.79961548359425 C119.46209725644033 59.37745094968744 119.65075823593777 59.55405382877174 120.21656210638172 59.55405382877174 Z M125.35599757250877 59.55405382877174 L126.28338417320379 59.55405382877174 C126.8334522257239 59.55405382877174 127.02211149981136 59.37745094968744 127.02211149981136 58.79961548359425 L127.02211149981136 57.85250551870217 C127.02211149981136 57.29074053491939 126.8334522257239 57.114137655835094 126.28338417320379 57.114137655835094 L125.35599757250877 57.114137655835094 C124.79019540747481 57.114137655835094 124.60171349602572 57.29074053491939 124.60171349602572 57.85250551870217 L124.60171349602572 58.79961548359425 C124.60171349602572 59.37745094968744 124.79019540747481 59.55405382877174 125.35599757250877 59.55405382877174 Z M130.47987458335035 59.55405382877174 L131.407085526817 59.55405382877174 C131.97288598644099 59.55405382877174 132.16154867134838 59.37745094968744 132.16154867134838 58.79961548359425 L132.16154867134838 57.85250551870217 C132.16154867134838 57.29074053491939 131.97288598644099 57.114137655835094 131.407085526817 57.114137655835094 L130.47987458335035 57.114137655835094 C129.9298082362402 57.114137655835094 129.74114896215278 57.29074053491939 129.74114896215278 57.85250551870217 L129.74114896215278 58.79961548359425 C129.74114896215278 59.37745094968744 129.9298082362402 59.55405382877174 130.47987458335035 59.55405382877174 Z M115.09282664456882 64.70654793645024 L116.00440580012068 64.70654793645024 C116.57013633793531 64.70654793645024 116.75879731743274 64.52994505736595 116.75879731743274 63.96818007358317 L116.75879731743274 63.021071850371186 C116.75879731743274 62.443234642597886 116.57013633793531 62.266631763513594 116.00440580012068 62.266631763513594 L115.09282664456882 62.266631763513594 C114.52700572002503 62.266631763513594 114.33839760823712 62.443234642597886 114.33839760823712 63.021071850371186 L114.33839760823712 63.96818007358317 C114.33839760823712 64.52994505736595 114.52700572002503 64.70654793645024 115.09282664456882 64.70654793645024 Z M120.21656210638172 64.70654793645024 L121.14394870707673 64.70654793645024 C121.70975087211069 64.70654793645024 121.89823278355979 64.52994505736595 121.89823278355979 63.96818007358317 L121.89823278355979 63.021071850371186 C121.89823278355979 62.443234642597886 121.70975087211069 62.266631763513594 121.14394870707673 62.266631763513594 L120.21656210638172 62.266631763513594 C119.65075823593777 62.266631763513594 119.46209725644033 62.443234642597886 119.46209725644033 63.021071850371186 L119.46209725644033 63.96818007358317 C119.46209725644033 64.52994505736595 119.65075823593777 64.70654793645024 120.21656210638172 64.70654793645024 Z M125.35599757250877 64.70654793645024 L126.28338417320379 64.70654793645024 C126.8334522257239 64.70654793645024 127.02211149981136 64.52994505736595 127.02211149981136 63.96818007358317 L127.02211149981136 63.021071850371186 C127.02211149981136 62.443234642597886 126.8334522257239 62.266631763513594 126.28338417320379 62.266631763513594 L125.35599757250877 62.266631763513594 C124.79019540747481 62.266631763513594 124.60171349602572 62.443234642597886 124.60171349602572 63.021071850371186 L124.60171349602572 63.96818007358317 C124.60171349602572 64.52994505736595 124.79019540747481 64.70654793645024 125.35599757250877 64.70654793645024 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_12-dcaa4" fill="#666666" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Path_15" class="path firer click commentable non-processed" customid="iconoDesplegable"   datasizewidth="16.0px" datasizeheight="8.0px" dataX="297.3" dataY="53.7"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="7.999999046325684" viewBox="297.25 53.73689436925588 16.0 7.999999046325684" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_15-dcaa4" d="M305.2499997553395 61.73689436925588 C305.56565287265806 61.72905640398419 305.8543170035208 61.62725798463627 306.08879960395586 61.40807524837482 L312.9433777901807 55.31805947030781 C313.14173676061887 55.14590112820564 313.25 54.926717542576476 313.25 54.668435862302054 C313.25 54.15176548142115 312.78103479912994 53.73689436925588 312.18574845844785 53.73689436925588 C311.8970843275851 53.73689436925588 311.61755092569587 53.838657115159776 311.41005731171657 54.018697589654806 L305.25902968419683 59.505963815789826 L299.0899103931006 54.018697589654806 C298.8824681578213 53.8464857373866 298.6118952012141 53.73689436925588 298.31426181729216 53.73689436925588 C297.71899504944815 53.73689436925588 297.25 54.15176548142115 297.25 54.668435862302054 C297.25 54.926717542576476 297.3582309441983 55.14590112820564 297.55665352636026 55.31805947030781 L304.4202298355805 61.40807524837482 C304.6637433435148 61.62725798463627 304.934346638021 61.73689436925588 305.2499997553395 61.73689436925588 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-dcaa4" fill="#666666" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_4" class="path firer click commentable non-processed" customid="Volver"   datasizewidth="13.0px" datasizeheight="19.6px" dataX="33.0" dataY="60.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="12.970000267028809" height="19.59000015258789" viewBox="32.999999999999986 60.0 12.970000267028809 19.59000015258789" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-dcaa4" d="M32.999999999999986 69.7950002995562 C32.999999999999986 70.18147810871201 33.165144089929655 70.51279923591306 33.520827601671684 70.79989268915612 L43.40394396239999 79.21457940888986 C43.68332845107243 79.45744758462448 44.03902712502955 79.59 44.458318885815764 79.59 C45.2966157036848 79.59 45.969999999999985 79.01581309351386 45.969999999999985 78.27590211751514 C45.969999999999985 77.91153634800116 45.792078297903984 77.5912724388458 45.512693809231536 77.33722242969093 L36.60766851106451 69.7950002995562 L45.512693809231536 62.25274102445403 C45.792078297903984 61.998753922098814 45.969999999999985 61.66747113808996 45.969999999999985 61.31410027893437 C45.969999999999985 60.57422644790308 45.2966157036848 60.0 44.458318885815764 60.0 C44.03902712502955 60.0 43.68332845107243 60.13251586952048 43.40394396239999 60.37545893430233 L33.520827601671684 68.77905189013534 C33.165144089929655 69.07720256142409 32.999999999999986 69.40852249040037 32.999999999999986 69.7950002995562 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-dcaa4" fill="#666666" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Historial de viajes reali"   datasizewidth="261.7px" datasizeheight="33.0px" dataX="83.2" dataY="91.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Historial de viajes realizados</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      <!-- START DATA VIEW TEMPLATES -->\
      <script type="text/x-jquery-tmpl" id="s-Data_grid_1-template">\
        <![CDATA[\
        <td>\
          <div id="s-Grid_cell_1" class="gridcell firer commentable non-processed " instance="{{=it.id}}" customid="" originalwidth="360.0px" originalheight="230.00000000000009px" >\
            <div class="cellContainerChild">\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="layout scrollable">\
                  <div class="paddingLayer">\
                    <div class="freeLayout">\
                    <div id="s-Dynamic_Panel_3" class="dynamicpanel firer commentable non-processed" customid="panelDirecciones" datasizewidth="375.0px" datasizeheight="102.0px" dataX="-0.0" dataY="128.0" >\
                      <div id="s-Panel_3" class="panel default firer commentable non-processed" customid="Panel 2"  datasizewidth="375.0px" datasizeheight="102.0px" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <div class="borderLayer">\
                        	<div class="layoutWrapper scrollable">\
                        	  <div class="paddingLayer">\
                              <div class="freeLayout">\
                              <div id="s-Input_4" class="textarea firer commentable non-processed" customid="datoDestino"  datasizewidth="175.9px" datasizeheight="74.0px" dataX="185.9" dataY="28.0" ><div class="backgroundLayer">\
                                <div class="colorLayer"></div>\
                                <div class="imageLayer"></div>\
                              </div><div class="borderLayer"><div class="paddingLayer"><textarea name="e546c6fb-9c0e-4831-afcf-d46286ad3c60" readonly="readonly" tabindex="-1" placeholder="">{{!it.userdata["e546c6fb-9c0e-4831-afcf-d46286ad3c60"]}}</textarea></div></div></div>\
                              <div id="s-Input_3" class="textarea firer commentable non-processed" customid="datoParada"  datasizewidth="186.9px" datasizeheight="74.0px" dataX="0.0" dataY="28.0" ><div class="backgroundLayer">\
                                <div class="colorLayer"></div>\
                                <div class="imageLayer"></div>\
                              </div><div class="borderLayer"><div class="paddingLayer"><textarea name="5050d035-eb22-4af5-bf34-7bc6fc621b8e" readonly="readonly" tabindex="-1" placeholder="">{{!it.userdata["5050d035-eb22-4af5-bf34-7bc6fc621b8e"]}}</textarea></div></div></div>\
                              <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Destino"   datasizewidth="76.3px" datasizeheight="18.0px" dataX="182.0" dataY="5.0" >\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                                  <div class="paddingLayer">\
                                    <div class="content">\
                                      <div class="valign">\
                                        <span id="rtr-s-Paragraph_6_0">Destino</span>\
                                      </div>\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                              <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Puntos de Partida"   datasizewidth="169.0px" datasizeheight="36.0px" dataX="-3.0" dataY="5.0" >\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                                  <div class="paddingLayer">\
                                    <div class="content">\
                                      <div class="valign">\
                                        <span id="rtr-s-Paragraph_5_0">Puntos de Partida</span>\
                                      </div>\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                              </div>\
\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Input_8" class="text firer ie-background commentable non-processed" customid="datoAusentes"  datasizewidth="80.5px" datasizeheight="20.0px" dataX="281.7" dataY="68.8" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="3513c4a1-ec25-4a91-980d-d1190fc88813" value="{{!it.userdata["3513c4a1-ec25-4a91-980d-d1190fc88813"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Paragraph_9" class="richtext autofit firer ie-background commentable non-processed" customid="Ausentes"   datasizewidth="77.4px" datasizeheight="18.0px" dataX="192.6" dataY="68.8" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Paragraph_9_0">Ausentes:</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Input_5" class="text firer ie-background commentable non-processed" customid="datoCantPasajeros"  datasizewidth="78.2px" datasizeheight="20.0px" dataX="281.8" dataY="42.0" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="7d8f8894-d171-4569-b944-9296c9a3ebcd" value="{{!it.userdata["7d8f8894-d171-4569-b944-9296c9a3ebcd"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="Pasajeros"   datasizewidth="80.9px" datasizeheight="18.0px" dataX="191.8" dataY="41.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Paragraph_7_0">Pasajeros:</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Input_10" class="text firer ie-background commentable non-processed" customid="datoAveria"  datasizewidth="97.0px" datasizeheight="20.0px" dataX="79.7" dataY="99.3" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="5cc13e2a-d2ad-4f66-bb91-f5aa888b501f" value="{{!it.userdata["5cc13e2a-d2ad-4f66-bb91-f5aa888b501f"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Paragraph_10" class="richtext autofit firer ie-background commentable non-processed" customid="Averias"   datasizewidth="63.1px" datasizeheight="18.0px" dataX="10.3" dataY="99.3" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Paragraph_10_0">Averias:</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Input_9" class="text firer ie-background commentable non-processed" customid="datoKilometro"  datasizewidth="77.7px" datasizeheight="20.0px" dataX="95.1" dataY="68.8" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="5aaae552-9c95-46cb-b36a-a86966c7fd02" value="{{!it.userdata["5aaae552-9c95-46cb-b36a-a86966c7fd02"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="distancia"   datasizewidth="76.5px" datasizeheight="18.0px" dataX="11.2" dataY="68.8" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Paragraph_4_0">Distancia:</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Input_6" class="text firer ie-background commentable non-processed" customid="datoDuracion"  datasizewidth="110.0px" datasizeheight="20.0px" dataX="89.0" dataY="40.0" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="b908c647-b2c5-4956-94de-aeef4e17bf05" value="{{!it.userdata["b908c647-b2c5-4956-94de-aeef4e17bf05"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Paragraph_8" class="richtext autofit firer ie-background commentable non-processed" customid="Duraci&oacute;n:"   datasizewidth="74.7px" datasizeheight="18.0px" dataX="10.0" dataY="41.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Paragraph_8_0">Duraci&oacute;n:</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Dynamic_Panel_4" class="dynamicpanel firer commentable non-processed" customid="titulo" datasizewidth="361.5px" datasizeheight="32.0px" dataX="0.0" dataY="-1.0" >\
                      <div id="s-Panel_4" class="panel default firer commentable non-processed" customid="Panel 4"  datasizewidth="361.5px" datasizeheight="32.0px" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <div class="borderLayer">\
                        	<div class="layoutWrapper scrollable">\
                        	  <div class="paddingLayer">\
                              <div class="freeLayout">\
                              <div id="s-Input_2" class="date firer ie-background commentable non-processed" customid="datoFecha" value="{{!it.userdata["cde77159-5296-45dc-a380-df54e4d84c32"]}}" format="dd/MM/yyyy"  datasizewidth="85.6px" datasizeheight="20.0px" dataX="267.0" dataY="6.0" ><div class="backgroundLayer">\
                                <div class="colorLayer"></div>\
                                <div class="imageLayer"></div>\
                              </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date" name="cde77159-5296-45dc-a380-df54e4d84c32" tabindex="-1" readonly="readonly" /></div></div></div></div></div>\
                              <div id="s-Input_1" class="text firer ie-background commentable non-processed" customid="datoViaje"  datasizewidth="100.0px" datasizeheight="20.0px" dataX="118.0" dataY="6.0" ><div class="backgroundLayer">\
                                <div class="colorLayer"></div>\
                                <div class="imageLayer"></div>\
                              </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="b10f7a7c-2dcc-4b35-9a7b-2faa711d4acc" value="{{!it.userdata["b10f7a7c-2dcc-4b35-9a7b-2faa711d4acc"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                              <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Viaje"   datasizewidth="107.5px" datasizeheight="36.0px" dataX="13.0" dataY="6.0" >\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                                  <div class="paddingLayer">\
                                    <div class="content">\
                                      <div class="valign">\
                                        <span id="rtr-s-Paragraph_3_0">Nro de Viaje:</span>\
                                      </div>\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                              </div>\
\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    </div>\
\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div> \
        </td>\
        ]]>\
      </script>\
      <!-- END DATA VIEW TEMPLATES -->\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;