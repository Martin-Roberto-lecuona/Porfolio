var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-3df00100-9f44-4710-9231-36acf193c3c0" class="screen growth-none devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="gestion_tarjetas_detalle" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/3df00100-9f44-4710-9231-36acf193c3c0-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Tarjeta"   datasizewidth="69.4px" datasizeheight="23.0px" dataX="69.0" dataY="70.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Tarjeta</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Chevron left"   datasizewidth="19.0px" datasizeheight="33.0px" dataX="37.0" dataY="65.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.973670959472656" height="32.966854095458984" viewBox="37.0 65.03314766987339 18.973670959472656 32.966854095458984" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-3df00" d="M37.0 81.51657433904222 C37.0 82.16695498545933 37.24158746844515 82.72451571411108 37.76191295636316 83.20764830614837 L52.21981491915155 97.36822689184217 C52.628523407417525 97.77693538010814 53.14887107597283 98.00000000000027 53.762248370136895 98.00000000000027 C54.98858354277821 98.00000000000027 55.97367000579834 97.0337348159257 55.97367000579834 95.78858239718195 C55.97367000579834 95.17541279443974 55.7133903093882 94.63645960404699 55.30468182112223 94.2089338696786 L42.277618490304405 81.51657433904222 L55.30468182112223 68.82415229933713 C55.7133903093882 68.39673242710124 55.97367000579834 67.83923622393976 55.97367000579834 67.24456930553484 C55.97367000579834 65.99947939585982 54.98858354277821 65.03314766987339 53.762248370136895 65.03314766987339 C53.14887107597283 65.03314766987339 52.628523407417525 65.25615078890759 52.21981491915155 65.66498530352176 L37.76191295636316 79.80689485009864 C37.24158746844515 80.30863498039494 37.0 80.86619369262512 37.0 81.51657433904222 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-3df00" fill="#007EFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer ie-background commentable non-processed" customid="Path 1"   datasizewidth="384.2px" datasizeheight="3.0px" dataX="21.9" dataY="114.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="384.2122802734375" height="2.0" viewBox="21.89386676224156 114.0 384.2122802734375 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-3df00" d="M22.89386676224156 115.0 L405.1061332377579 115.0 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-3df00" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="square"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 11"   datasizewidth="351.5px" datasizeheight="200.9px" datasizewidthpx="351.49634872989554" datasizeheightpx="200.89601720353036" dataX="38.3" dataY="134.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="TITULAR"   datasizewidth="59.9px" datasizeheight="16.0px" dataX="52.8" dataY="285.7" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">TITULAR</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="text firer pageload ie-background commentable non-processed" customid="Input 4"  datasizewidth="191.8px" datasizeheight="20.1px" dataX="52.9" dataY="301.7" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="648cb4e9-c62e-4901-8378-f898826a129c" value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_3" class="text firer pageload ie-background commentable non-processed" customid="Input 5"  datasizewidth="310.0px" datasizeheight="40.2px" dataX="52.9" dataY="209.3" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="d37548b0-1358-438f-98dd-ae3a61d4cf85" value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="V&Aacute;LIDA HASTA"   datasizewidth="104.2px" datasizeheight="16.0px" dataX="266.6" dataY="285.7" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">V&Aacute;LIDA HASTA</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="text firer pageload ie-background commentable non-processed" customid="Input 3"  datasizewidth="308.4px" datasizeheight="30.1px" dataX="52.9" dataY="147.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="a6b4109c-cfc6-485b-8043-12ed989c2179" value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_4" class="date firer pageload ie-background commentable non-processed" customid="Input 6" value="" format="MM/yy"  datasizewidth="110.5px" datasizeheight="20.1px" dataX="261.8" dataY="301.7" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date" name="f61007c0-0e15-44b4-8602-197083513ade" tabindex="-1" readonly="readonly" /></div></div></div></div></div>\
      <div id="s-Input_5" class="text firer ie-background commentable non-processed" customid="Input 5"  datasizewidth="310.0px" datasizeheight="40.2px" dataX="52.9" dataY="388.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="d37548b0-1358-438f-98dd-ae3a61d4cf85" value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Eliminar" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 5"   datasizewidth="401.1px" datasizeheight="49.5px" datasizewidthpx="401.14574395361626" datasizeheightpx="49.49703979492176" dataX="13.8" dataY="811.9" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Eliminar tarjeta"   datasizewidth="146.7px" datasizeheight="25.0px" dataX="161.0" dataY="824.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_2_0">Eliminar tarjeta</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_16" class="path firer commentable non-processed" customid="Trash"   datasizewidth="25.4px" datasizeheight="29.0px" dataX="121.0" dataY="822.5"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="25.367189407348633" height="29.00031089782715" viewBox="121.0 822.4998447419533 25.367189407348633 29.00031089782715" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_16-3df00" d="M127.79110866025187 851.500155258046 L139.58894903756814 851.500155258046 C141.56592408789265 851.500155258046 142.8368258744475 850.3062291947481 142.93951031917436 848.3292541444235 L143.79967989871628 829.842986765635 L145.21182364030835 829.842986765635 C145.86648224708543 829.842986765635 146.36718940734863 829.3294698197932 146.36718940734863 828.6875924426352 C146.36718940734863 828.0457143689903 145.85363067229773 827.5578754991984 145.21182364030835 827.5578754991984 L139.51182844505283 827.5578754991984 L139.51182844505283 825.6322280450141 C139.51182844505283 823.6552390649532 138.25378101923297 822.4998447419533 136.10985529240122 822.4998447419533 L131.2316128567147 822.4998447419533 C129.0876885228566 822.4998447419533 127.82962577432673 823.6552390649532 127.82962577432673 825.6322280450141 L127.82962577432673 827.5578754991984 L122.15537969677665 827.5578754991984 C121.51350231961857 827.5578754991984 121.0 828.0585534070152 121.0 828.6875924426352 C121.0 829.3423088578182 121.51350231961857 829.842986765635 122.15537969677665 829.842986765635 L123.5675255278292 829.842986765635 L124.42765192518831 848.3292541444235 C124.53034890667794 850.3190807695357 125.78844160414104 851.500155258046 127.79110866025187 851.500155258046 Z M130.2301999291619 825.7477793872387 C130.2301999291619 825.0930476493456 130.69234540019383 824.6694039696786 131.39841866396353 824.6694039696786 L135.94304948515241 824.6694039696786 C136.6491227489221 824.6694039696786 137.11126961292766 825.0930476493456 137.11126961292766 825.7477793872387 L137.11126961292766 827.5578754991984 L130.2301999291619 827.5578754991984 L130.2301999291619 825.7477793872387 Z M128.04785877533092 849.2021304294948 C127.34178690453487 849.2021304294948 126.8282838884295 848.6758622029672 126.78976677435463 847.9183770681523 L125.92965569970553 829.842986765635 L141.39897341138544 829.842986765635 L140.56450976736622 847.9183770681523 C140.53894870110193 848.6887165637022 140.03824154083873 849.2021304294948 139.30646234154636 849.2021304294948 L128.04785877533092 849.2021304294948 Z M129.89644344540588 847.1353280811256 C130.44856526266173 847.1353280811256 130.7951747141791 846.7887172366346 130.7823203534441 846.2751585015837 L130.3971506056691 832.8469943146695 C130.38429763790776 832.3334773688276 130.02483382565543 831.9997069553352 129.49856559912794 831.9997069553352 C128.95929814260705 831.9997069553352 128.61268869108972 832.3463164068526 128.62554165885106 832.8597748478015 L129.0107127995997 846.2880100763714 C129.02356576736105 846.8015715973696 129.38302957961338 847.1353280811256 129.89644344540588 847.1353280811256 Z M133.68358773880612 847.1353280811256 C134.22270893309496 847.1353280811256 134.59502571310864 846.8015715973696 134.59502571310864 846.2880100763714 L134.59502571310864 832.8597748478015 C134.59502571310864 832.3463164068526 134.22270893309496 831.9997069553352 133.68358773880612 831.9997069553352 C133.1444665445173 831.9997069553352 132.78500273226496 832.3463164068526 132.78500273226496 832.8597748478015 L132.78500273226496 846.2880100763714 C132.78500273226496 846.8015715973696 133.1444665445173 847.1353280811256 133.68358773880612 847.1353280811256 Z M137.47073203220637 847.1481824418606 C137.98414589799887 847.1481824418606 138.34360831727759 846.8015715973696 138.35646267801255 846.2880100763714 L138.7416338187612 832.8597748478015 C138.75448817949618 832.3463164068526 138.4078773350052 832.0125459933602 137.8686098784843 832.0125459933602 C137.34234165195681 832.0125459933602 136.98287923267813 832.3463164068526 136.97002487194314 832.8597748478015 L136.58485512416814 846.2880100763714 C136.57200076343315 846.7887172366346 136.91861021495052 847.1481824418606 137.47073203220637 847.1481824418606 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-3df00" fill="#FFFFFF" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="403.1px" datasizeheight="49.5px" dataX="12.2" dataY="811.9"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;