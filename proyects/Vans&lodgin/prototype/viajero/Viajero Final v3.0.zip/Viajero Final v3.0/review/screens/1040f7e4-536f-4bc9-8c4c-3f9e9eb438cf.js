var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-1040f7e4-536f-4bc9-8c4c-3f9e9eb438cf" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="puntos_origen" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/1040f7e4-536f-4bc9-8c4c-3f9e9eb438cf-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="428.0px" datasizeheight="926.0px" datasizewidthpx="427.9999999999998" datasizeheightpx="925.9999999999993" dataX="0.0" dataY="-0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Puntos de origen"   datasizewidth="164.6px" datasizeheight="23.0px" dataX="69.0" dataY="70.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Puntos de origen</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Data_grid_1" summary="" class="datagrid horizontal firer ie-background commentable non-processed" customid="puntos_origen_mult 1" items="1" size="0" childWidth="374.3281250000005" childHeight="86.5" hSpacing="5" vSpacing="5" datamaster="puntos_origen_matias" datasizewidth="384.3px" datasizeheight="279.5px" dataX="21.8" dataY="131.8" originalwidth="384.3281250000005px" originalheight="279.5px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
        	<div class="paddingLayer">\
            <table >\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_17" class="path firer click commentable non-processed" customid="Chevron left"   datasizewidth="19.0px" datasizeheight="33.0px" dataX="37.0" dataY="65.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.973670959472656" height="32.966854095458984" viewBox="37.0 65.03314766987339 18.973670959472656 32.966854095458984" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_17-1040f" d="M37.0 81.51657433904222 C37.0 82.16695498545933 37.24158746844515 82.72451571411108 37.76191295636316 83.20764830614837 L52.21981491915155 97.36822689184217 C52.628523407417525 97.77693538010814 53.14887107597283 98.00000000000027 53.762248370136895 98.00000000000027 C54.98858354277821 98.00000000000027 55.97367000579834 97.0337348159257 55.97367000579834 95.78858239718195 C55.97367000579834 95.17541279443974 55.7133903093882 94.63645960404699 55.30468182112223 94.2089338696786 L42.277618490304405 81.51657433904222 L55.30468182112223 68.82415229933713 C55.7133903093882 68.39673242710124 55.97367000579834 67.83923622393976 55.97367000579834 67.24456930553484 C55.97367000579834 65.99947939585982 54.98858354277821 65.03314766987339 53.762248370136895 65.03314766987339 C53.14887107597283 65.03314766987339 52.628523407417525 65.25615078890759 52.21981491915155 65.66498530352176 L37.76191295636316 79.80689485009864 C37.24158746844515 80.30863498039494 37.0 80.86619369262512 37.0 81.51657433904222 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-1040f" fill="#007EFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer ie-background commentable non-processed" customid="Path 1"   datasizewidth="384.2px" datasizeheight="3.0px" dataX="21.9" dataY="114.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="384.2122802734375" height="2.0" viewBox="21.89386676224156 114.0 384.2122802734375 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-1040f" d="M22.89386676224156 115.0 L405.1061332377579 115.0 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-1040f" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="square"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      <!-- START DATA VIEW TEMPLATES -->\
      <script type="text/x-jquery-tmpl" id="s-Data_grid_1-template">\
        <![CDATA[\
        <td>\
          <div id="s-Grid_cell_1" class="gridcell firer ie-background commentable non-processed " instance="{{=it.id}}" customid="" originalwidth="374.3281250000005px" originalheight="86.5px" >\
            <div class="cellContainerChild">\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="layout scrollable">\
                  <div class="paddingLayer">\
                    <div class="freeLayout">\
                    <div id="s-Rectangle_7" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="374.3px" datasizeheight="87.0px" datasizewidthpx="374.32812500000057" datasizeheightpx="86.99999999999994" dataX="0.0" dataY="0.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_7_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Input_3" class="text firer ie-background commentable non-processed" customid="Input 3"  datasizewidth="292.0px" datasizeheight="35.0px" dataX="68.0" dataY="43.2" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="2c314900-1779-4da9-b5c7-f3cc749f5acb" value="{{!it.userdata["2c314900-1779-4da9-b5c7-f3cc749f5acb"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Input_4" class="text firer ie-background commentable non-processed" customid="Input 4"  datasizewidth="292.0px" datasizeheight="20.0px" dataX="68.0" dataY="16.0" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="ff73da1b-c9eb-4fd2-8d48-faced3d5993d" value="{{!it.userdata["ff73da1b-c9eb-4fd2-8d48-faced3d5993d"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Input_1" class="inputIOS checkbox firer commentable non-processed {{? jimData.isTrue(it.userdata["3dec400e-0fd2-4c8c-bf2c-ce335de32877"]) }}checked{{??}}unchecked{{?}}" customid="Input 1"  datasizewidth="34.7px" datasizeheight="34.7px" dataX="16.0" dataY="26.0"  name="3dec400e-0fd2-4c8c-bf2c-ce335de32877" value="{{!it.userdata["3dec400e-0fd2-4c8c-bf2c-ce335de32877"]}}"  {{? jimData.isTrue(it.userdata["3dec400e-0fd2-4c8c-bf2c-ce335de32877"]) }}checked="checked"{{?}} tabindex="-1">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                    </div>\
                    </div>\
\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div> \
        </td>\
        ]]>\
      </script>\
      <!-- END DATA VIEW TEMPLATES -->\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;