var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-0f3b92ae-5567-40ad-a1ab-bceaf748bb7d" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="menu" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/0f3b92ae-5567-40ad-a1ab-bceaf748bb7d-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Group 7" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 8"   datasizewidth="236.8px" datasizeheight="943.0px" datasizewidthpx="236.82858276367233" datasizeheightpx="943.0000000000008" dataX="-0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_1" class="path firer click commentable non-processed" customid="Menu"   datasizewidth="27.0px" datasizeheight="18.0px" dataX="15.0" dataY="75.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="27.0" height="18.0" viewBox="14.999999999998181 75.50000000000023 27.0 18.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-0f3b9" d="M14.999999999998181 93.50000000000023 L41.99999999999818 93.50000000000023 L41.99999999999818 90.50000000000023 L14.999999999998181 90.50000000000023 L14.999999999998181 93.50000000000023 Z M14.999999999998181 86.00000000000023 L41.99999999999818 86.00000000000023 L41.99999999999818 83.00000000000023 L14.999999999998181 83.00000000000023 L14.999999999998181 86.00000000000023 Z M14.999999999998181 75.50000000000023 L14.999999999998181 78.50000000000023 L41.99999999999818 78.50000000000023 L41.99999999999818 75.50000000000023 L14.999999999998181 75.50000000000023 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-0f3b9" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_1" class="richtext manualfit firer click ie-background commentable non-processed" customid="Inicio"   datasizewidth="156.8px" datasizeheight="24.0px" dataX="42.0" dataY="120.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_1_0">Inicio</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_2" class="path firer click commentable non-processed" customid="Home"   datasizewidth="22.0px" datasizeheight="19.2px" dataX="13.2" dataY="122.4"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="19.201934814453125" viewBox="13.171417236327954 122.39903298858196 22.0 19.201934814453125" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_2-0f3b9" d="M13.171417236327954 131.46512758166895 C13.171417236327954 131.93162288405324 13.531186290149545 132.3352523130636 14.106820680034637 132.3352523130636 C14.385642611692592 132.3352523130636 14.637478753496772 132.18278174201555 14.862339352844865 132.0033679586098 L15.887685181999775 131.14222462242654 L15.887685181999775 139.48413339941777 C15.887685181999775 140.81156764992784 16.688180171232958 141.600966884831 18.064310038322553 141.600966884831 L30.23354762993743 141.600966884831 C31.60074371812856 141.600966884831 32.41021396382228 140.81156764992784 32.41021396382228 139.48413339941777 L32.41021396382228 131.09742178695123 L33.489540156168474 132.0033679586098 C33.70536596655518 132.18278174201555 33.95721186778572 132.3352523130636 34.23607381309179 132.3352523130636 C34.76668211347945 132.3352523130636 35.171417236326306 132.0033679586098 35.171417236326306 131.48308939881528 C35.171417236326306 131.1781482567192 35.054550057439116 130.93596982069178 34.82061270359624 130.73859519341616 L32.41021396382228 128.71146762642937 L32.41021396382228 124.89036962893677 C32.41021396382228 124.48672998052352 32.14936206393813 124.2355818286023 31.744626941091273 124.2355818286023 L30.50340552847517 124.2355818286023 C30.10767640428191 124.2355818286023 29.837818505744163 124.48672998052352 29.837818505744163 124.89036962893677 L29.837818505744163 126.55874165157037 L25.45757324381846 122.89012395789045 C24.67512001814289 122.23533615755599 23.68574548269998 122.23533615755599 22.903189783047537 122.89012395789045 L13.531186290149545 130.73859519341616 C13.288335164232269 130.93596982069178 13.171417236327954 131.20509049580045 13.171417236327954 131.46512758166895 Z M26.761731245204953 133.9407886338937 C26.761731245204953 133.519197387737 26.49197484470145 133.25017890665708 26.06922967643267 133.25017890665708 L22.291635824410207 133.25017890665708 C21.86888968019879 133.25017890665708 21.59002675895008 133.519197387737 21.59002675895008 133.9407886338937 L21.59002675895008 139.81601678059513 L18.54100629150351 139.81601678059513 C17.983352668761235 139.81601678059513 17.67755519464719 139.50199302253537 17.67755519464719 138.93691260054203 L17.67755519464719 129.64435701044565 L23.784703138256855 124.53158342637497 C24.036550015430045 124.31630781173203 24.324315485412832 124.31630781173203 24.576162362586018 124.53158342637497 L30.61136820674301 129.5904715590067 L30.61136820674301 138.93691260054203 C30.61136820674301 139.50199302253537 30.30549021736142 139.81601678059513 29.74786587289825 139.81601678059513 L26.761731245204953 139.81601678059513 L26.761731245204953 133.9407886338937 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-0f3b9" fill="#007EFF" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group 24" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Favoritos"   datasizewidth="152.8px" datasizeheight="24.0px" dataX="46.0" dataY="235.9" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_2_0">Favoritos</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_3" class="path firer commentable non-processed" customid="Favorites"   datasizewidth="22.0px" datasizeheight="19.2px" dataX="13.2" dataY="238.3"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="19.200000762939453" viewBox="13.171417236327954 238.29054870605458 22.0 19.200000762939453" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_3-0f3b9" d="M13.171417236327954 244.69399906756132 C13.171417236327954 249.06878138473655 17.073596330630018 253.39238858927925 23.138770399585006 257.08068533574743 C23.47577608165799 257.285617020901 23.888839416117044 257.4905487060546 24.171429915158775 257.4905487060546 C24.454019234774382 257.4905487060546 24.867083748659564 257.285617020901 25.204088251306423 257.08068533574743 C31.280207394681725 253.39238858927925 35.171417236327954 249.06878138473655 35.171417236327954 244.69399906756132 C35.171417236327954 240.91338967956068 32.39968564658672 238.29054870605458 28.84535764727057 238.29054870605458 C26.769279891030127 238.29054870605458 25.14967306827517 239.18189481280027 24.171429915158775 240.53430163658402 C23.21495189171398 239.19214139705792 21.584462504123223 238.29054870605458 19.50838474788278 238.29054870605458 C15.94316179975654 238.29054870605458 13.171417236327954 240.91338967956068 13.171417236327954 244.69399906756132 Z M15.410556551186989 244.68374136625445 C15.410556551186989 242.1018633839757 17.21490337441211 240.3498870216016 19.63885758330011 240.3498870216016 C21.595346248385148 240.3498870216016 22.693180851509197 241.46664630911454 23.377950940748065 242.43996508992166 C23.682307748887517 242.8600272411749 23.888839416117044 242.9932206077706 24.171429915158775 242.9932206077706 C24.464902979036307 242.9932206077706 24.64966833716811 242.84978065691723 24.96490771014337 242.43996508992166 C25.70409416183961 241.48712724887577 26.758396146768206 240.3498870216016 28.704001067591317 240.3498870216016 C31.13885081500247 240.3498870216016 32.94322181646311 242.1018633839757 32.94322181646311 244.68374136625445 C32.94322181646311 248.29008878446453 28.964949097278225 252.28589978767977 24.377961582388306 255.15458763425522 C24.28013644147838 255.21602044819463 24.214961353928103 255.25705347683203 24.171429915158775 255.25705347683203 C24.128021136706224 255.25705347683203 24.062722209413046 255.21602044819463 23.975780812765045 255.15458763425522 C19.38879329787513 252.28589978767977 15.410556551186989 248.29008878446453 15.410556551186989 244.68374136625445 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-0f3b9" fill="#007EFF" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Group 25" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Perfil"   datasizewidth="152.8px" datasizeheight="24.0px" dataX="46.0" dataY="274.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_3_0">Perfil</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_4" class="path firer commentable non-processed" customid="Person"   datasizewidth="20.8px" datasizeheight="19.2px" dataX="13.2" dataY="276.4"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="20.828582763671875" height="19.19999885559082" viewBox="13.171417236328125 276.40000000000015 20.828582763671875 19.19999885559082" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_4-0f3b9" d="M23.591623404395637 286.0462683028776 C26.457242576226346 286.0462683028776 28.778028155715628 283.8478271035696 28.778028155715628 281.1563295918399 C28.778028155715628 278.50592855911464 26.457242576226346 276.40000000000015 23.591623404395637 276.40000000000015 C20.7378607867834 276.40000000000015 18.393362098857175 278.536750500364 18.405218653075647 281.1768775526728 C18.417073922448626 283.8581133454361 20.726005517410417 286.0462683028776 23.591623404395637 286.0462683028776 Z M23.591623404395637 284.2485000783614 C21.957533777929417 284.2485000783614 20.572147839196965 282.9027167675011 20.572147839196965 281.1768775526728 C20.56029256982399 279.4921231127376 21.945678508556437 278.19774481629366 23.591623404395637 278.19774481629366 C25.24942485445331 278.19774481629366 26.61109768474881 279.4715874133547 26.61109768474881 281.1563295918399 C26.61109768474881 282.88214539844546 25.237568300234837 284.2485000783614 23.591623404395637 284.2485000783614 Z M16.202748070899773 295.6000000000002 L30.9686691654284 295.6000000000002 C33.017175427214816 295.6000000000002 34.00000000000005 295.03499015499057 34.00000000000005 293.8228031445396 C34.00000000000005 290.99775614884595 29.938420945460265 287.23788394427294 23.591623404395637 287.23788394427294 C17.24477061497476 287.23788394427294 13.171417236328125 290.99775614884595 13.171417236328125 293.8228031445396 C13.171417236328125 295.03499015499057 14.154241809113351 295.6000000000002 16.202748070899773 295.6000000000002 Z M15.835674137496355 293.80223289016124 C15.551497150519218 293.80223289016124 15.444915362256861 293.7200633403751 15.444915362256861 293.53515621577884 C15.444915362256861 291.9634389686474 18.36965027526572 289.03565216878917 23.591623404395637 289.03565216878917 C28.80174126415257 289.03565216878917 31.72650187407131 291.9634389686474 31.72650187407131 293.53515621577884 C31.72650187407131 293.7200633403751 31.61993421910939 293.80223289016124 31.335662153565696 293.80223289016124 L15.835674137496355 293.80223289016124 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-0f3b9" fill="#007EFF" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Group 23" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_4" class="richtext manualfit firer click ie-background commentable non-processed" customid="Historial"   datasizewidth="152.8px" datasizeheight="24.0px" dataX="46.0" dataY="197.4" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_4_0">Historial</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_5" class="path firer click commentable non-processed" customid="Clock"   datasizewidth="22.0px" datasizeheight="19.2px" dataX="13.2" dataY="199.8"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="19.200000762939453" viewBox="13.171417236328125 199.79350891113253 22.0 19.200000762939453" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_5-0f3b9" d="M24.166082489311087 218.99350891113326 C30.195079839807914 218.99350891113326 35.171417236328125 214.64842334442756 35.171417236328125 209.39350286664865 C35.171417236328125 204.13857332214334 30.184432844301405 199.79350891113253 24.15543549380458 199.79350891113253 C18.137095522750062 199.79350891113253 13.171417236328125 204.13857332214334 13.171417236328125 209.39350286664865 C13.171417236328125 214.64842334442756 18.147729826779482 218.99350891113326 24.166082489311087 218.99350891113326 Z M24.166082489311087 217.08088096561457 C19.285478058239192 217.08088096561457 15.383118835892146 213.65503049041408 15.383118835892146 209.39350286664865 C15.383118835892146 205.1319963985781 19.285478058239192 201.71535822109072 24.15543549380458 201.71535822109072 C29.03607569176645 201.71535822109072 32.9597519805394 205.1319963985781 32.970398976045914 209.39350286664865 C32.98092367186412 213.65503049041408 29.046722687272958 217.08088096561457 24.166082489311087 217.08088096561457 Z M18.806982835282327 210.5633050010862 L24.15543549380458 210.5633050010862 C24.644563867020224 210.5633050010862 25.016703358205795 210.2383716609388 25.016703358205795 209.82058597589358 L25.016703358205795 203.74863155382317 C25.016703358205795 203.33083478722347 24.644563867020224 203.0058802913812 24.15543549380458 203.0058802913812 C23.687599957831306 203.0058802913812 23.315460466645735 203.33083478722347 23.315460466645735 203.74863155382317 L23.315460466645735 209.07786594328692 L18.806982835282327 209.07786594328692 C18.32850145757319 209.07786594328692 17.956337737204088 209.4027992834343 17.956337737204088 209.82058597589358 C17.956337737204088 210.2383716609388 18.32850145757319 210.5633050010862 18.806982835282327 210.5633050010862 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-0f3b9" fill="#007EFF" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Group 15" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Ofertas"   datasizewidth="152.8px" datasizeheight="24.0px" dataX="46.0" dataY="158.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_5_0">Ofertas</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="icons8-discount-100"   datasizewidth="24.7px" datasizeheight="24.7px" dataX="11.8" dataY="158.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/ebbdcb12-b88e-4ddf-b31c-d93e70be17d5.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;