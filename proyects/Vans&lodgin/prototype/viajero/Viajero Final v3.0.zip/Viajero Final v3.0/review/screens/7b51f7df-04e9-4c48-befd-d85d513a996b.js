var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-7b51f7df-04e9-4c48-befd-d85d513a996b" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="habitaciones" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/7b51f7df-04e9-4c48-befd-d85d513a996b-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="428.0px" datasizeheight="926.0px" datasizewidthpx="427.9999999999998" datasizeheightpx="925.9999999999993" dataX="0.0" dataY="-0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Habitaciones"   datasizewidth="128.2px" datasizeheight="23.0px" dataX="69.0" dataY="70.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Habitaciones</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_17" class="path firer click commentable non-processed" customid="Chevron left"   datasizewidth="19.0px" datasizeheight="33.0px" dataX="37.0" dataY="65.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.973670959472656" height="32.966854095458984" viewBox="37.0 65.03314766987339 18.973670959472656 32.966854095458984" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_17-7b51f" d="M37.0 81.51657433904222 C37.0 82.16695498545933 37.24158746844515 82.72451571411108 37.76191295636316 83.20764830614837 L52.21981491915155 97.36822689184217 C52.628523407417525 97.77693538010814 53.14887107597283 98.00000000000027 53.762248370136895 98.00000000000027 C54.98858354277821 98.00000000000027 55.97367000579834 97.0337348159257 55.97367000579834 95.78858239718195 C55.97367000579834 95.17541279443974 55.7133903093882 94.63645960404699 55.30468182112223 94.2089338696786 L42.277618490304405 81.51657433904222 L55.30468182112223 68.82415229933713 C55.7133903093882 68.39673242710124 55.97367000579834 67.83923622393976 55.97367000579834 67.24456930553484 C55.97367000579834 65.99947939585982 54.98858354277821 65.03314766987339 53.762248370136895 65.03314766987339 C53.14887107597283 65.03314766987339 52.628523407417525 65.25615078890759 52.21981491915155 65.66498530352176 L37.76191295636316 79.80689485009864 C37.24158746844515 80.30863498039494 37.0 80.86619369262512 37.0 81.51657433904222 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-7b51f" fill="#007EFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer ie-background commentable non-processed" customid="Path 1"   datasizewidth="384.2px" datasizeheight="3.0px" dataX="21.9" dataY="114.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="384.2122802734375" height="2.0" viewBox="21.89386676224156 114.0 384.2122802734375 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-7b51f" d="M22.89386676224156 115.0 L405.1061332377579 115.0 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-7b51f" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="square"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_17" class="richtext autofit firer ie-background commentable non-processed" customid="&iquest;Cu&aacute;ntas habitaciones que"   datasizewidth="395.2px" datasizeheight="23.0px" dataX="17.5" dataY="123.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_17_0">&iquest;Cu&aacute;ntas habitaciones quer&eacute;s reservar?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="contador" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Paragraph_18" class="richtext manualfit firer pageload ie-background commentable non-processed" customid="1"   datasizewidth="72.9px" datasizeheight="22.0px" dataX="209.2" dataY="177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_18_0">1</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_13" class="button multiline manualfit firer click commentable non-processed" customid="-"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="101.4" dataY="166.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_13_0">-</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_14" class="button multiline manualfit firer click commentable non-processed" customid="+"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="264.4" dataY="166.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_14_0">+</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Dynamic_Panel_3" class="dynamicpanel firer ie-background commentable hidden non-processed" customid="Dynamic Panel 3" datasizewidth="428.0px" datasizeheight="186.0px" dataX="0.0" dataY="592.0" >\
        <div id="s-Panel_3" class="panel default firer pageload ie-background commentable non-processed" customid="Panel 1"  datasizewidth="428.0px" datasizeheight="186.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="388.0px" datasizeheight="165.0px" datasizewidthpx="388.0" datasizeheightpx="164.99999999999997" dataX="20.0" dataY="0.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_3_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_13" class="richtext autofit firer ie-background commentable non-processed" customid="Adultos"   datasizewidth="74.4px" datasizeheight="23.0px" dataX="38.0" dataY="53.3" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_13_0">Adultos</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_15" class="richtext autofit firer ie-background commentable non-processed" customid="Menores"   datasizewidth="84.2px" datasizeheight="23.0px" dataX="36.4" dataY="108.3" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_15_0">Menores</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_12" class="richtext manualfit firer ie-background commentable non-processed" customid="Habitaci&oacute;n 3"   datasizewidth="122.3px" datasizeheight="23.0px" dataX="38.0" dataY="12.3" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_12_0">Habitaci&oacute;n 3</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="contador menor" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Paragraph_14" class="richtext manualfit firer pageload ie-background commentable non-processed" customid="0"   datasizewidth="72.9px" datasizeheight="22.0px" dataX="296.7" dataY="110.5" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_14_0">0</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_9" class="button multiline manualfit firer click commentable non-processed" customid="-"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="214.0" dataY="100.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_9_0">-</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_10" class="button multiline manualfit firer click commentable non-processed" customid="+"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="333.2" dataY="100.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_10_0">+</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="contador adulto" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Paragraph_16" class="richtext manualfit firer pageload ie-background commentable non-processed" customid="1"   datasizewidth="72.9px" datasizeheight="22.0px" dataX="296.7" dataY="50.5" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_16_0">1</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_11" class="button multiline manualfit firer click commentable non-processed" customid="-"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="214.0" dataY="40.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_11_0">-</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_12" class="button multiline manualfit firer click commentable non-processed" customid="+"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="333.2" dataY="40.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_12_0">+</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_2" class="dynamicpanel firer ie-background commentable hidden non-processed" customid="Dynamic Panel 2" datasizewidth="428.0px" datasizeheight="186.0px" dataX="-0.0" dataY="414.0" >\
        <div id="s-Panel_2" class="panel default firer pageload ie-background commentable non-processed" customid="Panel 1"  datasizewidth="428.0px" datasizeheight="186.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="388.0px" datasizeheight="165.0px" datasizewidthpx="388.0" datasizeheightpx="164.99999999999997" dataX="20.0" dataY="0.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_2_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="Habitaci&oacute;n 2"   datasizewidth="122.3px" datasizeheight="23.0px" dataX="38.0" dataY="12.3" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_7_0">Habitaci&oacute;n 2</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_8" class="richtext autofit firer ie-background commentable non-processed" customid="Adultos"   datasizewidth="74.4px" datasizeheight="23.0px" dataX="38.0" dataY="53.3" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_8_0">Adultos</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_10" class="richtext autofit firer ie-background commentable non-processed" customid="Menores"   datasizewidth="84.2px" datasizeheight="23.0px" dataX="36.4" dataY="108.3" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_10_0">Menores</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="contador menor" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Paragraph_11" class="richtext manualfit firer pageload ie-background commentable non-processed" customid="0"   datasizewidth="72.9px" datasizeheight="22.0px" dataX="296.7" dataY="112.5" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_11_0">0</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_7" class="button multiline manualfit firer click commentable non-processed" customid="-"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="214.0" dataY="102.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_7_0">-</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_8" class="button multiline manualfit firer click commentable non-processed" customid="+"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="333.2" dataY="102.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_8_0">+</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="contador adulto" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Paragraph_9" class="richtext manualfit firer pageload ie-background commentable non-processed" customid="1"   datasizewidth="72.9px" datasizeheight="22.0px" dataX="296.7" dataY="57.5" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_9_0">1</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="-"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="214.0" dataY="47.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_5_0">-</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="+"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="333.2" dataY="47.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_6_0">+</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Dynamic Panel 1" datasizewidth="428.0px" datasizeheight="186.0px" dataX="0.0" dataY="235.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel 1"  datasizewidth="428.0px" datasizeheight="186.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_7" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="388.0px" datasizeheight="165.0px" datasizewidthpx="388.0" datasizeheightpx="164.99999999999997" dataX="20.0" dataY="0.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_7_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Habitaci&oacute;n 1"   datasizewidth="122.3px" datasizeheight="23.0px" dataX="38.0" dataY="12.3" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_1_0">Habitaci&oacute;n 1</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Adultos"   datasizewidth="74.4px" datasizeheight="23.0px" dataX="38.0" dataY="53.3" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_2_0">Adultos</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Menores"   datasizewidth="84.2px" datasizeheight="23.0px" dataX="36.4" dataY="108.3" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_5_0">Menores</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="contador menor" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Paragraph_6" class="richtext manualfit firer pageload ie-background commentable non-processed" customid="0"   datasizewidth="72.9px" datasizeheight="22.0px" dataX="296.7" dataY="111.5" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_6_0">0</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="-"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="214.0" dataY="101.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_3_0">-</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="+"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="333.2" dataY="101.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_4_0">+</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="contador adulto" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Paragraph_4" class="richtext manualfit firer pageload ie-background commentable non-processed" customid="1"   datasizewidth="72.9px" datasizeheight="22.0px" dataX="296.7" dataY="50.5" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_4_0">1</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="-"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="214.0" dataY="40.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_1_0">-</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="+"   datasizewidth="62.0px" datasizeheight="43.0px" dataX="333.2" dataY="40.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Button_2_0">+</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;