var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-7039ddf3-b6fd-48f9-a207-006468e745f3" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="RegistrarViajero2" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/7039ddf3-b6fd-48f9-a207-006468e745f3-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="433.0px" datasizeheight="926.0px" dataX="-2.5" dataY="-11.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/0bb1c4a1-c19f-42cd-8b7b-26e6ef17703b.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="428.5px" datasizeheight="926.0px" datasizewidthpx="428.50000000000017" datasizeheightpx="925.9999999999998" dataX="2.0" dataY="-11.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="59.8px" datasizeheight="57.6px" dataX="339.5" dataY="10.4"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/9fdf7276-462a-4c37-8647-8fae1ed34fe6.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="email text firer focusout commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="69.4" dataY="171.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="email"  value="" maxlength="100"  tabindex="-1" placeholder="Usuario"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="password firer focusout commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="69.4" dataY="286.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="Contrase&ntilde;a"/></div></div></div></div></div>\
      <div id="s-Button_1" class="button multiline manualfit firer click ie-background commentable non-processed" customid="Button Filled"   datasizewidth="300.0px" datasizeheight="50.0px" dataX="64.0" dataY="611.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Registrarse</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Solo unos pasos m&aacute;s!"   datasizewidth="157.4px" datasizeheight="18.0px" dataX="128.0" dataY="68.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Solo unos pasos m&aacute;s!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer click commentable non-processed" customid="Arrow left"   datasizewidth="34.0px" datasizeheight="31.4px" dataX="17.0" dataY="23.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="34.0" height="31.449764251708984" viewBox="16.999999999999243 23.480610808931097 34.0 31.449764251708984" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-7039d" d="M16.999999999999243 39.21564408016107 C16.999999999999243 39.82402213397565 17.23349507396648 40.43240238800091 17.6465773073612 40.87836308992265 L29.500659938814547 54.24101479931673 C29.93184919776831 54.70750786726705 30.39880036814265 54.93037600748344 30.919700379494877 54.93037600748344 C32.051211154597794 54.93037600748344 32.87741654782537 54.01792223761138 32.87741654782537 52.78109140777425 C32.87741654782537 52.13210846593378 32.66182386722649 51.584634443842006 32.28458539812863 51.17928083015683 L28.243471867701903 46.55587692695274 L23.03483814324486 41.182436605769446 L27.219654142364075 41.46643979982963 L48.988329144057744 41.46643979982963 C50.17379265789455 41.46643979982963 51.00000000000014 40.53368248583929 51.00000000000014 39.21564408016107 C51.00000000000014 37.87730213036457 50.17379265789455 36.944547016584906 48.988329144057744 36.944547016584906 L27.219654142364075 36.944547016584906 L23.052800951831422 37.22854801043441 L28.243471867701903 31.855109889461794 L32.28458539812863 27.231866601637062 C32.66182386722649 26.82632597004442 32.87741654782537 26.27885414816332 32.87741654782537 25.629986717383346 C32.87741654782537 24.39306347869782 32.051211154597794 23.480610808931097 30.919700379494877 23.480610808931097 C30.39880036814265 23.480610808931097 29.913866900401683 23.703659366422922 29.446915730027346 24.210573604807678 L17.6465773073612 37.53262372649189 C17.23349507396648 37.97881325032394 16.999999999999243 38.58696248222821 16.999999999999243 39.21564408016107 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-7039d" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_4" class="password firer focusout commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="71.4" dataY="377.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="Confirma tu contrase&ntilde;a"/></div></div></div></div></div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable hidden non-processed" customid="El usuario ya esta en uso"   datasizewidth="184.1px" datasizeheight="18.0px" dataX="29.9" dataY="123.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">El usuario ya esta en uso!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable hidden non-processed" customid="El nombre debe contener m"   datasizewidth="333.5px" datasizeheight="18.0px" dataX="29.9" dataY="145.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">El nombre debe contener m&iacute;nimo 8 caracteres!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable hidden non-processed" customid="Las contrase&ntilde;as no coinci"   datasizewidth="211.7px" datasizeheight="18.0px" dataX="37.6" dataY="348.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Las contrase&ntilde;as no coinciden</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable hidden non-processed" customid="Las contrase&ntilde;a debe conte"   datasizewidth="374.4px" datasizeheight="18.0px" dataX="35.6" dataY="258.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Las contrase&ntilde;a debe contener m&iacute;nimo 10 caracteres</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;