var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-7e8caab1-b88c-40c0-bd49-27906cb022da" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Filtro" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/7e8caab1-b88c-40c0-bd49-27906cb022da-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="434.0px" datasizeheight="175.0px" datasizewidthpx="434.00000000000125" datasizeheightpx="175.00000000000006" dataX="-2.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="429.4px" datasizeheight="766.0px" datasizewidthpx="429.3762512960627" datasizeheightpx="766.0000000000009" dataX="-1.4" dataY="226.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 6" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Group 7" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 4"   datasizewidth="434.7px" datasizeheight="544.7px" datasizewidthpx="434.6897719025788" datasizeheightpx="544.71568327204" dataX="-2.0" dataY="80.9" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_3_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group 5" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Tipo Hospedaje"   datasizewidth="420.4px" datasizeheight="16.5px" dataX="29.9" dataY="131.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_1_0">Tipo Hospedaje</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Cantidad de dias"   datasizewidth="126.9px" datasizeheight="16.0px" dataX="29.9" dataY="293.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_2_0">Cantidad de dias</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Rango de precio"   datasizewidth="102.7px" datasizeheight="16.0px" dataX="29.9" dataY="325.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_3_0">Rango de precio</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Input_1" class="text firer pageunload commentable non-processed" customid="Input 1"  datasizewidth="152.1px" datasizeheight="18.7px" dataX="29.9" dataY="350.0" ><div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="$" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
            <div id="s-Input_2" class="text firer pageunload commentable non-processed" customid="Input 1"  datasizewidth="152.1px" datasizeheight="18.7px" dataX="210.1" dataY="350.0" ><div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="$" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
            <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="-"   datasizewidth="10.5px" datasizeheight="20.0px" dataX="190.4" dataY="349.3" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_4_0">-</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Category_1" class="checkboxlist firer toggle commentable non-processed" customid="Category 2"    datasizewidth="234.2px" datasizeheight="120.9px" dataX="29.9" dataY="156.0"  tabindex="-1">\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="scroll">\
                  <div class="paddingLayer">\
                    <table class="collapse" style="height: 100%; width: 100%;" summary="">\
                      <tbody>\
                        <tr>\
                          <td>\
                              <div class="checkbox inputIOS unchecked" name="s-Category_1"   tabindex="-1" >\
                              <div class="backgroundLayer">\
                                <div class="colorLayer"></div>\
                                <div class="imageLayer"></div>\
                              </div>\
                              </div><span class="option">Hotel</span>\
                          </td>\
                        </tr>\
                        <tr>\
                          <td>\
                              <div class="checkbox inputIOS unchecked" name="s-Category_1"   tabindex="-1" >\
                              <div class="backgroundLayer">\
                                <div class="colorLayer"></div>\
                                <div class="imageLayer"></div>\
                              </div>\
                              </div><span class="option">Caba&ntilde;a</span>\
                          </td>\
                        </tr>\
                        <tr>\
                          <td>\
                              <div class="checkbox inputIOS unchecked" name="s-Category_1"   tabindex="-1" >\
                              <div class="backgroundLayer">\
                                <div class="colorLayer"></div>\
                                <div class="imageLayer"></div>\
                              </div>\
                              </div><span class="option">Apar Hotel</span>\
                          </td>\
                        </tr>\
                        <tr>\
                          <td>\
                              <div class="checkbox inputIOS unchecked" name="s-Category_1"   tabindex="-1" >\
                              <div class="backgroundLayer">\
                                <div class="colorLayer"></div>\
                                <div class="imageLayer"></div>\
                              </div>\
                              </div><span class="option">Hostal</span>\
                          </td>\
                        </tr>\
                        <tr>\
                          <td>\
                              <div class="checkbox inputIOS unchecked" name="s-Category_1"   tabindex="-1" >\
                              <div class="backgroundLayer">\
                                <div class="colorLayer"></div>\
                                <div class="imageLayer"></div>\
                              </div>\
                              </div><span class="option">Pension</span>\
                          </td>\
                        </tr>\
                      </tbody>\
                    </table>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Input_3" class="text firer pageunload commentable non-processed" customid="Input 1"  datasizewidth="103.9px" datasizeheight="18.7px" dataX="165.3" dataY="291.7" ><div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
            <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Ordenar por :"   datasizewidth="83.3px" datasizeheight="16.0px" dataX="29.9" dataY="385.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_5_0">Ordenar por :</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="376.9px" datasizeheight="32.0px" dataX="28.3" dataY="560.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Button_2_0">Aplicar filtro</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group 4" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Filtrar"   datasizewidth="438.8px" datasizeheight="18.0px" dataX="-2.0" dataY="95.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_6_0">Filtrar</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_117" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="16.3px" datasizeheight="16.0px" dataX="14.6" dataY="97.0"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="16.28814125061035" height="16.0" viewBox="14.596662333391407 96.99999999999991 16.28814125061035 16.0" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_117-7e8ca" d="M30.88480366931946 103.99999999999993 L18.495636088011274 103.99999999999993 L24.186305622586957 98.40999984741202 L22.740733001355434 96.99999999999991 L14.596662333391407 104.99999999999994 L22.740733001355434 112.99999999999996 L24.176125422604382 111.59000003337856 L18.495636088011274 105.99999999999994 L30.88480366931946 105.99999999999994 L30.88480366931946 103.99999999999993 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_117-7e8ca" fill="#7D7D7D" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Category_2" class="dropdown firer commentable non-processed" customid="Category 2"    datasizewidth="155.0px" datasizeheight="16.0px" dataX="135.8" dataY="385.0"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Mas Relevantes</div></div></div></div></div><select id="s-Category_2-options" class="s-7e8caab1-b88c-40c0-bd49-27906cb022da dropdown-options" ><option selected="selected" class="option">Mas Relevantes</option>\
      <option  class="option">Menor Precio</option>\
      <option  class="option">Mayor precio</option></select></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;