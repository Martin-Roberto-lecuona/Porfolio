var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-22eef7c5-9d3c-401a-a013-db6e81ee1cc4" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Historial" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/22eef7c5-9d3c-401a-a013-db6e81ee1cc4-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Dynamic Panel 1" datasizewidth="424.8px" datasizeheight="919.7px" dataX="-1.4" dataY="141.0" >\
        <div id="s-Panel_1" class="panel default firer windowscroll ie-background commentable non-processed" customid="Panel 1"  datasizewidth="424.8px" datasizeheight="919.7px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="434.0px" datasizeheight="1046.9px" datasizewidthpx="434.00000000000114" datasizeheightpx="1046.8645606953237" dataX="-3.0" dataY="3.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="386.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_9" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="406.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_10" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="426.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_10_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_11" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="446.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_11_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_12" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="466.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_12_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="434.0px" datasizeheight="101.0px" datasizewidthpx="434.0000000000012" datasizeheightpx="101.00000000000006" dataX="-3.0" dataY="-5.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Group 8" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Path_33" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="13.9px" dataX="335.9" dataY="169.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="13.896464347839355" viewBox="335.9205430456144 168.9970407864929 14.550774574279785 13.896464347839355" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_33-22eef" d="M338.70981996558925 182.78937442699154 C338.9564744275809 182.96927495223963 339.25452389483786 182.91275361208963 339.6193706923215 182.64550289088018 L343.1959327136725 180.02474904927908 L346.7724631492909 182.64550289088018 C347.1373415325072 182.91275361208963 347.44049844224804 182.96927495223963 347.68205785989386 182.78937442699154 C347.9184171442143 182.6095353020461 347.9749384843643 182.31151712532798 347.83106694825295 181.8798422974663 L346.42820109846826 177.6763828907476 L350.0304234280378 175.08645731457028 C350.3953006304791 174.82436362839687 350.53917216659045 174.5520113685788 350.4415456853586 174.26424468085506 C350.3490567563745 173.98674837452648 350.0818060351651 173.8377268880294 349.61936375179476 173.84286503066463 L345.20003564060636 173.86856223810352 L343.84855239794894 169.64965726053717 C343.70981959486033 169.21286768414595 343.49395089039064 168.9970407864929 343.1959327136725 168.9970407864929 C342.8979139465669 168.9970407864929 342.68204583248473 169.21286768414595 342.54331302939613 169.64965726053717 L341.19182329247593 173.86856223810352 L336.77251422128523 173.84286503066463 C336.31516731435374 173.8377268880294 336.04281472244264 173.98674837452648 335.9503173158627 174.26424468085506 C335.85268154063976 174.5520113685788 335.9965661436876 174.82436362839687 336.3614159115584 175.08645731457028 L339.9636705279458 177.6763828907476 L338.56593042265837 181.8798422974663 C338.41690893616124 182.31151712532798 338.473435589799 182.6095353020461 338.70981996558925 182.78937442699154 Z "></path>\
            	      <filter filterUnits="userSpaceOnUse" x="334.9205430456144" y="167.9970407864929" width="18.672094917839427" height="18.017784691398997" color-interpolation-filters="sRGB" id="s-Path_33-22eef_effects">\
            	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
            	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
            	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
            	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
            	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
            	      </filter>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal" filter="url(#s-Path_33-22eef_effects)">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_33-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_1" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="13.9px" dataX="367.3" dataY="169.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="13.896464347839355" viewBox="367.2657633811349 168.9970407864929 14.550774574279785 13.896464347839355" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-22eef" d="M370.0550403011097 182.78937442699154 C370.3016947631014 182.96927495223963 370.5997442303584 182.91275361208963 370.96459102784206 182.64550289088018 L374.54115304919304 180.02474904927908 L378.1176834848115 182.64550289088018 C378.48256186802774 182.91275361208963 378.78571877776864 182.96927495223963 379.02727819541445 182.78937442699154 C379.2636374797348 182.6095353020461 379.32015881988485 182.31151712532798 379.1762872837735 181.8798422974663 L377.77342143398886 177.6763828907476 L381.3756437635584 175.08645731457028 C381.7405209659997 174.82436362839687 381.88439250211104 174.5520113685788 381.7867660208792 174.26424468085506 C381.6942770918951 173.98674837452648 381.42702637068567 173.8377268880294 380.9645840873153 173.84286503066463 L376.5452559761269 173.86856223810352 L375.1937727334695 169.64965726053717 C375.0550399303809 169.21286768414595 374.8391712259112 168.9970407864929 374.54115304919304 168.9970407864929 C374.24313428208745 168.9970407864929 374.02726616800527 169.21286768414595 373.8885333649166 169.64965726053717 L372.53704362799647 173.86856223810352 L368.1177345568057 173.84286503066463 C367.6603876498742 173.8377268880294 367.3880350579631 173.98674837452648 367.2955376513832 174.26424468085506 C367.19790187616024 174.5520113685788 367.34178647920805 174.82436362839687 367.7066362470789 175.08645731457028 L371.30889086346633 177.6763828907476 L369.91115075817885 181.8798422974663 C369.7621292716818 182.31151712532798 369.8186559253195 182.6095353020461 370.0550403011097 182.78937442699154 Z "></path>\
            	      <filter filterUnits="userSpaceOnUse" x="366.2657633811349" y="167.9970407864929" width="18.672094917839427" height="18.017784691398997" color-interpolation-filters="sRGB" id="s-Path_1-22eef_effects">\
            	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
            	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
            	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
            	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
            	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
            	      </filter>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal" filter="url(#s-Path_1-22eef_effects)">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_2" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="13.9px" dataX="351.4" dataY="169.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="13.896464347839355" viewBox="351.3687858770139 168.9970407864929 14.550774574279785 13.896464347839355" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_2-22eef" d="M354.15806279698876 182.78937442699154 C354.40471725898044 182.96927495223963 354.7027667262374 182.91275361208963 355.0676135237211 182.64550289088018 L358.6441755450721 180.02474904927908 L362.2207059806905 182.64550289088018 C362.5855843639068 182.91275361208963 362.88874127364767 182.96927495223963 363.1303006912935 182.78937442699154 C363.36665997561386 182.6095353020461 363.4231813157639 182.31151712532798 363.2793097796525 181.8798422974663 L361.8764439298679 177.6763828907476 L365.47866625943743 175.08645731457028 C365.8435434618787 174.82436362839687 365.9874149979901 174.5520113685788 365.88978851675824 174.26424468085506 C365.79729958777415 173.98674837452648 365.5300488665647 173.8377268880294 365.06760658319433 173.84286503066463 L360.6482784720059 173.86856223810352 L359.2967952293485 169.64965726053717 C359.1580624262599 169.21286768414595 358.9421937217902 168.9970407864929 358.6441755450721 168.9970407864929 C358.3461567779665 168.9970407864929 358.1302886638843 169.21286768414595 357.99155586079564 169.64965726053717 L356.6400661238755 173.86856223810352 L352.22075705268475 173.84286503066463 C351.76341014575326 173.8377268880294 351.49105755384215 173.98674837452648 351.39856014726223 174.26424468085506 C351.3009243720393 174.5520113685788 351.4448089750871 174.82436362839687 351.80965874295794 175.08645731457028 L355.41191335934536 177.6763828907476 L354.0141732540579 181.8798422974663 C353.8651517675608 182.31151712532798 353.9216784211985 182.6095353020461 354.15806279698876 182.78937442699154 Z "></path>\
            	      <filter filterUnits="userSpaceOnUse" x="350.3687858770139" y="167.9970407864929" width="18.672094917839427" height="18.017784691398997" color-interpolation-filters="sRGB" id="s-Path_2-22eef_effects">\
            	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
            	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
            	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
            	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
            	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
            	      </filter>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal" filter="url(#s-Path_2-22eef_effects)">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_3" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="13.9px" dataX="382.9" dataY="169.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="13.896464347839355" viewBox="382.87480238453304 168.9970407864929 14.550774574279785 13.896464347839355" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_3-22eef" d="M385.6640793045079 182.78937442699154 C385.9107337664995 182.96927495223963 386.2087832337565 182.91275361208963 386.57363003124016 182.64550289088018 L390.15019205259114 180.02474904927908 L393.72672248820953 182.64550289088018 C394.09160087142584 182.91275361208963 394.3947577811667 182.96927495223963 394.6363171988125 182.78937442699154 C394.8726764831329 182.6095353020461 394.92919782328295 182.31151712532798 394.7853262871716 181.8798422974663 L393.3824604373869 177.6763828907476 L396.98468276695644 175.08645731457028 C397.3495599693977 174.82436362839687 397.4934315055091 174.5520113685788 397.39580502427725 174.26424468085506 C397.30331609529316 173.98674837452648 397.0360653740837 173.8377268880294 396.5736230907134 173.84286503066463 L392.154294979525 173.86856223810352 L390.80281173686757 169.64965726053717 C390.66407893377897 169.21286768414595 390.44821022930927 168.9970407864929 390.15019205259114 168.9970407864929 C389.85217328548555 168.9970407864929 389.63630517140336 169.21286768414595 389.49757236831476 169.64965726053717 L388.14608263139456 173.86856223810352 L383.72677356020387 173.84286503066463 C383.2694266532724 173.8377268880294 382.9970740613613 173.98674837452648 382.90457665478135 174.26424468085506 C382.8069408795584 174.5520113685788 382.9508254826062 174.82436362839687 383.31567525047706 175.08645731457028 L386.9179298668644 177.6763828907476 L385.520189761577 181.8798422974663 C385.37116827507987 182.31151712532798 385.42769492871764 182.6095353020461 385.6640793045079 182.78937442699154 Z "></path>\
            	      <filter filterUnits="userSpaceOnUse" x="381.87480238453304" y="167.9970407864929" width="18.672094917839427" height="18.017784691398997" color-interpolation-filters="sRGB" id="s-Path_3-22eef_effects">\
            	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
            	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
            	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
            	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
            	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
            	      </filter>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal" filter="url(#s-Path_3-22eef_effects)">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_131" class="path firer commentable non-processed" customid="Star half"   datasizewidth="14.6px" datasizeheight="13.9px" dataX="398.4" dataY="169.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="14.550853729248047" height="13.91293716430664" viewBox="398.44914435596866 168.98880544134934 14.550853729248047 13.91293716430664" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_131-22eef" d="M401.24107636840927 182.7668056758645 C401.54495818599986 182.9995595895701 401.91995317488295 182.92195109889957 402.35961021345787 182.60518773389208 L405.72168461831717 180.13530790127152 L409.08373727506387 182.60518773389208 C409.52335081741353 182.92195109889957 409.90484779041884 182.9995595895701 410.20873767585766 182.7668056758645 C410.506152236151 182.54052568420028 410.57081428584286 182.16550123013232 410.39624990289167 181.65475311915347 L409.0707908340851 177.70427019779532 L412.46521099638267 175.26683153368782 C412.8983492135869 174.95646912931164 413.08586144062093 174.6138121807946 412.9630112632787 174.2517348692574 C412.84016108593653 173.8961307782096 412.4975048389715 173.721550961114 411.9608624429311 173.72801716608316 L407.79711893229756 173.75386023784725 L406.5298486926934 169.78405902928785 C406.368230750721 169.2668222636752 406.10310933146445 168.98880544134934 405.72168461831717 168.98880544134934 C405.3466601642492 168.98880544134934 405.08161240795476 169.2668222636752 404.91344758253086 169.78405902928785 L403.6462503043368 173.75386023784725 L399.48246294670196 173.72801716608316 C398.9458205506616 173.721550961114 398.6096154252973 173.8961307782096 398.48677226347536 174.2517348692574 C398.3639294524294 174.6138121807946 398.5449607419017 174.95646912931164 398.98461778047664 175.26683153368782 L402.37900882836544 177.70427019779532 L401.0471126689985 181.65475311915347 C400.8725402181991 182.16550123013232 400.9371945508187 182.54052568420028 401.24107636840927 182.7668056758645 Z M405.72168461831717 178.79697535289628 L405.72168461831717 170.91552493349886 C405.7410320199273 170.91552493349886 405.7475052404166 170.92199113846803 405.7604523829474 170.9607810019869 L406.79497011194997 174.4909620034524 C406.89192600423064 174.81419788739726 407.0664910887338 174.92410092220868 407.39620019316806 174.91122744264 L411.0750898778843 174.82714502992803 C411.11393060392464 174.82714502992803 411.1268040834933 174.83361895196944 411.1332780055347 174.84656609450022 C411.1397519275761 174.86591279455828 411.1332780055347 174.8723867165997 411.1009841629459 174.89180707961984 L408.06864061063345 176.97371531564164 C407.771224647236 177.17410102224432 407.7324568826058 177.3680871713197 407.8423606189692 177.68492279618525 L409.0707908340851 181.1568784877433 C409.08373727506387 181.18917233033216 409.08373727506387 181.19564625237354 409.0707908340851 181.20859409645635 C409.05784299000226 181.2280144594765 409.0449695104336 181.2150666153937 409.01907522537203 181.20212017441494 L406.10310933146445 178.95212077593135 C405.97385889504295 178.8486909616093 405.84453479565934 178.79697535289628 405.72168461831717 178.79697535289628 Z "></path>\
            	      <filter filterUnits="userSpaceOnUse" x="397.44914435596866" y="167.98880544134934" width="18.67217407280769" height="18.034257507866283" color-interpolation-filters="sRGB" id="s-Path_131-22eef_effects">\
            	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
            	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
            	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
            	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
            	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
            	      </filter>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal" filter="url(#s-Path_131-22eef_effects)">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_131-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_4" class="path firer ie-background commentable non-processed" customid="Path 4"   datasizewidth="405.2px" datasizeheight="3.0px" dataX="13.4" dataY="357.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="405.23126220703125" height="2.0" viewBox="13.384373049826877 356.99434977731903 405.23126220703125 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-22eef" d="M14.384373049826877 357.99434977731903 L417.6156269501737 357.99434977731903 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-22eef" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="square"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_9" class="image firer ie-background commentable non-processed" customid="Image 9"   datasizewidth="229.9px" datasizeheight="405.0px" dataX="-448.0" dataY="206.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4aa0914a-2684-4a76-a420-b54de6a63c8f.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_5" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 5"   datasizewidth="349.0px" datasizeheight="40.0px" datasizewidthpx="349.0" datasizeheightpx="39.99999999999997" dataX="54.3" dataY="56.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0">Historial</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer commentable non-processed" customid="Menu"   datasizewidth="27.0px" datasizeheight="18.0px" dataX="12.0" dataY="67.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="27.0" height="18.0" viewBox="11.999999999998522 66.99999999999991 27.0 18.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-22eef" d="M11.999999999998522 84.99999999999991 L38.99999999999852 84.99999999999991 L38.99999999999852 81.99999999999991 L11.999999999998522 81.99999999999991 L11.999999999998522 84.99999999999991 Z M11.999999999998522 77.49999999999991 L38.99999999999852 77.49999999999991 L38.99999999999852 74.49999999999991 L11.999999999998522 74.49999999999991 L11.999999999998522 77.49999999999991 Z M11.999999999998522 66.99999999999991 L11.999999999998522 69.99999999999991 L38.99999999999852 69.99999999999991 L38.99999999999852 66.99999999999991 L11.999999999998522 66.99999999999991 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-22eef" fill="#007EFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Group 4" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="406.3px" datasizeheight="278.0px" datasizewidthpx="406.3285827636726" datasizeheightpx="278.00000000000057" dataX="13.2" dataY="119.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_2_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="405.0px" datasizeheight="139.3px" dataX="14.5" dataY="119.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/a40deff2-bba7-4f75-9554-ccb13c0347be.jpg" />\
            	</div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Villa Maria"   datasizewidth="375.7px" datasizeheight="21.3px" dataX="30.8" dataY="296.8" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_1_0">Villa Maria</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Hotel Abudabi"   datasizewidth="379.0px" datasizeheight="23.4px" dataX="25.6" dataY="270.4" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_6_0">Hotel Abudabi</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="99.3px" datasizeheight="32.0px" dataX="307.2" dataY="354.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Button_1_0">Ver detalle</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_12" class="group firer ie-background commentable non-processed" customid="Group 8" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Path_9" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="338.9" dataY="135.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="338.9205430456143 134.95298551836572 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_9-22eef" d="M341.70981996558913 149.62381174743115 C341.95647442758076 149.81517090486068 342.25452389483775 149.75504947935076 342.6193706923214 149.47077641921078 L346.1959327136724 146.68309558132935 L349.7724631492908 149.47077641921078 C350.1373415325071 149.75504947935076 350.44049844224793 149.81517090486068 350.68205785989375 149.62381174743115 C350.9184171442142 149.4325179011516 350.9749384843642 149.115517674961 350.83106694825284 148.6563476351336 L349.42820109846815 144.18515196047102 L353.0304234280377 141.43026297179836 C353.39530063047897 141.15147542026358 353.53917216659033 140.8617758827501 353.4415456853585 140.5556801066363 C353.3490567563744 140.26050887633775 353.08180603516496 140.1019955754141 352.61936375179465 140.10746098828088 L348.20003564060625 140.13479496052477 L346.8485523979488 135.64716992069305 C346.7098195948602 135.18255935217502 346.4939508903905 134.95298551836572 346.1959327136724 134.95298551836572 C345.8979139465668 134.95298551836572 345.6820458324846 135.18255935217502 345.543313029396 135.64716992069305 L344.1918232924758 140.13479496052477 L339.7725142212851 140.10746098828088 C339.31516731435363 140.1019955754141 339.04281472244253 140.26050887633775 338.9503173158626 140.5556801066363 C338.85268154063965 140.8617758827501 338.99656614368746 141.15147542026358 339.3614159115583 141.43026297179836 L342.9636705279457 144.18515196047102 L341.56593042265825 148.6563476351336 C341.4169089361611 149.115517674961 341.4734355897989 149.4325179011516 341.70981996558913 149.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="337.9205430456143" y="133.95298551836572" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_9-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_9-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_10" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="370.3" dataY="135.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="370.26576338113546 134.95298551836572 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_10-22eef" d="M373.0550403011103 149.62381174743115 C373.301694763102 149.81517090486068 373.59974423035897 149.75504947935076 373.96459102784263 149.47077641921078 L377.54115304919367 146.68309558132935 L381.1176834848121 149.47077641921078 C381.4825618680284 149.75504947935076 381.78571877776926 149.81517090486068 382.0272781954151 149.62381174743115 C382.2636374797355 149.4325179011516 382.32015881988553 149.115517674961 382.1762872837742 148.6563476351336 L380.7734214339895 144.18515196047102 L384.3756437635591 141.43026297179836 C384.74052096600036 141.15147542026358 384.8843925021117 140.8617758827501 384.7867660208799 140.5556801066363 C384.6942770918958 140.26050887633775 384.42702637068635 140.1019955754141 383.964584087316 140.10746098828088 L379.5452559761275 140.13479496052477 L378.19377273347015 135.64716992069305 C378.0550399303815 135.18255935217502 377.8391712259118 134.95298551836572 377.54115304919367 134.95298551836572 C377.2431342820881 134.95298551836572 377.0272661680059 135.18255935217502 376.88853336491724 135.64716992069305 L375.5370436279971 140.13479496052477 L371.1177345568063 140.10746098828088 C370.6603876498748 140.1019955754141 370.3880350579637 140.26050887633775 370.29553765138377 140.5556801066363 C370.1979018761608 140.8617758827501 370.3417864792086 141.15147542026358 370.70663624707953 141.43026297179836 L374.3088908634669 144.18515196047102 L372.9111507581794 148.6563476351336 C372.76212927168234 149.115517674961 372.81865592532006 149.4325179011516 373.0550403011103 149.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="369.26576338113546" y="133.95298551836572" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_10-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_10-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_11" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="354.4" dataY="135.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="354.3687858770138 134.95298551836572 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_11-22eef" d="M357.15806279698865 149.62381174743115 C357.40471725898027 149.81517090486068 357.70276672623726 149.75504947935076 358.0676135237209 149.47077641921078 L361.6441755450719 146.68309558132935 L365.2207059806903 149.47077641921078 C365.5855843639066 149.75504947935076 365.88874127364744 149.81517090486068 366.13030069129326 149.62381174743115 C366.3666599756137 149.4325179011516 366.4231813157637 149.115517674961 366.27930977965235 148.6563476351336 L364.87644392986766 144.18515196047102 L368.4786662594372 141.43026297179836 C368.8435434618785 141.15147542026358 368.98741499798984 140.8617758827501 368.889788516758 140.5556801066363 C368.7972995877739 140.26050887633775 368.53004886656447 140.1019955754141 368.06760658319416 140.10746098828088 L363.64827847200576 140.13479496052477 L362.29679522934833 135.64716992069305 C362.15806242625973 135.18255935217502 361.94219372179003 134.95298551836572 361.6441755450719 134.95298551836572 C361.3461567779663 134.95298551836572 361.13028866388413 135.18255935217502 360.99155586079553 135.64716992069305 L359.64006612387533 140.13479496052477 L355.22075705268463 140.10746098828088 C354.76341014575314 140.1019955754141 354.49105755384204 140.26050887633775 354.3985601472621 140.5556801066363 C354.30092437203916 140.8617758827501 354.44480897508697 141.15147542026358 354.8096587429578 141.43026297179836 L358.4119133593452 144.18515196047102 L357.01417325405777 148.6563476351336 C356.86515176756063 149.115517674961 356.9216784211984 149.4325179011516 357.15806279698865 149.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="353.3687858770138" y="133.95298551836572" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_11-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_11-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_12" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="385.9" dataY="135.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="385.8748023845335 134.95298551836572 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_12-22eef" d="M388.66407930450833 149.62381174743115 C388.91073376649996 149.81517090486068 389.20878323375695 149.75504947935076 389.5736300312406 149.47077641921078 L393.1501920525916 146.68309558132935 L396.72672248821 149.47077641921078 C397.0916008714263 149.75504947935076 397.39475778116713 149.81517090486068 397.63631719881295 149.62381174743115 C397.8726764831334 149.4325179011516 397.9291978232834 149.115517674961 397.78532628717204 148.6563476351336 L396.38246043738735 144.18515196047102 L399.9846827669569 141.43026297179836 C400.3495599693982 141.15147542026358 400.49343150550953 140.8617758827501 400.3958050242777 140.5556801066363 C400.3033160952936 140.26050887633775 400.03606537408416 140.1019955754141 399.57362309071385 140.10746098828088 L395.15429497952545 140.13479496052477 L393.802811736868 135.64716992069305 C393.6640789337794 135.18255935217502 393.4482102293097 134.95298551836572 393.1501920525916 134.95298551836572 C392.852173285486 134.95298551836572 392.6363051714038 135.18255935217502 392.4975723683152 135.64716992069305 L391.146082631395 140.13479496052477 L386.7267735602043 140.10746098828088 C386.26942665327283 140.1019955754141 385.99707406136173 140.26050887633775 385.9045766547818 140.5556801066363 C385.80694087955885 140.8617758827501 385.95082548260666 141.15147542026358 386.3156752504775 141.43026297179836 L389.9179298668649 144.18515196047102 L388.52018976157746 148.6563476351336 C388.3711682750803 149.115517674961 388.4276949287181 149.4325179011516 388.66407930450833 149.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="384.8748023845335" y="133.95298551836572" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_12-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_12-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_12-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_13" class="path firer commentable non-processed" customid="Star half"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="401.4" dataY="134.9"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550853729248047" height="14.799108505249023" viewBox="401.44914435596866 134.94422562894562 14.550853729248047 14.799108505249023" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_13-22eef" d="M404.24107636840927 149.59980549623245 C404.54495818599986 149.847384499983 404.91995317488295 149.7648327933462 405.35961021345787 149.42789341782867 L408.72168461831717 146.800696398417 L412.0837372750638 149.42789341782867 C412.52335081741353 149.7648327933462 412.90484779041884 149.847384499983 413.20873767585766 149.59980549623245 C413.506152236151 149.35911276624566 413.57081428584286 148.96020140427527 413.39624990289167 148.4169215664825 L412.0707908340851 144.21481552911428 L415.46521099638267 141.62212599468145 C415.8983492135869 141.29199528429405 416.08586144062093 140.92751305243198 415.9630112632787 140.5423734917523 C415.84016108593653 140.16411945859954 415.4975048389715 139.97841990793094 414.9608624429311 139.98529797308925 L410.79711893229756 140.0127871003797 L409.5298486926934 135.7901323116573 C409.368230750721 135.23995052912662 409.10310933146445 134.94422562894562 408.72168461831717 134.94422562894562 C408.3466601642492 134.94422562894562 408.08161240795476 135.23995052912662 407.91344758253086 135.7901323116573 L406.6462503043368 140.0127871003797 L402.48246294670196 139.98529797308925 C401.9458205506616 139.97841990793094 401.6096154252973 140.16411945859954 401.48677226347536 140.5423734917523 C401.3639294524294 140.92751305243198 401.5449607419017 141.29199528429405 401.98461778047664 141.62212599468145 L405.37900882836544 144.21481552911428 L404.0471126689985 148.4169215664825 C403.8725402181991 148.96020140427527 403.9371945508187 149.35911276624566 404.24107636840927 149.59980549623245 Z M408.72168461831717 145.37711973868025 L408.72168461831717 136.99366610785623 C408.7410320199273 136.99366610785623 408.7475052404166 137.00054417301453 408.7604523829474 137.04180472847727 L409.79497011194997 140.79683802302978 C409.89192600423064 141.14066217983736 410.0664910887338 141.25756540794885 410.39620019316806 141.24387196152867 L414.0750898778843 141.15443398112805 C414.11393060392464 141.15443398112805 414.1268040834933 141.16132025489185 414.1332780055347 141.17509205618254 C414.1397519275761 141.19567103012963 414.1332780055347 141.20255730389343 414.10098416294585 141.22321463271106 L411.06864061063345 143.43772848886164 C410.771224647236 143.65087761626702 410.7324568826058 143.857219571016 410.8423606189692 144.1942358089303 L412.0707908340851 147.8873351751099 C412.0837372750638 147.92168595034772 412.0837372750638 147.9285722241115 412.0707908340851 147.94234477163906 C412.05784299000226 147.9630021004567 412.0449695104336 147.94922955292913 412.01907522537203 147.9354584978753 L409.10310933146445 145.542147035794 C408.97385889504295 145.4321293352094 408.84453479565934 145.37711973868025 408.72168461831717 145.37711973868025 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="400.44914435596866" y="133.94422562894562" width="18.67217407280769" height="18.920428848808665" color-interpolation-filters="sRGB" id="s-Path_13-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_13-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_13-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="$ 123.456,34"   datasizewidth="93.4px" datasizeheight="18.0px" dataX="87.6" dataY="361.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_3_0">$ 123.456,34</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_43" class="richtext manualfit firer ie-background commentable non-processed" customid="Precio"   datasizewidth="96.8px" datasizeheight="18.0px" dataX="30.8" dataY="361.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_43_0">Precio</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Group 9" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Group 7" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Paragraph_7" class="richtext manualfit firer ie-background commentable non-processed" customid="-"   datasizewidth="25.3px" datasizeheight="18.0px" dataX="202.0" dataY="326.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_7_0">-</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_41" class="richtext manualfit firer ie-background commentable non-processed" customid="Oct 22 2022 10:53"   datasizewidth="115.2px" datasizeheight="16.0px" dataX="82.8" dataY="328.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_41_0">Oct 22 2022 10:53</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_42" class="richtext autofit firer ie-background commentable non-processed" customid="Oct 30 2022 23:50"   datasizewidth="115.2px" datasizeheight="16.0px" dataX="230.5" dataY="328.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_42_0">Oct 30 2022 23:50</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Group 4" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_6" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="406.3px" datasizeheight="278.0px" datasizewidthpx="406.3285827636726" datasizeheightpx="278.00000000000057" dataX="486.2" dataY="119.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_6_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="405.0px" datasizeheight="139.3px" dataX="487.5" dataY="119.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/f46260ae-0052-412f-b122-59a0603c1924.jpg" />\
            	</div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Villa Maria"   datasizewidth="375.7px" datasizeheight="21.3px" dataX="503.8" dataY="296.8" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_2_0">Villa Maria</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Hotel Abudabi"   datasizewidth="379.0px" datasizeheight="23.4px" dataX="498.6" dataY="270.4" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_4_0">Hotel Abudabi</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="99.3px" datasizeheight="32.0px" dataX="780.2" dataY="354.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Button_3_0">Ver detalle</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Group 8" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Path_7" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="811.9" dataY="135.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="811.9205430456143 134.95298551836572 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_7-22eef" d="M814.7098199655891 149.62381174743115 C814.9564744275808 149.81517090486068 815.2545238948378 149.75504947935076 815.6193706923215 149.47077641921078 L819.1959327136724 146.68309558132935 L822.7724631492908 149.47077641921078 C823.1373415325071 149.75504947935076 823.440498442248 149.81517090486068 823.6820578598938 149.62381174743115 C823.9184171442141 149.4325179011516 823.9749384843642 149.115517674961 823.8310669482528 148.6563476351336 L822.4282010984682 144.18515196047102 L826.0304234280377 141.43026297179836 C826.3953006304789 141.15147542026358 826.5391721665903 140.8617758827501 826.4415456853585 140.5556801066363 C826.3490567563745 140.26050887633775 826.081806035165 140.1019955754141 825.6193637517946 140.10746098828088 L821.2000356406062 140.13479496052477 L819.8485523979489 135.64716992069305 C819.7098195948603 135.18255935217502 819.4939508903906 134.95298551836572 819.1959327136724 134.95298551836572 C818.8979139465667 134.95298551836572 818.6820458324846 135.18255935217502 818.543313029396 135.64716992069305 L817.1918232924759 140.13479496052477 L812.7725142212852 140.10746098828088 C812.3151673143536 140.1019955754141 812.0428147224426 140.26050887633775 811.9503173158625 140.5556801066363 C811.8526815406397 140.8617758827501 811.9965661436875 141.15147542026358 812.3614159115583 141.43026297179836 L815.9636705279457 144.18515196047102 L814.5659304226582 148.6563476351336 C814.4169089361611 149.115517674961 814.4734355897989 149.4325179011516 814.7098199655891 149.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="810.9205430456143" y="133.95298551836572" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_7-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_7-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_8" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="843.3" dataY="135.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="843.2657633811355 134.95298551836572 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_8-22eef" d="M846.0550403011104 149.62381174743115 C846.301694763102 149.81517090486068 846.599744230359 149.75504947935076 846.9645910278426 149.47077641921078 L850.5411530491937 146.68309558132935 L854.1176834848121 149.47077641921078 C854.4825618680284 149.75504947935076 854.7857187777693 149.81517090486068 855.0272781954151 149.62381174743115 C855.2636374797355 149.4325179011516 855.3201588198855 149.115517674961 855.1762872837742 148.6563476351336 L853.7734214339895 144.18515196047102 L857.3756437635591 141.43026297179836 C857.7405209660003 141.15147542026358 857.8843925021117 140.8617758827501 857.7867660208799 140.5556801066363 C857.6942770918959 140.26050887633775 857.4270263706863 140.1019955754141 856.964584087316 140.10746098828088 L852.5452559761276 140.13479496052477 L851.1937727334702 135.64716992069305 C851.0550399303816 135.18255935217502 850.8391712259119 134.95298551836572 850.5411530491937 134.95298551836572 C850.243134282088 134.95298551836572 850.0272661680059 135.18255935217502 849.8885333649173 135.64716992069305 L848.537043627997 140.13479496052477 L844.1177345568063 140.10746098828088 C843.6603876498748 140.1019955754141 843.3880350579637 140.26050887633775 843.2955376513837 140.5556801066363 C843.1979018761608 140.8617758827501 843.3417864792086 141.15147542026358 843.7066362470795 141.43026297179836 L847.3088908634669 144.18515196047102 L845.9111507581795 148.6563476351336 C845.7621292716823 149.115517674961 845.8186559253201 149.4325179011516 846.0550403011104 149.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="842.2657633811355" y="133.95298551836572" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_8-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_8-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_14" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="827.4" dataY="135.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="827.3687858770138 134.95298551836572 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_14-22eef" d="M830.1580627969886 149.62381174743115 C830.4047172589803 149.81517090486068 830.7027667262373 149.75504947935076 831.067613523721 149.47077641921078 L834.6441755450719 146.68309558132935 L838.2207059806904 149.47077641921078 C838.5855843639066 149.75504947935076 838.8887412736475 149.81517090486068 839.1303006912933 149.62381174743115 C839.3666599756136 149.4325179011516 839.4231813157637 149.115517674961 839.2793097796523 148.6563476351336 L837.8764439298677 144.18515196047102 L841.4786662594372 141.43026297179836 C841.8435434618784 141.15147542026358 841.9874149979898 140.8617758827501 841.889788516758 140.5556801066363 C841.797299587774 140.26050887633775 841.5300488665645 140.1019955754141 841.0676065831941 140.10746098828088 L836.6482784720057 140.13479496052477 L835.2967952293484 135.64716992069305 C835.1580624262598 135.18255935217502 834.9421937217901 134.95298551836572 834.6441755450719 134.95298551836572 C834.3461567779663 134.95298551836572 834.1302886638841 135.18255935217502 833.9915558607955 135.64716992069305 L832.6400661238754 140.13479496052477 L828.2207570526847 140.10746098828088 C827.7634101457531 140.1019955754141 827.4910575538421 140.26050887633775 827.3985601472621 140.5556801066363 C827.3009243720392 140.8617758827501 827.444808975087 141.15147542026358 827.8096587429578 141.43026297179836 L831.4119133593452 144.18515196047102 L830.0141732540577 148.6563476351336 C829.8651517675606 149.115517674961 829.9216784211984 149.4325179011516 830.1580627969886 149.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="826.3687858770138" y="133.95298551836572" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_14-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_14-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_15" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="858.9" dataY="135.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="858.8748023845335 134.95298551836572 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_15-22eef" d="M861.6640793045083 149.62381174743115 C861.9107337665 149.81517090486068 862.208783233757 149.75504947935076 862.5736300312407 149.47077641921078 L866.1501920525916 146.68309558132935 L869.72672248821 149.47077641921078 C870.0916008714263 149.75504947935076 870.3947577811672 149.81517090486068 870.636317198813 149.62381174743115 C870.8726764831333 149.4325179011516 870.9291978232834 149.115517674961 870.785326287172 148.6563476351336 L869.3824604373874 144.18515196047102 L872.9846827669569 141.43026297179836 C873.3495599693981 141.15147542026358 873.4934315055095 140.8617758827501 873.3958050242777 140.5556801066363 C873.3033160952937 140.26050887633775 873.0360653740842 140.1019955754141 872.5736230907138 140.10746098828088 L868.1542949795254 140.13479496052477 L866.8028117368681 135.64716992069305 C866.6640789337795 135.18255935217502 866.4482102293098 134.95298551836572 866.1501920525916 134.95298551836572 C865.852173285486 134.95298551836572 865.6363051714038 135.18255935217502 865.4975723683152 135.64716992069305 L864.1460826313951 140.13479496052477 L859.7267735602044 140.10746098828088 C859.2694266532728 140.1019955754141 858.9970740613618 140.26050887633775 858.9045766547817 140.5556801066363 C858.8069408795589 140.8617758827501 858.9508254826067 141.15147542026358 859.3156752504775 141.43026297179836 L862.9179298668649 144.18515196047102 L861.5201897615774 148.6563476351336 C861.3711682750803 149.115517674961 861.4276949287181 149.4325179011516 861.6640793045083 149.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="857.8748023845335" y="133.95298551836572" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_15-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_15-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_16" class="path firer commentable non-processed" customid="Star half"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="874.4" dataY="134.9"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550853729248047" height="14.799108505249023" viewBox="874.4491443559687 134.94422562894562 14.550853729248047 14.799108505249023" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_16-22eef" d="M877.2410763684093 149.59980549623245 C877.5449581859998 149.847384499983 877.919953174883 149.7648327933462 878.3596102134579 149.42789341782867 L881.7216846183172 146.800696398417 L885.0837372750639 149.42789341782867 C885.5233508174135 149.7648327933462 885.9048477904189 149.847384499983 886.2087376758577 149.59980549623245 C886.506152236151 149.35911276624566 886.5708142858429 148.96020140427527 886.3962499028917 148.4169215664825 L885.0707908340851 144.21481552911428 L888.4652109963827 141.62212599468145 C888.8983492135869 141.29199528429405 889.0858614406209 140.92751305243198 888.9630112632788 140.5423734917523 C888.8401610859365 140.16411945859954 888.4975048389715 139.97841990793094 887.9608624429311 139.98529797308925 L883.7971189322976 140.0127871003797 L882.5298486926935 135.7901323116573 C882.368230750721 135.23995052912662 882.1031093314645 134.94422562894562 881.7216846183172 134.94422562894562 C881.3466601642492 134.94422562894562 881.0816124079547 135.23995052912662 880.9134475825308 135.7901323116573 L879.6462503043367 140.0127871003797 L875.482462946702 139.98529797308925 C874.9458205506616 139.97841990793094 874.6096154252973 140.16411945859954 874.4867722634754 140.5423734917523 C874.3639294524294 140.92751305243198 874.5449607419017 141.29199528429405 874.9846177804767 141.62212599468145 L878.3790088283654 144.21481552911428 L877.0471126689985 148.4169215664825 C876.8725402181991 148.96020140427527 876.9371945508186 149.35911276624566 877.2410763684093 149.59980549623245 Z M881.7216846183172 145.37711973868025 L881.7216846183172 136.99366610785623 C881.7410320199273 136.99366610785623 881.7475052404167 137.00054417301453 881.7604523829474 137.04180472847727 L882.79497011195 140.79683802302978 C882.8919260042306 141.14066217983736 883.0664910887339 141.25756540794885 883.396200193168 141.24387196152867 L887.0750898778844 141.15443398112805 C887.1139306039246 141.15443398112805 887.1268040834933 141.16132025489185 887.1332780055347 141.17509205618254 C887.1397519275761 141.19567103012963 887.1332780055347 141.20255730389343 887.1009841629459 141.22321463271106 L884.0686406106335 143.43772848886164 C883.7712246472361 143.65087761626702 883.7324568826058 143.857219571016 883.8423606189692 144.1942358089303 L885.0707908340851 147.8873351751099 C885.0837372750639 147.92168595034772 885.0837372750639 147.9285722241115 885.0707908340851 147.94234477163906 C885.0578429900023 147.9630021004567 885.0449695104336 147.94922955292913 885.019075225372 147.9354584978753 L882.1031093314645 145.542147035794 C881.973858895043 145.4321293352094 881.8445347956593 145.37711973868025 881.7216846183172 145.37711973868025 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="873.4491443559687" y="133.94422562894562" width="18.67217407280769" height="18.920428848808665" color-interpolation-filters="sRGB" id="s-Path_16-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_16-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="$ 123.456,34"   datasizewidth="93.4px" datasizeheight="18.0px" dataX="560.6" dataY="361.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_5_0">$ 123.456,34</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_20" class="richtext manualfit firer ie-background commentable non-processed" customid="Precio"   datasizewidth="96.8px" datasizeheight="18.0px" dataX="503.8" dataY="361.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_20_0">Precio</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_11" class="group firer ie-background commentable non-processed" customid="Group 9" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Group_13" class="group firer ie-background commentable non-processed" customid="Group 7" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Paragraph_21" class="richtext manualfit firer ie-background commentable non-processed" customid="-"   datasizewidth="25.3px" datasizeheight="18.0px" dataX="675.0" dataY="326.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_21_0">-</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_22" class="richtext manualfit firer ie-background commentable non-processed" customid="Oct 22 2022 10:53"   datasizewidth="115.2px" datasizeheight="16.0px" dataX="555.8" dataY="328.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_22_0">Oct 22 2022 10:53</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_23" class="richtext autofit firer ie-background commentable non-processed" customid="Oct 30 2022 23:50"   datasizewidth="115.2px" datasizeheight="16.0px" dataX="703.5" dataY="328.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_23_0">Oct 30 2022 23:50</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_16" class="group firer ie-background commentable non-processed" customid="Group 4" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_17" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_7" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="406.3px" datasizeheight="278.0px" datasizewidthpx="406.3285827636726" datasizeheightpx="278.00000000000057" dataX="11.2" dataY="427.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_7_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="405.0px" datasizeheight="139.3px" dataX="12.5" dataY="427.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/f0633b41-0c69-437d-8207-d603894678aa.jpg" />\
            	</div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_24" class="richtext manualfit firer ie-background commentable non-processed" customid="Mar del Plata"   datasizewidth="375.7px" datasizeheight="21.3px" dataX="28.8" dataY="604.8" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_24_0">Mar del Plata</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_25" class="richtext manualfit firer ie-background commentable non-processed" customid="Do&ntilde;a Maria"   datasizewidth="379.0px" datasizeheight="23.4px" dataX="23.6" dataY="578.4" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_25_0">Do&ntilde;a Maria</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="99.3px" datasizeheight="32.0px" dataX="305.2" dataY="662.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Button_4_0">Ver detalle</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_19" class="group firer ie-background commentable non-processed" customid="Group 8" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Path_17" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="336.9" dataY="443.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="336.9205430456143 442.9529855183657 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_17-22eef" d="M339.70981996558913 457.62381174743115 C339.95647442758076 457.8151709048607 340.25452389483775 457.75504947935076 340.6193706923214 457.4707764192108 L344.1959327136724 454.6830955813294 L347.7724631492908 457.4707764192108 C348.1373415325071 457.75504947935076 348.44049844224793 457.8151709048607 348.68205785989375 457.62381174743115 C348.9184171442142 457.43251790115164 348.9749384843642 457.115517674961 348.83106694825284 456.6563476351336 L347.42820109846815 452.18515196047105 L351.0304234280377 449.43026297179836 C351.39530063047897 449.1514754202636 351.53917216659033 448.86177588275007 351.4415456853585 448.5556801066363 C351.3490567563744 448.2605088763378 351.08180603516496 448.1019955754141 350.61936375179465 448.1074609882809 L346.20003564060625 448.1347949605248 L344.8485523979488 443.64716992069305 C344.7098195948602 443.182559352175 344.4939508903905 442.9529855183657 344.1959327136724 442.9529855183657 C343.8979139465668 442.9529855183657 343.6820458324846 443.182559352175 343.543313029396 443.64716992069305 L342.1918232924758 448.1347949605248 L337.7725142212851 448.1074609882809 C337.31516731435363 448.1019955754141 337.04281472244253 448.2605088763378 336.9503173158626 448.5556801066363 C336.85268154063965 448.86177588275007 336.99656614368746 449.1514754202636 337.3614159115583 449.43026297179836 L340.9636705279457 452.18515196047105 L339.56593042265825 456.6563476351336 C339.4169089361611 457.115517674961 339.4734355897989 457.43251790115164 339.70981996558913 457.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="335.9205430456143" y="441.9529855183657" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_17-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_17-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_18" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="368.3" dataY="443.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="368.26576338113546 442.9529855183657 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_18-22eef" d="M371.0550403011103 457.62381174743115 C371.301694763102 457.8151709048607 371.59974423035897 457.75504947935076 371.96459102784263 457.4707764192108 L375.54115304919367 454.6830955813294 L379.1176834848121 457.4707764192108 C379.4825618680284 457.75504947935076 379.78571877776926 457.8151709048607 380.0272781954151 457.62381174743115 C380.2636374797355 457.43251790115164 380.32015881988553 457.115517674961 380.1762872837742 456.6563476351336 L378.7734214339895 452.18515196047105 L382.3756437635591 449.43026297179836 C382.74052096600036 449.1514754202636 382.8843925021117 448.86177588275007 382.7867660208799 448.5556801066363 C382.6942770918958 448.2605088763378 382.42702637068635 448.1019955754141 381.964584087316 448.1074609882809 L377.5452559761275 448.1347949605248 L376.19377273347015 443.64716992069305 C376.0550399303815 443.182559352175 375.8391712259118 442.9529855183657 375.54115304919367 442.9529855183657 C375.2431342820881 442.9529855183657 375.0272661680059 443.182559352175 374.88853336491724 443.64716992069305 L373.5370436279971 448.1347949605248 L369.1177345568063 448.1074609882809 C368.6603876498748 448.1019955754141 368.3880350579637 448.2605088763378 368.29553765138377 448.5556801066363 C368.1979018761608 448.86177588275007 368.3417864792086 449.1514754202636 368.70663624707953 449.43026297179836 L372.3088908634669 452.18515196047105 L370.9111507581794 456.6563476351336 C370.76212927168234 457.115517674961 370.81865592532006 457.43251790115164 371.0550403011103 457.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="367.26576338113546" y="441.9529855183657" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_18-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_18-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_18-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_28" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="352.4" dataY="443.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="352.3687858770138 442.9529855183657 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_28-22eef" d="M355.15806279698865 457.62381174743115 C355.40471725898027 457.8151709048607 355.70276672623726 457.75504947935076 356.0676135237209 457.4707764192108 L359.6441755450719 454.6830955813294 L363.2207059806903 457.4707764192108 C363.5855843639066 457.75504947935076 363.88874127364744 457.8151709048607 364.13030069129326 457.62381174743115 C364.3666599756137 457.43251790115164 364.4231813157637 457.115517674961 364.27930977965235 456.6563476351336 L362.87644392986766 452.18515196047105 L366.4786662594372 449.43026297179836 C366.8435434618785 449.1514754202636 366.98741499798984 448.86177588275007 366.889788516758 448.5556801066363 C366.7972995877739 448.2605088763378 366.53004886656447 448.1019955754141 366.06760658319416 448.1074609882809 L361.64827847200576 448.1347949605248 L360.29679522934833 443.64716992069305 C360.15806242625973 443.182559352175 359.94219372179003 442.9529855183657 359.6441755450719 442.9529855183657 C359.3461567779663 442.9529855183657 359.13028866388413 443.182559352175 358.99155586079553 443.64716992069305 L357.64006612387533 448.1347949605248 L353.22075705268463 448.1074609882809 C352.76341014575314 448.1019955754141 352.49105755384204 448.2605088763378 352.3985601472621 448.5556801066363 C352.30092437203916 448.86177588275007 352.44480897508697 449.1514754202636 352.8096587429578 449.43026297179836 L356.4119133593452 452.18515196047105 L355.01417325405777 456.6563476351336 C354.86515176756063 457.115517674961 354.9216784211984 457.43251790115164 355.15806279698865 457.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="351.3687858770138" y="441.9529855183657" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_28-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_28-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_28-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_35" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="383.9" dataY="443.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="383.8748023845335 442.9529855183657 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_35-22eef" d="M386.66407930450833 457.62381174743115 C386.91073376649996 457.8151709048607 387.20878323375695 457.75504947935076 387.5736300312406 457.4707764192108 L391.1501920525916 454.6830955813294 L394.72672248821 457.4707764192108 C395.0916008714263 457.75504947935076 395.39475778116713 457.8151709048607 395.63631719881295 457.62381174743115 C395.8726764831334 457.43251790115164 395.9291978232834 457.115517674961 395.78532628717204 456.6563476351336 L394.38246043738735 452.18515196047105 L397.9846827669569 449.43026297179836 C398.3495599693982 449.1514754202636 398.49343150550953 448.86177588275007 398.3958050242777 448.5556801066363 C398.3033160952936 448.2605088763378 398.03606537408416 448.1019955754141 397.57362309071385 448.1074609882809 L393.15429497952545 448.1347949605248 L391.802811736868 443.64716992069305 C391.6640789337794 443.182559352175 391.4482102293097 442.9529855183657 391.1501920525916 442.9529855183657 C390.852173285486 442.9529855183657 390.6363051714038 443.182559352175 390.4975723683152 443.64716992069305 L389.146082631395 448.1347949605248 L384.7267735602043 448.1074609882809 C384.26942665327283 448.1019955754141 383.99707406136173 448.2605088763378 383.9045766547818 448.5556801066363 C383.80694087955885 448.86177588275007 383.95082548260666 449.1514754202636 384.3156752504775 449.43026297179836 L387.9179298668649 452.18515196047105 L386.52018976157746 456.6563476351336 C386.3711682750803 457.115517674961 386.4276949287181 457.43251790115164 386.66407930450833 457.62381174743115 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="382.8748023845335" y="441.9529855183657" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_35-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_35-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_35-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_36" class="path firer commentable non-processed" customid="Star half"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="399.4" dataY="442.9"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550853729248047" height="14.799108505249023" viewBox="399.44914435596866 442.9442256289456 14.550853729248047 14.799108505249023" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_36-22eef" d="M402.24107636840927 457.5998054962324 C402.54495818599986 457.84738449998304 402.91995317488295 457.76483279334616 403.35961021345787 457.42789341782867 L406.72168461831717 454.80069639841696 L410.0837372750638 457.42789341782867 C410.52335081741353 457.76483279334616 410.90484779041884 457.84738449998304 411.20873767585766 457.5998054962324 C411.506152236151 457.3591127662457 411.57081428584286 456.96020140427527 411.39624990289167 456.41692156648253 L410.0707908340851 452.2148155291143 L413.46521099638267 449.6221259946814 C413.8983492135869 449.29199528429405 414.08586144062093 448.927513052432 413.9630112632787 448.5423734917523 C413.84016108593653 448.16411945859954 413.4975048389715 447.9784199079309 412.9608624429311 447.98529797308925 L408.79711893229756 448.0127871003797 L407.5298486926934 443.7901323116573 C407.368230750721 443.23995052912665 407.10310933146445 442.9442256289456 406.72168461831717 442.9442256289456 C406.3466601642492 442.9442256289456 406.08161240795476 443.23995052912665 405.91344758253086 443.7901323116573 L404.6462503043368 448.0127871003797 L400.48246294670196 447.98529797308925 C399.9458205506616 447.9784199079309 399.6096154252973 448.16411945859954 399.48677226347536 448.5423734917523 C399.3639294524294 448.927513052432 399.5449607419017 449.29199528429405 399.98461778047664 449.6221259946814 L403.37900882836544 452.2148155291143 L402.0471126689985 456.41692156648253 C401.8725402181991 456.96020140427527 401.9371945508187 457.3591127662457 402.24107636840927 457.5998054962324 Z M406.72168461831717 453.3771197386803 L406.72168461831717 444.99366610785626 C406.7410320199273 444.99366610785626 406.7475052404166 445.00054417301453 406.7604523829474 445.0418047284773 L407.79497011194997 448.7968380230298 C407.89192600423064 449.14066217983736 408.0664910887338 449.25756540794885 408.39620019316806 449.24387196152867 L412.0750898778843 449.1544339811281 C412.11393060392464 449.1544339811281 412.1268040834933 449.16132025489185 412.1332780055347 449.17509205618256 C412.1397519275761 449.19567103012963 412.1332780055347 449.2025573038934 412.10098416294585 449.22321463271106 L409.06864061063345 451.43772848886164 C408.771224647236 451.650877616267 408.7324568826058 451.857219571016 408.8423606189692 452.19423580893033 L410.0707908340851 455.8873351751099 C410.0837372750638 455.9216859503477 410.0837372750638 455.9285722241115 410.0707908340851 455.94234477163906 C410.05784299000226 455.96300210045666 410.0449695104336 455.9492295529291 410.01907522537203 455.9354584978753 L407.10310933146445 453.54214703579396 C406.97385889504295 453.4321293352094 406.84453479565934 453.3771197386803 406.72168461831717 453.3771197386803 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="398.44914435596866" y="441.9442256289456" width="18.67217407280769" height="18.920428848808665" color-interpolation-filters="sRGB" id="s-Path_36-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_36-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_36-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_26" class="richtext manualfit firer ie-background commentable non-processed" customid="$ 123.456,34"   datasizewidth="93.4px" datasizeheight="18.0px" dataX="85.6" dataY="669.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_26_0">$ 123.456,34</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_27" class="richtext manualfit firer ie-background commentable non-processed" customid="Precio"   datasizewidth="96.8px" datasizeheight="18.0px" dataX="28.8" dataY="669.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_27_0">Precio</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_20" class="group firer ie-background commentable non-processed" customid="Group 9" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Group_21" class="group firer ie-background commentable non-processed" customid="Group 7" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Paragraph_28" class="richtext manualfit firer ie-background commentable non-processed" customid="-"   datasizewidth="25.3px" datasizeheight="18.0px" dataX="200.0" dataY="634.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_28_0">-</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_29" class="richtext manualfit firer ie-background commentable non-processed" customid="Oct 22 2022 10:53"   datasizewidth="115.2px" datasizeheight="16.0px" dataX="80.8" dataY="636.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_29_0">Oct 22 2022 10:53</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_30" class="richtext autofit firer ie-background commentable non-processed" customid="Oct 30 2022 23:50"   datasizewidth="115.2px" datasizeheight="16.0px" dataX="228.5" dataY="636.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_30_0">Oct 30 2022 23:50</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 4" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="406.3px" datasizeheight="278.0px" datasizewidthpx="406.3285827636726" datasizeheightpx="278.00000000000057" dataX="9.2" dataY="728.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_4_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="405.0px" datasizeheight="139.3px" dataX="10.5" dataY="728.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/dda7dfac-b67a-4327-bca2-2a9aa5d1145e.jpg" />\
            	</div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_13" class="richtext manualfit firer ie-background commentable non-processed" customid="Catamarca Capital"   datasizewidth="375.7px" datasizeheight="21.3px" dataX="26.8" dataY="905.8" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_13_0">Catamarca Capital</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_14" class="richtext manualfit firer ie-background commentable non-processed" customid="Provence"   datasizewidth="379.0px" datasizeheight="23.4px" dataX="21.6" dataY="879.4" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_14_0">Provence</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="99.3px" datasizeheight="32.0px" dataX="303.2" dataY="963.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Button_2_0">Ver detalle</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_22" class="group firer ie-background commentable non-processed" customid="Group 8" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Path_5" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="334.9" dataY="744.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="334.9205430456143 743.9529855183657 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_5-22eef" d="M337.70981996558913 758.6238117474312 C337.95647442758076 758.8151709048607 338.25452389483775 758.7550494793508 338.6193706923214 758.4707764192108 L342.1959327136724 755.6830955813293 L345.7724631492908 758.4707764192108 C346.1373415325071 758.7550494793508 346.44049844224793 758.8151709048607 346.68205785989375 758.6238117474312 C346.9184171442142 758.4325179011516 346.9749384843642 758.115517674961 346.83106694825284 757.6563476351336 L345.42820109846815 753.185151960471 L349.0304234280377 750.4302629717984 C349.39530063047897 750.1514754202636 349.53917216659033 749.8617758827501 349.4415456853585 749.5556801066363 C349.3490567563744 749.2605088763378 349.08180603516496 749.1019955754141 348.61936375179465 749.1074609882809 L344.20003564060625 749.1347949605248 L342.8485523979488 744.647169920693 C342.7098195948602 744.182559352175 342.4939508903905 743.9529855183657 342.1959327136724 743.9529855183657 C341.8979139465668 743.9529855183657 341.6820458324846 744.182559352175 341.543313029396 744.647169920693 L340.1918232924758 749.1347949605248 L335.7725142212851 749.1074609882809 C335.31516731435363 749.1019955754141 335.04281472244253 749.2605088763378 334.9503173158626 749.5556801066363 C334.85268154063965 749.8617758827501 334.99656614368746 750.1514754202636 335.3614159115583 750.4302629717984 L338.9636705279457 753.185151960471 L337.56593042265825 757.6563476351336 C337.4169089361611 758.115517674961 337.4734355897989 758.4325179011516 337.70981996558913 758.6238117474312 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="333.9205430456143" y="742.9529855183657" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_5-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_5-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_19" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="366.3" dataY="744.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="366.26576338113546 743.9529855183657 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_19-22eef" d="M369.0550403011103 758.6238117474312 C369.301694763102 758.8151709048607 369.59974423035897 758.7550494793508 369.96459102784263 758.4707764192108 L373.54115304919367 755.6830955813293 L377.1176834848121 758.4707764192108 C377.4825618680284 758.7550494793508 377.78571877776926 758.8151709048607 378.0272781954151 758.6238117474312 C378.2636374797355 758.4325179011516 378.32015881988553 758.115517674961 378.1762872837742 757.6563476351336 L376.7734214339895 753.185151960471 L380.3756437635591 750.4302629717984 C380.74052096600036 750.1514754202636 380.8843925021117 749.8617758827501 380.7867660208799 749.5556801066363 C380.6942770918958 749.2605088763378 380.42702637068635 749.1019955754141 379.964584087316 749.1074609882809 L375.5452559761275 749.1347949605248 L374.19377273347015 744.647169920693 C374.0550399303815 744.182559352175 373.8391712259118 743.9529855183657 373.54115304919367 743.9529855183657 C373.2431342820881 743.9529855183657 373.0272661680059 744.182559352175 372.88853336491724 744.647169920693 L371.5370436279971 749.1347949605248 L367.1177345568063 749.1074609882809 C366.6603876498748 749.1019955754141 366.3880350579637 749.2605088763378 366.29553765138377 749.5556801066363 C366.1979018761608 749.8617758827501 366.3417864792086 750.1514754202636 366.70663624707953 750.4302629717984 L370.3088908634669 753.185151960471 L368.9111507581794 757.6563476351336 C368.76212927168234 758.115517674961 368.81865592532006 758.4325179011516 369.0550403011103 758.6238117474312 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="365.26576338113546" y="742.9529855183657" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_19-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_19-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_19-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_20" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="350.4" dataY="744.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="350.3687858770138 743.9529855183657 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_20-22eef" d="M353.15806279698865 758.6238117474312 C353.40471725898027 758.8151709048607 353.70276672623726 758.7550494793508 354.0676135237209 758.4707764192108 L357.6441755450719 755.6830955813293 L361.2207059806903 758.4707764192108 C361.5855843639066 758.7550494793508 361.88874127364744 758.8151709048607 362.13030069129326 758.6238117474312 C362.3666599756137 758.4325179011516 362.4231813157637 758.115517674961 362.27930977965235 757.6563476351336 L360.87644392986766 753.185151960471 L364.4786662594372 750.4302629717984 C364.8435434618785 750.1514754202636 364.98741499798984 749.8617758827501 364.889788516758 749.5556801066363 C364.7972995877739 749.2605088763378 364.53004886656447 749.1019955754141 364.06760658319416 749.1074609882809 L359.64827847200576 749.1347949605248 L358.29679522934833 744.647169920693 C358.15806242625973 744.182559352175 357.94219372179003 743.9529855183657 357.6441755450719 743.9529855183657 C357.3461567779663 743.9529855183657 357.13028866388413 744.182559352175 356.99155586079553 744.647169920693 L355.64006612387533 749.1347949605248 L351.22075705268463 749.1074609882809 C350.76341014575314 749.1019955754141 350.49105755384204 749.2605088763378 350.3985601472621 749.5556801066363 C350.30092437203916 749.8617758827501 350.44480897508697 750.1514754202636 350.8096587429578 750.4302629717984 L354.4119133593452 753.185151960471 L353.01417325405777 757.6563476351336 C352.86515176756063 758.115517674961 352.9216784211984 758.4325179011516 353.15806279698865 758.6238117474312 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="349.3687858770138" y="742.9529855183657" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_20-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_20-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_20-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_21" class="path firer commentable non-processed" customid="Star"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="381.9" dataY="744.0"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550774574279785" height="14.781588554382324" viewBox="381.8748023845335 743.9529855183657 14.550774574279785 14.781588554382324" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_21-22eef" d="M384.66407930450833 758.6238117474312 C384.91073376649996 758.8151709048607 385.20878323375695 758.7550494793508 385.5736300312406 758.4707764192108 L389.1501920525916 755.6830955813293 L392.72672248821 758.4707764192108 C393.0916008714263 758.7550494793508 393.39475778116713 758.8151709048607 393.63631719881295 758.6238117474312 C393.8726764831334 758.4325179011516 393.9291978232834 758.115517674961 393.78532628717204 757.6563476351336 L392.38246043738735 753.185151960471 L395.9846827669569 750.4302629717984 C396.3495599693982 750.1514754202636 396.49343150550953 749.8617758827501 396.3958050242777 749.5556801066363 C396.3033160952936 749.2605088763378 396.03606537408416 749.1019955754141 395.57362309071385 749.1074609882809 L391.15429497952545 749.1347949605248 L389.802811736868 744.647169920693 C389.6640789337794 744.182559352175 389.4482102293097 743.9529855183657 389.1501920525916 743.9529855183657 C388.852173285486 743.9529855183657 388.6363051714038 744.182559352175 388.4975723683152 744.647169920693 L387.146082631395 749.1347949605248 L382.7267735602043 749.1074609882809 C382.26942665327283 749.1019955754141 381.99707406136173 749.2605088763378 381.9045766547818 749.5556801066363 C381.80694087955885 749.8617758827501 381.95082548260666 750.1514754202636 382.3156752504775 750.4302629717984 L385.9179298668649 753.185151960471 L384.52018976157746 757.6563476351336 C384.3711682750803 758.115517674961 384.4276949287181 758.4325179011516 384.66407930450833 758.6238117474312 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="380.8748023845335" y="742.9529855183657" width="18.672094917839427" height="18.902908897941966" color-interpolation-filters="sRGB" id="s-Path_21-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_21-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_21-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_22" class="path firer commentable non-processed" customid="Star half"   datasizewidth="14.6px" datasizeheight="14.8px" dataX="397.4" dataY="743.9"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="14.550853729248047" height="14.799108505249023" viewBox="397.44914435596866 743.9442256289456 14.550853729248047 14.799108505249023" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_22-22eef" d="M400.24107636840927 758.5998054962324 C400.54495818599986 758.8473844999829 400.91995317488295 758.7648327933462 401.35961021345787 758.4278934178286 L404.72168461831717 755.8006963984169 L408.0837372750638 758.4278934178286 C408.52335081741353 758.7648327933462 408.90484779041884 758.8473844999829 409.20873767585766 758.5998054962324 C409.506152236151 758.3591127662456 409.57081428584286 757.9602014042753 409.39624990289167 757.4169215664824 L408.0707908340851 753.2148155291142 L411.46521099638267 750.6221259946814 C411.8983492135869 750.291995284294 412.08586144062093 749.9275130524319 411.9630112632787 749.5423734917522 C411.84016108593653 749.1641194585994 411.4975048389715 748.9784199079309 410.9608624429311 748.9852979730891 L406.79711893229756 749.0127871003797 L405.5298486926934 744.7901323116572 C405.368230750721 744.2399505291265 405.10310933146445 743.9442256289456 404.72168461831717 743.9442256289456 C404.3466601642492 743.9442256289456 404.08161240795476 744.2399505291265 403.91344758253086 744.7901323116572 L402.6462503043368 749.0127871003797 L398.48246294670196 748.9852979730891 C397.9458205506616 748.9784199079309 397.6096154252973 749.1641194585994 397.48677226347536 749.5423734917522 C397.3639294524294 749.9275130524319 397.5449607419017 750.291995284294 397.98461778047664 750.6221259946814 L401.37900882836544 753.2148155291142 L400.0471126689985 757.4169215664824 C399.8725402181991 757.9602014042753 399.9371945508187 758.3591127662456 400.24107636840927 758.5998054962324 Z M404.72168461831717 754.3771197386802 L404.72168461831717 745.9936661078561 C404.7410320199273 745.9936661078561 404.7475052404166 746.0005441730145 404.7604523829474 746.0418047284772 L405.79497011194997 749.7968380230297 C405.89192600423064 750.1406621798372 406.0664910887338 750.2575654079488 406.39620019316806 750.2438719615286 L410.0750898778843 750.154433981128 C410.11393060392464 750.154433981128 410.1268040834933 750.1613202548917 410.1332780055347 750.1750920561825 C410.1397519275761 750.1956710301296 410.1332780055347 750.2025573038934 410.10098416294585 750.223214632711 L407.06864061063345 752.4377284888616 C406.771224647236 752.6508776162669 406.7324568826058 752.8572195710159 406.8423606189692 753.1942358089302 L408.0707908340851 756.8873351751098 C408.0837372750638 756.9216859503476 408.0837372750638 756.9285722241115 408.0707908340851 756.942344771639 C408.05784299000226 756.9630021004566 408.0449695104336 756.9492295529291 408.01907522537203 756.9354584978752 L405.10310933146445 754.542147035794 C404.97385889504295 754.4321293352093 404.84453479565934 754.3771197386802 404.72168461831717 754.3771197386802 Z "></path>\
                	      <filter filterUnits="userSpaceOnUse" x="396.44914435596866" y="742.9442256289456" width="18.67217407280769" height="18.920428848808665" color-interpolation-filters="sRGB" id="s-Path_22-22eef_effects">\
                	        <feOffset dx="2.1213203435596424" dy="2.121320343559643" input="SourceAlpha"></feOffset>\
                	        <feGaussianBlur result="DROP_SHADOW_0_blur" stdDeviation="1"></feGaussianBlur>\
                	        <feFlood flood-color="#404040" flood-opacity="1.0"></feFlood>\
                	        <feComposite operator="in" in2="DROP_SHADOW_0_blur"></feComposite>\
                	        <feComposite in="SourceGraphic" result="DROP_SHADOW_0"></feComposite>\
                	      </filter>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal" filter="url(#s-Path_22-22eef_effects)">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_22-22eef" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_15" class="richtext manualfit firer ie-background commentable non-processed" customid="$ 123.456,34"   datasizewidth="93.4px" datasizeheight="18.0px" dataX="83.6" dataY="970.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_15_0">$ 123.456,34</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_16" class="richtext manualfit firer ie-background commentable non-processed" customid="Precio"   datasizewidth="96.8px" datasizeheight="18.0px" dataX="26.8" dataY="970.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_16_0">Precio</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_23" class="group firer ie-background commentable non-processed" customid="Group 9" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Group_24" class="group firer ie-background commentable non-processed" customid="Group 7" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Paragraph_17" class="richtext manualfit firer ie-background commentable non-processed" customid="-"   datasizewidth="25.3px" datasizeheight="18.0px" dataX="198.0" dataY="935.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_17_0">-</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_18" class="richtext manualfit firer ie-background commentable non-processed" customid="Oct 22 2022 10:53"   datasizewidth="115.2px" datasizeheight="16.0px" dataX="78.8" dataY="937.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_18_0">Oct 22 2022 10:53</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_19" class="richtext autofit firer ie-background commentable non-processed" customid="Oct 30 2022 23:50"   datasizewidth="115.2px" datasizeheight="16.0px" dataX="226.5" dataY="937.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_19_0">Oct 30 2022 23:50</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;