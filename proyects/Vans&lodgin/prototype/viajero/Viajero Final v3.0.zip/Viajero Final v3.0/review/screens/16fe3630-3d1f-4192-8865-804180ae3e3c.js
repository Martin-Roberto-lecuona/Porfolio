var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-16fe3630-3d1f-4192-8865-804180ae3e3c" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="viaje_buscarReserva" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/16fe3630-3d1f-4192-8865-804180ae3e3c-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="428.0px" datasizeheight="926.0px" datasizewidthpx="427.9999999999998" datasizeheightpx="925.9999999999993" dataX="0.0" dataY="-0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Busc&aacute; tu destino deseado"   datasizewidth="225.6px" datasizeheight="20.0px" dataX="20.5" dataY="123.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Busc&aacute; tu destino deseado</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="a"   datasizewidth="54.3px" datasizeheight="18.0px" dataX="207.8" dataY="367.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">a</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Buscar"   datasizewidth="385.6px" datasizeheight="45.0px" dataX="15.0" dataY="545.3" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Buscar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Cancelar"   datasizewidth="385.6px" datasizeheight="45.0px" dataX="15.0" dataY="601.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Cancelar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="text firer focusout pageload commentable non-processed" customid="Input 1"  datasizewidth="385.6px" datasizeheight="45.0px" dataX="20.5" dataY="153.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Ingres&aacute; tu destino ..."/></div></div>  </div></div></div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Puntos de origen"   datasizewidth="148.1px" datasizeheight="20.0px" dataX="20.5" dataY="225.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Puntos de origen</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="text firer click commentable non-processed" customid="Input 1"  datasizewidth="385.6px" datasizeheight="45.0px" dataX="20.5" dataY="254.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder="Seleccion&aacute; ..."/></div></div>  </div></div></div>\
      <div id="s-Input_3" class="date firer focusout pageload commentable non-processed" customid="Input 3" value="" format="dd/MM/yyyy" title="Ida" datasizewidth="176.3px" datasizeheight="45.0px" dataX="20.5" dataY="354.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date"  tabindex="-1"  /></div></div></div></div></div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Fechas"   datasizewidth="63.6px" datasizeheight="20.0px" dataX="20.5" dataY="327.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Fechas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_5" class="date firer focusout pageload commentable non-processed" customid="Input 3" value="" format="dd/MM/yyyy" title="Ida" datasizewidth="175.7px" datasizeheight="45.0px" dataX="230.5" dataY="354.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date"  tabindex="-1"  /></div></div></div></div></div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Habitaciones"   datasizewidth="115.3px" datasizeheight="20.0px" dataX="20.5" dataY="439.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Habitaciones</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_4" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="384.3px" datasizeheight="45.0px" dataX="21.8" dataY="463.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Path_35" class="path firer commentable non-processed" customid="Persons"   datasizewidth="24.7px" datasizeheight="16.5px" dataX="230.5" dataY="477.2"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="24.653350830078125" height="16.53223991394043" viewBox="230.45312500000017 477.2338802814478 24.653350830078125 16.53223991394043" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_35-16fe3" d="M247.37207520008104 485.4868199825281 C249.49897491931932 485.4868199825281 251.22167503833788 483.6147201061243 251.22167503833788 481.31200003623906 C251.22167503833788 479.0444200038904 249.50777542591112 477.2338802814478 247.37207520008104 477.2338802814478 C245.26267540454882 477.2338802814478 243.5224753618242 479.0707900524134 243.5224753618242 481.3295800685877 C243.5312749147417 483.6235196590418 245.25387489795702 485.4868199825281 247.37207520008104 485.4868199825281 Z M237.18554508686083 485.688919782638 C239.04007542133348 485.688919782638 240.53417503833788 484.04542040824833 240.53417503833788 482.0151202678675 C240.53417503833788 480.0375897884363 239.04007542133348 478.43797993659916 237.18554508686083 478.43797993659916 C235.34862482547777 478.43797993659916 233.82812511920946 480.06395983695927 233.83690512180345 482.02391982078495 C233.83690512180345 484.0542199611658 235.33983480930345 485.688919782638 237.18554508686083 485.688919782638 Z M247.37207520008104 483.9487197399134 C246.15917503833788 483.9487197399134 245.13087570667284 482.8061196804041 245.13087570667284 481.3207900524134 C245.13087570667284 479.8881700038904 246.15037453174608 478.77196002006474 247.37207520008104 478.77196002006474 C248.60257446765917 478.77196002006474 249.61327469348925 479.87060046195927 249.61327469348925 481.31200003623906 C249.61327469348925 482.7885196208948 248.593775868416 483.9487197399134 247.37207520008104 483.9487197399134 Z M237.18554508686083 484.16842055320683 C236.19237482547777 484.16842055320683 235.34862482547777 483.21921992301884 235.34862482547777 482.02391982078495 C235.34862482547777 480.8813397884363 236.18358480930345 479.94970011711064 237.18554508686083 479.94970011711064 C238.2050753831865 479.94970011711064 239.0312749147417 480.8637597560877 239.0312749147417 482.0151202678675 C239.0312749147417 483.21921992301884 238.18749535083788 484.16842055320683 237.18554508686083 484.16842055320683 Z M232.35155498981493 493.76611971855107 L239.18067467212694 493.76611971855107 C238.69726479053514 493.4848201274866 238.37206470966356 492.84322047233525 238.4335852861406 492.2632205486292 L232.27245509624498 492.2632205486292 C232.1054650545122 492.2632205486292 232.03515493869799 492.1841208934778 232.03515493869799 492.03462100028935 C232.03515493869799 490.02191996574345 234.39062511920946 488.1059195995325 237.1767550706865 488.1059195995325 C238.16112530231493 488.1059195995325 239.1454755067827 488.35202097892704 239.901374936104 488.77392077445927 C240.20017540454882 488.34322047233525 240.56937515735643 487.97411990165654 241.05277550220507 487.65772032737675 C239.93647491931932 486.97212004661503 238.54784500598925 486.60302042961064 237.1767550706865 486.60302042961064 C233.4589749574663 486.60302042961064 230.45312500000017 489.25731921195927 230.45312500000017 492.175320386886 C230.45312500000017 493.2300193309778 231.0859349966051 493.76611971855107 232.35155498981493 493.76611971855107 Z M241.8964749574663 493.76611971855107 L252.84767448902147 493.76611971855107 C254.36817467212694 493.76611971855107 255.10647499561327 493.28271937370243 255.10647499561327 492.2456195354456 C255.10647499561327 489.82861971855107 252.0829745531084 486.6118199825281 247.37207520008104 486.6118199825281 C242.66117489337938 486.6118199825281 239.63767540454882 489.82861971855107 239.63767540454882 492.2456195354456 C239.63767540454882 493.28271937370243 240.37597477436083 493.76611971855107 241.8964749574663 493.76611971855107 Z M241.61527550220507 492.22802042961064 C241.41307461261766 492.22802042961064 241.3339749574663 492.15771937370243 241.3339749574663 491.9995200633997 C241.3339749574663 490.65482020378056 243.50487530231493 488.14992022514286 247.37207520008104 488.14992022514286 C251.23927414417284 488.14992022514286 253.41017448902147 490.65482020378056 253.41017448902147 491.9995200633997 C253.41017448902147 492.15771937370243 253.3310748338701 492.22802042961064 253.12007439136522 492.22802042961064 L241.61527550220507 492.22802042961064 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_35-16fe3" fill="#007EFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer commentable non-processed" customid="Bed"   datasizewidth="22.6px" datasizeheight="15.2px" dataX="42.3" dataY="477.9"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.649398803710938" height="15.231420516967773" viewBox="42.30567157268523 477.8842899799343 22.649398803710938 15.231420516967773" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-16fe3" d="M43.07911145687102 493.1157100200649 L43.624031424522386 493.1157100200649 C44.08985149860381 493.1157100200649 44.397471547126756 492.8169105052944 44.397471547126756 492.34231066703757 L44.397471547126756 491.0767104625698 C44.50293123722075 491.103008985519 44.8105512857437 491.1206099987026 45.030281662940965 491.1206099987026 L62.23047077655791 491.1206099987026 C62.45017063617705 491.1206099987026 62.75777065753935 491.103008985519 62.86327183246611 491.0767104625698 L62.86327183246611 492.34231066703757 C62.86327183246611 492.8169105052944 63.170871853828416 493.1157100200649 63.636772274970994 493.1157100200649 L64.1816712617874 493.1157100200649 C64.64747059345244 493.1157100200649 64.95507061481474 492.8169105052944 64.95507061481474 492.34231066703757 L64.95507061481474 486.1812102794643 C64.95507061481474 484.59030985832175 64.15527164936064 483.66750979423483 62.678671002387986 483.5181100368496 L62.678671002387986 480.42432951927145 C62.678671002387986 478.75441002845724 61.78227055072783 477.8842899799343 60.14747059345244 477.8842899799343 L47.1132913827896 477.8842899799343 C45.478521466255174 477.8842899799343 44.5820413827896 478.75441002845724 44.5820413827896 480.42432951927145 L44.5820413827896 483.5181100368496 C43.105471491813645 483.66750979423483 42.30567157268523 484.59030985832175 42.30567157268523 486.1812102794643 L42.30567157268523 492.34231066703757 C42.30567157268523 492.8169105052944 42.6132913827896 493.1157100200649 43.07911145687102 493.1157100200649 Z M46.946291565895066 481.8833100795742 C46.946291565895066 481.0395600795742 47.41211140155791 480.5737397670742 48.27344143390654 480.5737397670742 L51.43747150897978 480.5737397670742 C52.29007160663603 480.5737397670742 52.75587189197539 481.0395600795742 52.75587189197539 481.8833100795742 L52.75587189197539 483.5005099773403 L46.946291565895066 483.5005099773403 L46.946291565895066 481.8833100795742 Z M54.50487148761748 481.8833100795742 C54.50487148761748 481.0395600795742 54.970671772956834 480.5737397670742 55.82327091693877 480.5737397670742 L58.98727238178252 480.5737397670742 C59.84867107868193 480.5737397670742 60.3144723176956 481.0395600795742 60.3144723176956 481.8833100795742 L60.3144723176956 483.5005099773403 L54.50487148761748 483.5005099773403 L54.50487148761748 481.8833100795742 Z M44.30957138538359 489.6177089214321 C44.10743153095244 489.6177089214321 43.99317133426665 489.4858100414272 43.99317133426665 489.2661101818081 L43.99317133426665 486.0757100582119 C43.99317133426665 485.4253098964687 44.42383158206938 485.0034101009365 45.074221253395066 485.0034101009365 L62.186571240425096 485.0034101009365 C62.83687222003935 485.0034101009365 63.267570614814744 485.4253098964687 63.267570614814744 486.0757100582119 L63.267570614814744 489.2661101818081 C63.267570614814744 489.4858100414272 63.15337193012236 489.6177089214321 62.951171994209275 489.6177089214321 L44.30957138538359 489.6177089214321 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-16fe3" fill="#007EFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_6" class="text firer pageload ie-background commentable non-processed" customid="Input 6"  datasizewidth="100.0px" datasizeheight="45.0px" dataX="66.5" dataY="463.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder="num.hab"/></div></div>  </div></div></div>\
      <div id="s-Input_7" class="text firer pageload ie-background commentable non-processed" customid="Input 6"  datasizewidth="100.0px" datasizeheight="45.0px" dataX="255.1" dataY="463.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder="num.per"/></div></div>  </div></div></div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Volver al Inicio"   datasizewidth="143.2px" datasizeheight="23.0px" dataX="69.0" dataY="70.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Volver al Inicio</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Chevron left"   datasizewidth="19.0px" datasizeheight="33.0px" dataX="37.0" dataY="65.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.973670959472656" height="32.966854095458984" viewBox="37.0 65.03314766987339 18.973670959472656 32.966854095458984" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-16fe3" d="M37.0 81.51657433904222 C37.0 82.16695498545933 37.24158746844515 82.72451571411108 37.76191295636316 83.20764830614837 L52.21981491915155 97.36822689184217 C52.628523407417525 97.77693538010814 53.14887107597283 98.00000000000027 53.762248370136895 98.00000000000027 C54.98858354277821 98.00000000000027 55.97367000579834 97.0337348159257 55.97367000579834 95.78858239718195 C55.97367000579834 95.17541279443974 55.7133903093882 94.63645960404699 55.30468182112223 94.2089338696786 L42.277618490304405 81.51657433904222 L55.30468182112223 68.82415229933713 C55.7133903093882 68.39673242710124 55.97367000579834 67.83923622393976 55.97367000579834 67.24456930553484 C55.97367000579834 65.99947939585982 54.98858354277821 65.03314766987339 53.762248370136895 65.03314766987339 C53.14887107597283 65.03314766987339 52.628523407417525 65.25615078890759 52.21981491915155 65.66498530352176 L37.76191295636316 79.80689485009864 C37.24158746844515 80.30863498039494 37.0 80.86619369262512 37.0 81.51657433904222 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-16fe3" fill="#007EFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer ie-background commentable non-processed" customid="Path 1"   datasizewidth="384.2px" datasizeheight="3.0px" dataX="21.9" dataY="114.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="384.2122802734375" height="2.0" viewBox="21.89386676224156 114.0 384.2122802734375 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-16fe3" d="M22.89386676224156 115.0 L405.1061332377579 115.0 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-16fe3" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="square"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="383.3px" datasizeheight="45.0px" dataX="22.9" dataY="463.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;