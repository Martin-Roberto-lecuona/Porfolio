var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-ffe6c059-b262-42d7-b6d7-40a397de123b" class="screen growth-none devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Reserva_confirmada" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/ffe6c059-b262-42d7-b6d7-40a397de123b-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="429.4px" datasizeheight="926.5px" datasizewidthpx="429.37625129606386" datasizeheightpx="926.4856509689153" dataX="-0.4" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 20"   datasizewidth="244.3px" datasizeheight="41.0px" datasizewidthpx="244.32858276367233" datasizeheightpx="41.0" dataX="87.7" dataY="296.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0">&iexcl;Listo!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 20"   datasizewidth="326.9px" datasizeheight="115.0px" datasizewidthpx="326.85425604638385" datasizeheightpx="115.0" dataX="52.0" dataY="337.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0">Se reserv&oacute; tu viaje. Revis&aacute; tu casilla de correo electr&oacute;nico.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer commentable non-processed" customid="Airplane"   datasizewidth="132.3px" datasizeheight="118.3px" dataX="143.7" dataY="469.9"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="132.258544921875" height="118.26692962646484" viewBox="143.69930946826835 469.872726440429 132.258544921875 118.26692962646484" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-ffe6c" d="M275.9578560590736 529.0060897162992 C275.9002023646208 522.2118629785241 266.6296282448866 516.8569293593544 255.28691986886636 516.8569293593544 L231.6220900525426 516.8569293593544 C228.3976066393796 516.8569293593544 227.18825354793532 516.2810796608586 225.23076442528705 514.150635702543 L186.19228459116417 471.945585428895 C184.92594630822612 470.5636773540206 183.42834348759123 469.872726440429 181.75910409413356 469.872726440429 L174.33118028498242 469.872726440429 C172.83410227040886 469.872726440429 171.9704651718718 471.2546313914578 172.66134736086016 472.8092256512777 L192.87121018772487 516.7992819125927 L163.33365060042567 520.0814190202085 L152.79673507390783 501.31071811043387 C151.99061109677146 499.87123131340104 150.78146105529137 499.23785912196786 148.8813569763741 499.23785912196786 L146.2902988600196 499.23785912196786 C144.7357046001997 499.23785912196786 143.69930946826835 500.2742573777448 143.69930946826835 501.82892036216793 L143.69930946826835 556.1830029150912 C143.69930946826835 557.7376034226022 144.7357046001997 558.773995430688 146.2902988600196 558.773995430688 L148.8813569763741 558.773995430688 C150.78146105529137 558.773995430688 151.99061109677146 558.1411542930073 152.79673507390783 556.7011989191341 L163.33365060042567 537.8731129656284 L192.87121018772487 541.2129037676971 L172.66134736086016 585.2027663505846 C171.9704651718718 586.7573543627134 172.83410227040886 588.1396560421338 174.33118028498242 588.1396560421338 L181.75910409413356 588.1396560421338 C183.42834348759123 588.1396560421338 184.92594630822612 587.390857755662 186.19228459116417 586.0668595305798 L225.23076442528705 543.8615437300556 C227.18825354793532 541.73109977174 228.3976066393796 541.1552500732442 231.6220900525426 541.1552500732442 L255.28691986886636 541.1552500732442 C266.6296282448866 541.1552500732442 275.9002023646208 535.7426690073128 275.9578560590736 529.0060897162992 Z "></path>\
          	    </defs>\
          	    <g transform="rotate(315.0 209.828582763671 529.0061912412814)" style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-ffe6c" fill="#007EFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Volver al inicio"   datasizewidth="385.6px" datasizeheight="45.0px" dataX="21.2" dataY="650.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Volver al inicio</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;