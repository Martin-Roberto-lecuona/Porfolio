var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-80c2f224-f237-4fb8-bf16-24a842008216" class="screen growth-none devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="gestion_tarjetas" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/80c2f224-f237-4fb8-bf16-24a842008216-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Tarjetas"   datasizewidth="80.3px" datasizeheight="23.0px" dataX="69.0" dataY="70.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Tarjetas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Chevron left"   datasizewidth="19.0px" datasizeheight="33.0px" dataX="37.0" dataY="65.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.973670959472656" height="32.966854095458984" viewBox="37.0 65.03314766987339 18.973670959472656 32.966854095458984" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-80c2f" d="M37.0 81.51657433904222 C37.0 82.16695498545933 37.24158746844515 82.72451571411108 37.76191295636316 83.20764830614837 L52.21981491915155 97.36822689184217 C52.628523407417525 97.77693538010814 53.14887107597283 98.00000000000027 53.762248370136895 98.00000000000027 C54.98858354277821 98.00000000000027 55.97367000579834 97.0337348159257 55.97367000579834 95.78858239718195 C55.97367000579834 95.17541279443974 55.7133903093882 94.63645960404699 55.30468182112223 94.2089338696786 L42.277618490304405 81.51657433904222 L55.30468182112223 68.82415229933713 C55.7133903093882 68.39673242710124 55.97367000579834 67.83923622393976 55.97367000579834 67.24456930553484 C55.97367000579834 65.99947939585982 54.98858354277821 65.03314766987339 53.762248370136895 65.03314766987339 C53.14887107597283 65.03314766987339 52.628523407417525 65.25615078890759 52.21981491915155 65.66498530352176 L37.76191295636316 79.80689485009864 C37.24158746844515 80.30863498039494 37.0 80.86619369262512 37.0 81.51657433904222 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-80c2f" fill="#007EFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer ie-background commentable non-processed" customid="Path 1"   datasizewidth="384.2px" datasizeheight="3.0px" dataX="21.9" dataY="114.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="384.2122802734375" height="2.0" viewBox="21.89386676224156 114.0 384.2122802734375 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-80c2f" d="M22.89386676224156 115.0 L405.1061332377579 115.0 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-80c2f" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="square"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Dynamic Panel 1" datasizewidth="385.4px" datasizeheight="683.0px" dataX="23.3" dataY="129.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel 1"  datasizewidth="385.4px" datasizeheight="683.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Data_grid_1" summary="" class="datagrid horizontal firer ie-background commentable non-processed" customid="tarjetas_reservar 1" items="1" size="0" childWidth="375.38983497475965" childHeight="109.30672982186336" hSpacing="5" vSpacing="5" datamaster="tarjetas_pago" datasizewidth="385.4px" datasizeheight="347.9px" dataX="0.0" dataY="0.0" originalwidth="385.38983497475965px" originalheight="347.92018946559006px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                  	<div class="paddingLayer">\
                      <table >\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Agregar" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 5"   datasizewidth="401.1px" datasizeheight="62.5px" datasizewidthpx="401.14574395361626" datasizeheightpx="62.49703979492165" dataX="13.8" dataY="830.9" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Agregar una nueva tarjeta"   datasizewidth="254.4px" datasizeheight="25.0px" dataX="104.0" dataY="848.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_2_0">Agregar una nueva tarjeta</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="+"   datasizewidth="23.0px" datasizeheight="55.0px" dataX="70.1" dataY="830.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_1_0">+</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="403.1px" datasizeheight="62.5px" dataX="12.2" dataY="830.9"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
      </div>\
\
      <!-- START DATA VIEW TEMPLATES -->\
      <script type="text/x-jquery-tmpl" id="s-Data_grid_1-template">\
        <![CDATA[\
        <td>\
          <div id="s-Grid_cell_1" class="gridcell firer ie-background commentable non-processed " instance="{{=it.id}}" customid="" originalwidth="375.38983497475965px" originalheight="109.30672982186336px" >\
            <div class="cellContainerChild">\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="layout scrollable">\
                  <div class="paddingLayer">\
                    <div class="freeLayout">\
                    <div id="s-Rectangle_1" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 11"   datasizewidth="371.4px" datasizeheight="100.0px" datasizewidthpx="371.3898349747598" datasizeheightpx="99.99999999999991" dataX="0.0" dataY="4.3" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_1_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Input_1" class="text firer ie-background commentable non-processed" customid="Input 3"  datasizewidth="307.0px" datasizeheight="30.0px" dataX="11.0" dataY="19.3" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="a6b4109c-cfc6-485b-8043-12ed989c2179" value="{{!it.userdata["a6b4109c-cfc6-485b-8043-12ed989c2179"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Input_3" class="text firer ie-background commentable non-processed" customid="Input 5"  datasizewidth="308.7px" datasizeheight="40.0px" dataX="11.0" dataY="49.3" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="d37548b0-1358-438f-98dd-ae3a61d4cf85" value="{{!it.userdata["d37548b0-1358-438f-98dd-ae3a61d4cf85"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Path_3" class="path firer commentable non-processed" customid="Chevron left"   datasizewidth="13.0px" datasizeheight="22.5px" dataX="347.0" dataY="43.0"  >\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg xmlns="http://www.w3.org/2000/svg" width="12.97367000579834" height="22.541820526123047" viewBox="347.0 43.04912133381657 12.97367000579834 22.541820526123047" preserveAspectRatio="none">\
                        	  <g>\
                        	    <defs>\
                        	      <path id="s-Path_3-80c2f" d="M347.0 54.320031922290994 C347.0 54.76474419367522 347.16519081928726 55.14598877627361 347.5209749756361 55.476341460610506 L357.40688787409374 65.15895286925326 C357.6863514177155 65.43841641287509 358.0421507405698 65.5909418213788 358.46156114462457 65.5909418213788 C359.3000951679047 65.5909418213788 359.97367000579834 64.93023645270503 359.97367000579834 64.07883571775147 C359.97367000579834 63.65956732733819 359.7956979587773 63.29104606399847 359.51623441515545 62.99871580870327 L350.608689341007 54.320031922290994 L359.51623441515545 45.64130529390896 C359.7956979587773 45.34904742420771 359.97367000579834 44.967846962352304 359.97367000579834 44.56123019499033 C359.97367000579834 43.70987220200655 359.3000951679047 43.04912133381657 358.46156114462457 43.04912133381657 C358.0421507405698 43.04912133381657 357.6863514177155 43.20160468973714 357.40688787409374 43.4811544066851 L347.5209749756361 53.15100044348602 C347.16519081928726 53.494076447081596 347.0 53.87531965090677 347.0 54.320031922290994 Z "></path>\
                        	    </defs>\
                        	    <g transform="rotate(180.0 353.48683500289917 54.32003157759769)" style="mix-blend-mode:normal">\
                        	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-80c2f" fill="#FFFFFF" fill-opacity="1.0"></use>\
                        	    </g>\
                        	  </g>\
                        	</svg>\
\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="378.4px" datasizeheight="109.0px" dataX="0.0" dataY="0.0"  >\
                      <div class="clickableSpot"></div>\
                    </div>\
                    </div>\
\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div> \
        </td>\
        ]]>\
      </script>\
      <!-- END DATA VIEW TEMPLATES -->\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;