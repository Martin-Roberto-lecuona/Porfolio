var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-538d83dc-4fe7-45d8-902a-fff77e5e9c17" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Resultados_busqueda" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/538d83dc-4fe7-45d8-902a-fff77e5e9c17-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="429.4px" datasizeheight="1303.5px" datasizewidthpx="429.37625129606346" datasizeheightpx="1303.4856509689153" dataX="-0.4" dataY="140.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="433.0px" datasizeheight="145.0px" datasizewidthpx="433.00000000000114" datasizeheightpx="145.00000000000006" dataX="-3.0" dataY="-5.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_16" class="group firer ie-background commentable non-processed" customid="Search Field" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Input_15" class="text firer focusin focusout pageload commentable non-processed" customid="Search Input"  datasizewidth="315.7px" datasizeheight="36.0px" dataX="52.0" dataY="58.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
        <div id="s-Path_123" class="path firer commentable non-processed" customid="Search icon"   datasizewidth="16.8px" datasizeheight="16.9px" dataX="60.0" dataY="68.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="16.76076889038086" height="16.91897964477539" viewBox="60.0 68.0 16.76076889038086 16.91897964477539" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_123-538d8" d="M66.91696977615356 81.83397912979126 C68.31446981430054 81.83397912979126 69.62406969070435 81.41207933425903 70.71386957168579 80.6913800239563 L74.56346940994263 84.54978036880493 C74.81836938858032 84.79587984085083 75.14357042312622 84.91898012161255 75.49516916275024 84.91898012161255 C76.22456979751587 84.91898012161255 76.76076936721802 84.34767961502075 76.76076936721802 83.62698030471802 C76.76076936721802 83.29298067092896 76.6464695930481 82.96777963638306 76.4003701210022 82.72168016433716 L72.57716989517212 78.88087892532349 C73.36817026138306 77.7558798789978 73.8339695930481 76.39357995986938 73.8339695930481 74.91698026657104 C73.8339695930481 71.11132955551147 70.72267007827759 68.0 66.91696977615356 68.0 C63.12011957168579 68.0 60.0 71.11132955551147 60.0 74.91698026657104 C60.0 78.72267961502075 63.111329555511475 81.83397912979126 66.91696977615356 81.83397912979126 Z M66.91696977615356 79.98827981948853 C64.13085985183716 79.98827981948853 61.845709800720215 77.70307970046997 61.845709800720215 74.91698026657104 C61.845709800720215 72.13085985183716 64.13085985183716 69.84569978713989 66.91696977615356 69.84569978713989 C69.70317029953003 69.84569978713989 71.98827028274536 72.13085985183716 71.98827028274536 74.91698026657104 C71.98827028274536 77.70307970046997 69.70317029953003 79.98827981948853 66.91696977615356 79.98827981948853 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_123-538d8" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_113" class="path firer commentable non-processed" customid="Microphone icon"   datasizewidth="12.0px" datasizeheight="17.3px" dataX="347.4" dataY="68.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="12.0" height="17.269668579101562" viewBox="347.39262670657433 68.00000000000027 12.0 17.269668579101562" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_113-538d8" d="M353.39264460176236 79.1675546325176 C354.98690899520994 79.1675546325176 356.1648716678364 77.97386720265146 356.1648716678364 76.23037995034537 L356.1648716678364 70.93718362976644 C356.1648716678364 69.19372364631806 354.98690899520994 68.00000000000027 353.39264460176236 68.00000000000027 C351.7983802083147 68.00000000000027 350.62041838784006 69.19372364631806 350.62041838784006 70.93718362976644 L350.62041838784006 76.23037995034537 C350.62041838784006 77.97386720265146 351.7983802083147 79.1675546325176 353.39264460176236 79.1675546325176 Z M347.39262670657433 76.41105488013872 C347.39262670657433 79.66231141348007 349.55231853439597 81.88482728090172 352.6622601776202 82.18327299861876 L352.6622601776202 83.77753653991454 L349.78006547769195 83.77753653991454 C349.36383363331873 83.77753653991454 349.0182818160269 84.1074334764146 349.0182818160269 84.52364827775175 C349.0182818160269 84.9319977179377 349.36383363331873 85.26966968749771 349.78006547769195 85.26966968749771 L357.00525014253867 85.26966968749771 C357.4214649438758 85.26966968749771 357.76699886597976 84.9319977179377 357.76699886597976 84.52364827775175 C357.76699886597976 84.1074334764146 357.4214649438758 83.77753653991454 357.00525014253867 83.77753653991454 L354.12302902590443 83.77753653991454 L354.12302902590443 82.18327299861876 C357.2330149810225 81.88482728090172 359.39262670657456 79.66231141348007 359.39262670657456 76.41105488013872 L359.39262670657456 74.86388039538164 C359.39262670657456 74.44766644619632 359.06281839386213 74.12572179033143 358.64660529682857 74.12572179033143 C358.230392199795 74.12572179033143 357.88476794959985 74.44766644619632 357.88476794959985 74.86388039538164 L357.88476794959985 76.35601269081302 C357.88476794959985 79.0340590873542 356.0706918504554 80.79327194905179 353.39264460176236 80.79327194905179 C350.71459820522114 80.79327194905179 348.90048546354905 79.0340590873542 348.90048546354905 76.35601269081302 L348.90048546354905 74.86388039538164 C348.90048546354905 74.44766644619632 348.56278792943493 74.12572179033143 348.14655608506166 74.12572179033143 C347.7303246667644 74.12572179033143 347.39262670657433 74.44766644619632 347.39262670657433 74.86388039538164 L347.39262670657433 76.41105488013872 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_113-538d8" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Subtraction_4" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.0px" datasizeheight="18.0px" dataX="345.0" dataY="67.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="345.02312469100326 67.00000000000001 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_4-538d8" d="M351.28110703688105 72.8406628921158 C351.3813063409814 72.8406628921158 351.48158055111537 72.87866965713076 351.55800967392923 72.95477018760391 L354.0202958373652 75.4116005585459 L356.4881250472778 72.95477018760391 C356.56447926405804 72.87874422893924 356.6646535994808 72.84073746392423 356.76482793490345 72.84073746392423 C356.8649773016482 72.84073746392423 356.96512666839305 72.87874422893924 357.0415058538512 72.95477018760391 C357.19368994517754 73.10627524500515 357.19423925608953 73.35362993347104 357.0415058538512 73.50568185080047 L354.57312733302666 75.96305908167074 L357.0354384651404 78.42098317246925 C357.1875975877889 78.57248822987049 357.1881718673788 78.81984291833626 357.0348641855505 78.97134797573747 C356.9584850000924 79.04737393440229 356.85833563334756 79.08538069941724 356.7581862666027 79.08538069941724 C356.65801193118006 79.08538069941724 356.5578375957574 79.04737393440229 356.48148337897715 78.97134797573747 L354.0197465264531 76.51397074486727 L351.55800967392923 78.96473594205926 C351.4817053945045 79.0406873289156 351.3815060904041 79.0785698075833 351.281381692337 79.0785698075833 C351.1810575448476 79.0785698075833 351.0807833347135 79.04055061393359 351.0046288673559 78.96473594205926 C350.8518954651175 78.81268402472983 350.8518954651175 78.56587619619228 351.0046288673559 78.41382427886273 L353.4669150307919 75.96251222174246 L351.0040545877658 73.5051349908722 C350.8518954651175 73.35253621361448 350.8518954651175 73.10571595644217 351.0051781782679 72.95422332767566 C351.0812078022364 72.87853294214875 351.181107482203 72.8406628921158 351.28110703688105 72.8406628921158 Z M354.02319220399266 67.0 C349.0736761679762 67.0 345.0010850657532 71.06778029055758 345.02325725165923 75.9999099836555 C345.00115997178654 80.915087018977 349.0457112488153 84.97775914065909 353.9829177266654 84.9997329668679 C353.9963508753337 84.99979511004153 354.00975905532425 84.999819967311 354.0231672353149 84.999819967311 C358.9726583026535 84.999819967311 363.04522443619857 80.93202724811871 363.02307721897023 75.9999099836555 C363.0451495301651 71.08473294833405 359.0006232218144 67.0220732552867 354.06341674396424 67.00008700044316 C354.0500085639736 67.00002485726947 354.0366003839833 67.0 354.02319220399266 67.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_4-538d8" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_147" class="path firer click commentable non-processed" customid="Menu"   datasizewidth="27.0px" datasizeheight="18.0px" dataX="12.0" dataY="67.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="27.0" height="18.0" viewBox="11.999999999998522 66.99999999999991 27.0 18.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_147-538d8" d="M11.999999999998522 84.99999999999991 L38.99999999999852 84.99999999999991 L38.99999999999852 81.99999999999991 L11.999999999998522 81.99999999999991 L11.999999999998522 84.99999999999991 Z M11.999999999998522 77.49999999999991 L38.99999999999852 77.49999999999991 L38.99999999999852 74.49999999999991 L11.999999999998522 74.49999999999991 L11.999999999998522 77.49999999999991 Z M11.999999999998522 66.99999999999991 L11.999999999998522 69.99999999999991 L38.99999999999852 69.99999999999991 L38.99999999999852 66.99999999999991 L11.999999999998522 66.99999999999991 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_147-538d8" fill="#007EFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer click ie-background commentable non-processed" customid="filtro icono"   datasizewidth="36.3px" datasizeheight="34.9px" dataX="378.9" dataY="58.6"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/48d0b065-ff4a-42fa-9897-8f8b5b01437a.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_5" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 20"   datasizewidth="321.3px" datasizeheight="41.0px" datasizewidthpx="321.3285827636722" datasizeheightpx="41.0" dataX="12.0" dataY="155.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0">Seleccion&aacute; tu destino deseado</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Data_grid_2" summary="" class="datagrid horizontal firer ie-background commentable non-processed" customid="hospedajes_busqueda 1" items="1" size="0" childWidth="430.0" childHeight="270.0" hSpacing="5" vSpacing="5" datamaster="Hospedajes" datasizewidth="440.0px" datasizeheight="1380.0px" dataX="-6.0" dataY="207.9" originalwidth="440.0px" originalheight="1380.0px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
        	<div class="paddingLayer">\
            <table >\
            </table>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      <!-- START DATA VIEW TEMPLATES -->\
      <script type="text/x-jquery-tmpl" id="s-Data_grid_2-template">\
        <![CDATA[\
        <td>\
          <div id="s-Grid_cell_2" class="gridcell firer variablechange pageload ie-background commentable non-processed " instance="{{=it.id}}" customid="" originalwidth="430.0px" originalheight="270.0px" >\
            <div class="cellContainerChild">\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="layout scrollable">\
                  <div class="paddingLayer">\
                    <div class="freeLayout">\
                    <div id="s-Rectangle_6" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 5"   datasizewidth="410.0px" datasizeheight="262.5px" datasizewidthpx="410.00000000000006" datasizeheightpx="262.4970397949218" dataX="10.0" dataY="0.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_6_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image 15" name="9e2957ab-ca95-40ce-a13f-7ae77dbe7ffb"  datasizewidth="410.0px" datasizeheight="125.0px" dataX="10.0" dataY="0.0"   alt="image">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                      		<img src="{{!it.userdata["9e2957ab-ca95-40ce-a13f-7ae77dbe7ffb"]}}" />\
                      	</div>\
                      </div>\
                    </div>\
\
                    <div id="s-Input_4" class="text firer ie-background commentable non-processed" customid="Input 1"  datasizewidth="194.2px" datasizeheight="20.0px" dataX="22.1" dataY="124.6" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="21ae2d05-b7c6-40b4-a4a7-a6a7e54fc52b" value="{{!it.userdata["21ae2d05-b7c6-40b4-a4a7-a6a7e54fc52b"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Input_8" class="text firer ie-background commentable non-processed" customid="Input 2"  datasizewidth="174.9px" datasizeheight="20.0px" dataX="133.9" dataY="146.3" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="94308b40-57af-4dce-be2e-06232c0ca444" value="{{!it.userdata["94308b40-57af-4dce-be2e-06232c0ca444"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Input_9" class="text firer ie-background commentable non-processed" customid="Input 3"  datasizewidth="161.0px" datasizeheight="20.0px" dataX="33.0" dataY="222.0" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="662bf97f-2121-4a90-8623-db6c057797a7" value="{{!it.userdata["662bf97f-2121-4a90-8623-db6c057797a7"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Paragraph_13" class="richtext autofit firer ie-background commentable non-processed" customid="Incluye impuestos"   datasizewidth="78.5px" datasizeheight="10.0px" dataX="33.0" dataY="242.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Paragraph_13_0">Incluye impuestos</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Rectangle_9" class="rectangle manualfit firer commentable non-processed" customid="dias/noches"   datasizewidth="165.7px" datasizeheight="23.5px" datasizewidthpx="165.66429138183554" datasizeheightpx="23.497039794921875" dataX="243.3" dataY="114.9" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_9_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Estadia" datasizewidth="0.0px" datasizeheight="0.0px" >\
                      <div id="s-Paragraph_14" class="richtext autofit firer ie-background commentable non-processed" customid="Noches"   datasizewidth="54.2px" datasizeheight="17.0px" dataX="338.8" dataY="118.1" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <div class="borderLayer">\
                          <div class="paddingLayer">\
                            <div class="content">\
                              <div class="valign">\
                                <span id="rtr-s-Paragraph_14_0">Noches</span>\
                              </div>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                      <div id="s-Input_10" class="text firer ie-background commentable non-processed" customid="Input 6"  datasizewidth="30.0px" datasizeheight="20.0px" dataX="324.8" dataY="116.6" ><div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="13926341-2768-4d74-8bb4-72fe6c9e790c" value="{{!it.userdata["13926341-2768-4d74-8bb4-72fe6c9e790c"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                      <div id="s-Paragraph_16" class="richtext autofit firer ie-background commentable non-processed" customid="D&iacute;as /"   datasizewidth="40.0px" datasizeheight="17.0px" dataX="279.8" dataY="118.1" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <div class="borderLayer">\
                          <div class="paddingLayer">\
                            <div class="content">\
                              <div class="valign">\
                                <span id="rtr-s-Paragraph_16_0">D&iacute;as /</span>\
                              </div>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                      <div id="s-Input_11" class="text firer ie-background commentable non-processed" customid="Input 5"  datasizewidth="23.6px" datasizeheight="20.0px" dataX="261.6" dataY="116.6" ><div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="7fde123b-6e16-4283-986c-ed1011721b92" value="{{!it.userdata["7fde123b-6e16-4283-986c-ed1011721b92"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    </div>\
\
                    <div id="s-Input_12" class="text firer ie-background commentable non-processed" customid="Input 7"  datasizewidth="189.8px" datasizeheight="20.0px" dataX="126.5" dataY="166.3" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="dfa2f131-83a4-48db-8dd7-8a6d2942f287" value="{{!it.userdata["dfa2f131-83a4-48db-8dd7-8a6d2942f287"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="101.3px" datasizeheight="34.0px" dataX="307.7" dataY="219.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Button_3_0">Reservar</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Paragraph_20" class="richtext autofit firer ie-background commentable non-processed" customid="$"   datasizewidth="12.2px" datasizeheight="25.0px" dataX="19.9" dataY="221.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Paragraph_20_0">$</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Rectangle_10" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 11"   datasizewidth="45.0px" datasizeheight="45.0px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="10.0" dataY="0.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_10_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Dynamic_Panel_1" datasizewidth="26.0px" datasizeheight="26.0px" dataX="19.5" dataY="9.5" >\
                      <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Not_favorite"  datasizewidth="26.0px" datasizeheight="26.0px" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <div class="borderLayer">\
                        	<div class="layoutWrapper scrollable">\
                        	  <div class="paddingLayer">\
                              <div class="freeLayout">\
                              <div id="s-Image_4" class="image firer click pageload ie-background commentable non-processed" customid="Image_49"   datasizewidth="26.0px" datasizeheight="26.0px" dataX="0.0" dataY="0.0"   alt="image" systemName="./images/8db9592b-fa56-4616-bbce-9957c29770ab.svg" overlay="#A9A9A9">\
                                <div class="borderLayer">\
                                	<div class="imageViewport">\
                                  	<?xml version="1.0" encoding="UTF-8"?>\
                                  	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" height="64" id="s-Image_4-Layer_1" viewBox="0 0 64 64" width="64"><defs><style>#s-Image_4 .cls-1{fill:#A9A9A9 !important;}</style></defs><title>heartc</title><path class="cls-1" d="M30.29,55.7a1,1,0,0,0,1.42,0l21.9-22.1A15,15,0,0,0,32.43,12.36L31,13.65l-1.39-1.26A15,15,0,1,0,8.39,33.6ZM9.81,13.81a13,13,0,0,1,18.42,0l2.1,1.9a1,1,0,0,0,1.34,0l2.14-1.93a13,13,0,0,1,18.38,0,13,13,0,0,1,0,18.39L31,53.58,9.81,32.19A13,13,0,0,1,9.81,13.81Z" fill="#A9A9A9" jimofill=" " /></svg>\
\
                                  </div>\
                                </div>\
                              </div>\
\
                              </div>\
\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                      <div id="s-Panel_2" class="panel hidden firer ie-background commentable non-processed" customid="Favorite"  datasizewidth="26.0px" datasizeheight="26.0px" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <div class="borderLayer">\
                        	<div class="layoutWrapper scrollable">\
                        	  <div class="paddingLayer">\
                              <div class="freeLayout">\
                              <div id="s-Image_5" class="image firer click pageload ie-background commentable non-processed" customid="Image_13"   datasizewidth="26.0px" datasizeheight="26.0px" dataX="0.0" dataY="0.0"   alt="image" systemName="./images/010d9af0-9153-466c-b59f-c4b7c38e0ef8.svg" overlay="#FF0000">\
                                <div class="borderLayer">\
                                	<div class="imageViewport">\
                                  	<?xml version="1.0" encoding="UTF-8"?>\
                                  	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" height="64" id="s-Image_5-Layer_1" viewBox="0 0 64 64" width="64"><defs><style>#s-Image_5 .cls-1{fill:#FF0000 !important;}</style></defs><title>hearthahahah</title><path class="cls-1" d="M30.29,55.7a1,1,0,0,0,1.42,0l21.9-22.1A15,15,0,0,0,32.43,12.36L31,13.65l-1.39-1.26A15,15,0,1,0,8.39,33.6Z" fill="#FF0000" jimofill=" " /></svg>\
\
                                  </div>\
                                </div>\
                              </div>\
\
                              </div>\
\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Path_6" class="path firer ie-background commentable non-processed" customid="Path 6"   datasizewidth="406.9px" datasizeheight="3.0px" dataX="11.5" dataY="199.0"  >\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg xmlns="http://www.w3.org/2000/svg" width="406.9443359375" height="2.0" viewBox="11.527873056918224 199.00000335369575 406.9443359375 2.0" preserveAspectRatio="none">\
                        	  <g>\
                        	    <defs>\
                        	      <path id="s-Path_6-538d8" d="M12.52775345963937 199.9999999999999 L417.4722465403602 199.9999999999999 "></path>\
                        	    </defs>\
                        	    <g style="mix-blend-mode:normal">\
                        	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-538d8" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="square"></use>\
                        	    </g>\
                        	  </g>\
                        	</svg>\
\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Rectangle_11" class="rectangle manualfit firer commentable non-processed" customid="precio final"   datasizewidth="165.7px" datasizeheight="23.5px" datasizewidthpx="165.66429138183554" datasizeheightpx="23.497039794921875" dataX="134.5" dataY="188.3" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_11_0">Precio final</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    </div>\
\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div> \
        </td>\
        ]]>\
      </script>\
      <!-- END DATA VIEW TEMPLATES -->\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;