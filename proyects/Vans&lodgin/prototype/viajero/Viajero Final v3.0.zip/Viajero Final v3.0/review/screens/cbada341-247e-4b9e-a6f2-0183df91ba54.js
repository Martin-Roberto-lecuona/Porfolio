var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-cbada341-247e-4b9e-a6f2-0183df91ba54" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="RegistrarViajero" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/cbada341-247e-4b9e-a6f2-0183df91ba54-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="433.0px" datasizeheight="926.0px" dataX="-4.5" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/0bb1c4a1-c19f-42cd-8b7b-26e6ef17703b.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="428.5px" datasizeheight="926.0px" datasizewidthpx="428.50000000000017" datasizeheightpx="925.9999999999998" dataX="-0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="59.8px" datasizeheight="57.6px" dataX="339.5" dataY="10.4"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/9fdf7276-462a-4c37-8647-8fae1ed34fe6.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="email text firer pageunload commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="69.4" dataY="171.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="email"  value="" maxlength="100"  tabindex="-1" placeholder="Nombre"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="text firer pageunload commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="69.4" dataY="232.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Apellido"/></div></div>  </div></div></div>\
      <div id="s-Button_1" class="button multiline manualfit firer click ie-background commentable non-processed" customid="Button Filled"   datasizewidth="300.0px" datasizeheight="50.0px" dataX="64.0" dataY="830.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Continuar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Gestionar datos de usuari"   datasizewidth="192.1px" datasizeheight="18.0px" dataX="118.0" dataY="68.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Gestionar datos de usuario</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="Person circle"   datasizewidth="49.2px" datasizeheight="46.2px" dataX="189.4" dataY="104.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="49.18457794189453" height="46.1757926940918" viewBox="189.40770983695958 104.0 49.18457794189453 46.1757926940918" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-cbada" d="M213.9880733048552 150.17579078674316 C227.46687805354773 150.17579078674316 238.59229016303976 139.72590734514458 238.59229016303976 127.08788085645281 C238.59229016303976 114.4498325623829 227.44307496237857 104.0 213.96427021368604 104.0 C200.50929177114105 104.0 189.40770983695958 114.4498325623829 189.40770983695958 127.08788085645281 C189.40770983695958 139.72590734514458 200.53306648844773 150.17579078674316 213.9880733048552 150.17579078674316 Z M213.9880733048552 134.8135723712516 C207.2843716980996 134.8135723712516 202.07825802909133 137.06878633873762 199.5584139948816 139.6588388475715 C196.32540969389575 136.3764946560727 194.3523286997358 131.955500268204 194.3523286997358 127.08788085645281 C194.3523286997358 116.83900423635018 203.07668781940617 108.62202664897252 213.96427021368604 108.62202664897252 C224.87573566183838 108.62202664897252 233.6477525526879 116.83900423635018 233.67155564385706 127.08788085645281 C233.67155564385706 131.955500268204 231.69844756555565 136.3764946560727 228.44166467810007 139.68119178300282 C225.92165813904165 137.06878633873762 220.7155754233379 134.8135723712516 213.9880733048552 134.8135723712516 Z M213.9880733048552 131.15168134472256 C218.59992479832016 131.19639448404453 222.18938606433653 127.48979031819353 222.18938606433653 122.71134278900777 C222.18938606433653 118.20092212249511 218.57612428659303 114.42750143232976 213.9880733048552 114.42750143232976 C209.42382283484443 114.42750143232976 205.78675538648977 118.20092212249511 205.81055847765893 122.71134278900777 C205.83435898938603 127.48979031819353 209.4000197436753 131.12932598647149 213.9880733048552 131.15168134472256 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-cbada" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer click commentable non-processed" customid="Arrow left"   datasizewidth="34.0px" datasizeheight="31.4px" dataX="17.0" dataY="23.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="34.0" height="31.449764251708984" viewBox="16.999999999999243 23.480610808931097 34.0 31.449764251708984" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-cbada" d="M16.999999999999243 39.21564408016107 C16.999999999999243 39.82402213397565 17.23349507396648 40.43240238800091 17.6465773073612 40.87836308992265 L29.500659938814547 54.24101479931673 C29.93184919776831 54.70750786726705 30.39880036814265 54.93037600748344 30.919700379494877 54.93037600748344 C32.051211154597794 54.93037600748344 32.87741654782537 54.01792223761138 32.87741654782537 52.78109140777425 C32.87741654782537 52.13210846593378 32.66182386722649 51.584634443842006 32.28458539812863 51.17928083015683 L28.243471867701903 46.55587692695274 L23.03483814324486 41.182436605769446 L27.219654142364075 41.46643979982963 L48.988329144057744 41.46643979982963 C50.17379265789455 41.46643979982963 51.00000000000014 40.53368248583929 51.00000000000014 39.21564408016107 C51.00000000000014 37.87730213036457 50.17379265789455 36.944547016584906 48.988329144057744 36.944547016584906 L27.219654142364075 36.944547016584906 L23.052800951831422 37.22854801043441 L28.243471867701903 31.855109889461794 L32.28458539812863 27.231866601637062 C32.66182386722649 26.82632597004442 32.87741654782537 26.27885414816332 32.87741654782537 25.629986717383346 C32.87741654782537 24.39306347869782 32.051211154597794 23.480610808931097 30.919700379494877 23.480610808931097 C30.39880036814265 23.480610808931097 29.913866900401683 23.703659366422922 29.446915730027346 24.210573604807678 L17.6465773073612 37.53262372649189 C17.23349507396648 37.97881325032394 16.999999999999243 38.58696248222821 16.999999999999243 39.21564408016107 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-cbada" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_3" class="text firer pageunload commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="69.4" dataY="356.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Ubicacion (calle y altura)"/></div></div>  </div></div></div>\
      <div id="s-Input_4" class="number text firer pageunload commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="69.4" dataY="294.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="number"  value="" maxlength="100"  tabindex="-1" placeholder="dni (sin puntos ni espacios)"/></div></div>  </div></div></div>\
      <div id="s-Input_5" class="email text firer focusout commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="69.4" dataY="440.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="email"  value="" maxlength="100"  tabindex="-1" placeholder="email"/></div></div>  </div></div></div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Subi tu foto! (opcional)"   datasizewidth="160.1px" datasizeheight="18.0px" dataX="139.0" dataY="556.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Subi tu foto! (opcional)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="150.0px" datasizeheight="138.2px" dataX="64.0" dataY="599.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/92e52963-bd32-482b-9cc5-8e7c5a707e04.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Cargar foto"   datasizewidth="150.0px" datasizeheight="45.0px" dataX="239.0" dataY="633.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Cargar foto</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_6" class="number text firer pageunload commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="69.0" dataY="500.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="number"  value="" maxlength="100"  tabindex="-1" placeholder="telefono"/></div></div>  </div></div></div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable hidden non-processed" customid="El email ingresado ya est"   datasizewidth="244.6px" datasizeheight="18.0px" dataX="96.8" dataY="794.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">El email ingresado ya esta en uso!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable hidden non-processed" customid="El email ingresado no es "   datasizewidth="221.5px" datasizeheight="18.0px" dataX="69.4" dataY="412.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">El email ingresado no es valido</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;