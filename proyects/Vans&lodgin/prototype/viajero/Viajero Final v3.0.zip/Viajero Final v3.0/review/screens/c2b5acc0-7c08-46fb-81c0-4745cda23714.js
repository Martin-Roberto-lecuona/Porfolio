var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-c2b5acc0-7c08-46fb-81c0-4745cda23714" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Recibo" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/c2b5acc0-7c08-46fb-81c0-4745cda23714-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_8" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="386.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_9" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="406.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_10" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="426.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_10_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_11" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="446.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_11_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_12" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="466.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_12_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="434.0px" datasizeheight="125.0px" datasizewidthpx="434.00000000000114" datasizeheightpx="125.00000000000006" dataX="-3.0" dataY="-5.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_147" class="path firer click commentable non-processed" customid="Menu"   datasizewidth="27.0px" datasizeheight="18.0px" dataX="12.0" dataY="67.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="27.0" height="18.0" viewBox="11.999999999998522 66.99999999999991 27.0 18.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_147-c2b5a" d="M11.999999999998522 84.99999999999991 L38.99999999999852 84.99999999999991 L38.99999999999852 81.99999999999991 L11.999999999998522 81.99999999999991 L11.999999999998522 84.99999999999991 Z M11.999999999998522 77.49999999999991 L38.99999999999852 77.49999999999991 L38.99999999999852 74.49999999999991 L11.999999999998522 74.49999999999991 L11.999999999998522 77.49999999999991 Z M11.999999999998522 66.99999999999991 L11.999999999998522 69.99999999999991 L38.99999999999852 69.99999999999991 L38.99999999999852 66.99999999999991 L11.999999999998522 66.99999999999991 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_147-c2b5a" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_9" class="image firer ie-background commentable non-processed" customid="Image 9"   datasizewidth="229.9px" datasizeheight="405.0px" dataX="-448.0" dataY="206.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/06beec91-3e35-449a-a51b-bed8e763bb54.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="434.0px" datasizeheight="827.8px" datasizewidthpx="434.000000000001" datasizeheightpx="827.8147940831027" dataX="-4.7" dataY="120.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="406.5px" datasizeheight="759.0px" datasizewidthpx="406.5000000000008" datasizeheightpx="759.0000000000018" dataX="10.7" dataY="129.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Total"   datasizewidth="115.6px" datasizeheight="41.0px" dataX="39.0" dataY="179.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Total</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Subtotal"   datasizewidth="88.1px" datasizeheight="27.0px" dataX="39.0" dataY="237.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Subtotal</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_13" class="richtext manualfit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="123.6px" datasizeheight="18.0px" dataX="39.0" dataY="445.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_13_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_14" class="richtext autofit firer ie-background commentable non-processed" customid="Mas Acciones"   datasizewidth="224.1px" datasizeheight="41.0px" dataX="32.4" dataY="579.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_14_0">Mas Acciones</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_15" class="richtext manualfit firer ie-background commentable non-processed" customid="Descargar PDF"   datasizewidth="163.6px" datasizeheight="18.0px" dataX="92.8" dataY="654.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_15_0">Descargar PDF</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_16" class="richtext manualfit firer ie-background commentable non-processed" customid="Reenviar por Mail"   datasizewidth="163.6px" datasizeheight="18.0px" dataX="92.8" dataY="708.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_16_0">Reenviar por Mail</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_17" class="richtext autofit firer ie-background commentable non-processed" customid="Mas informacion sobre las"   datasizewidth="306.8px" datasizeheight="18.0px" dataX="92.8" dataY="761.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_17_0">Mas informacion sobre las tarifas aplicadas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_18" class="richtext manualfit firer ie-background commentable non-processed" customid="$121.00"   datasizewidth="203.6px" datasizeheight="41.0px" dataX="198.0" dataY="179.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_18_0">$121.00</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_19" class="richtext manualfit firer ie-background commentable non-processed" customid="$100"   datasizewidth="125.1px" datasizeheight="27.0px" dataX="276.6" dataY="237.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_19_0">$100</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="IVA"   datasizewidth="38.7px" datasizeheight="27.0px" dataX="39.0" dataY="278.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">IVA</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_20" class="richtext manualfit firer ie-background commentable non-processed" customid="$21"   datasizewidth="125.1px" datasizeheight="27.0px" dataX="276.6" dataY="278.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_20_0">$21</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="Metodo de pago"   datasizewidth="173.5px" datasizeheight="27.0px" dataX="39.0" dataY="386.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Metodo de pago</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_21" class="richtext manualfit firer ie-background commentable non-processed" customid="Tarjeta &nbsp;**** 2949"   datasizewidth="169.0px" datasizeheight="31.0px" dataX="39.0" dataY="424.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_21_0">Tarjeta &nbsp;**** 2949</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_22" class="richtext manualfit firer ie-background commentable non-processed" customid="$121.00"   datasizewidth="193.7px" datasizeheight="31.0px" dataX="208.0" dataY="424.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_22_0">$121.00</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_14" class="path firer commentable non-processed" customid="Download"   datasizewidth="35.9px" datasizeheight="32.2px" dataX="40.4" dataY="646.9"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="35.921409606933594" height="32.21124267578125" viewBox="40.381093749999636 646.8943777069911 35.921409606933594 32.21124267578125" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_14-c2b5a" d="M62.60012658097726 667.6939894141556 L62.60012658097726 670.5047225915848 L69.19139474338564 670.5047225915848 C73.60417565458232 670.5047225915848 76.30249999999948 667.8906659844126 76.30249999999948 664.3210443341541 C76.30249999999948 661.3416140374508 74.60195386325128 658.9384661902034 71.80529275763753 657.8282760996585 C71.81936177958917 651.4759007229536 67.23788679898229 646.8943777069911 61.349385039721206 646.8943777069911 C57.61106627018857 646.8943777069911 54.80033156782739 648.8197422702294 53.043501718612994 651.3634743542244 C49.684692757567845 650.5343093935736 45.72152125057674 653.0780414775686 45.5809842867189 657.0412450081301 C42.36267950349519 657.5892247210346 40.381093749999636 660.2595665656049 40.381093749999636 663.6604941464533 C40.381093749999636 667.4410276065005 43.262120951967574 670.5047225915848 47.94201427662911 670.5047225915848 L54.02737102318258 670.5047225915848 L54.02737102318258 667.6939894141556 L47.94201427662911 667.6939894141556 C44.87830099236159 667.6939894141556 43.21995505927465 665.8669654234437 43.21995505927465 663.6043690269074 C43.21995505927465 660.9762418728517 44.9485614683979 659.1351442853924 47.815532610335566 659.1351442853924 C48.02634606201495 659.1351442853924 48.11066183561557 659.0227339284484 48.09660653805126 658.8260558332594 C48.01229076445064 654.6380010901713 51.00574433514782 653.2888389174627 54.02737102318258 654.1742250683708 C54.20997857148796 654.2163909610638 54.32238892843197 654.1882803659352 54.406815259597245 654.0336888669789 C55.755898135845655 651.5742878059039 57.849957530960154 649.6910731235732 61.33531296790571 649.6910731235732 C65.74809235417047 649.6910731235732 68.896216720284 653.1904686087638 69.10696841222037 657.2801362689016 C69.149181577803 658.0249541948474 69.09289634040486 658.8541984519584 69.03676969592706 659.5286605936225 C69.00862860215992 659.7254972817318 69.09289634040486 659.8379076386758 69.27566248163058 659.8660502573748 C71.84750592322018 660.3579048507335 73.46362267893925 661.847540702625 73.46362267893925 664.1945619053946 C73.46362267893925 666.2464081349265 72.0301104216617 667.6939894141556 69.1351095059875 667.6939894141556 L62.60012658097726 667.6939894141556 Z M58.31366950561976 679.1056222930105 C58.66497112333534 679.1056222930105 58.960147621505065 678.9791413891829 59.31144923922066 678.6559808652345 L64.0336388382548 674.2149002673503 C64.28660064590996 673.9900795534624 64.41308154973754 673.7230456739917 64.41308154973754 673.3858161280916 C64.41308154973754 672.7252644154588 63.879013790796236 672.2473233009954 63.232534149979 672.2473233009954 C62.909215033110215 672.2473233009954 62.58605755902562 672.3878732267746 62.347164773322106 672.6408380842936 L60.39365835385068 674.6084150506485 L59.49421690537829 675.648409474764 L59.63476988102136 673.5684206265331 L59.63476988102136 661.5103096317929 C59.63476988102136 660.8216168253931 59.044575477602265 660.2173518750905 58.31366950561976 660.2173518750905 C57.596994198373075 660.2173518750905 56.99257065515007 660.8216168253931 56.99257065515007 661.5103096317929 L56.99257065515007 673.5684206265331 L57.14719417767672 675.648409474764 L56.23368065738883 674.6084150506485 L54.28033435576966 672.6408380842936 C54.04128297714582 672.3878732267746 53.7181239781293 672.2473233009954 53.39480486126051 672.2473233009954 C52.74848533829553 672.2473233009954 52.2284881262378 672.7252644154588 52.2284881262378 673.3858161280916 C52.2284881262378 673.7230456739917 52.34089848318181 673.9900795534624 52.59386181576889 674.2149002673503 L57.315889772018856 678.6559808652345 C57.66719138973445 678.9791413891829 57.97643843478774 679.1056222930105 58.31366950561976 679.1056222930105 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-c2b5a" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_40" class="path firer commentable non-processed" customid="Questionmark"   datasizewidth="32.0px" datasizeheight="31.9px" dataX="42.3" dataY="754.1"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="32.0" height="31.879840850830078" viewBox="42.34179687499968 754.0600801531828 32.0 31.879840850830078" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_40-c2b5a" d="M72.24843214194627 756.1705267311382 C70.48128130931397 754.4032409193501 68.04471578179187 754.0600801531828 64.9219460141672 754.0600801531828 L51.71010803965511 754.0600801531828 C48.63885562682997 754.0600801531828 46.18522873400185 754.4204009590735 44.435102961937076 756.1705267311382 C42.6678180810396 757.9378311607411 42.34179687499968 760.3571193563077 42.34179687499968 763.4456677189029 L42.34179687499968 776.5372495053043 C42.34179687499968 779.6600192729289 42.6678180810396 782.0794042811316 44.41794292221364 783.8467487390358 C46.20238877372529 785.5967190523486 48.63885562682997 785.9399198468172 51.76164587405069 785.9399198468172 L64.9219460141672 785.9399198468172 C68.04471578179187 785.9399198468172 70.48128130931397 785.5967190523486 72.24843214194627 783.8467487390358 C74.01577659985048 782.0794042811316 74.34179687499969 779.6600192729289 74.34179687499969 776.5372495053043 L74.34179687499969 763.4798314087071 C74.34179687499969 760.3571193563077 74.01577659985048 757.9206720519084 72.24843214194627 756.1705267311382 Z M70.9789019816975 763.0165699131811 L70.9789019816975 777.0005128626118 C70.9789019816975 778.7850341162726 70.73858323074808 780.4321223860661 69.7948834439395 781.3758258964376 C68.83399941424851 782.3367099261286 67.16973062513546 782.5770249535151 65.40238989079415 782.5770249535151 L51.2812038592052 782.5770249535151 C49.51391897830772 782.5770249535151 47.84957385615479 782.3367099261286 46.88873078565593 781.3758258964376 C45.92786816645173 780.4321223860661 45.70480719875242 778.7850341162726 45.70480719875242 777.0005128626118 L45.70480719875242 763.0509290900386 C45.70480719875242 761.2322013256 45.92786816645173 759.584997625356 46.871570745932495 758.6241536239663 C47.832413816431355 757.6632910047622 49.51391897830772 757.4230699973394 51.31556303606274 757.4230699973394 L65.40238989079415 757.4230699973394 C67.16973062513546 757.4230699973394 68.83399941424851 757.6804510444856 69.7948834439395 758.6241536239663 C70.75576375006757 759.584997625356 70.9789019816975 761.2322013256 70.9789019816975 763.0165699131811 Z M57.97282623244246 773.3973010801417 C58.91652974281395 773.3973010801417 59.517227945770124 772.8655167179539 59.55139163557429 772.1619364714785 C59.56857029311233 772.0934136048168 59.56857029311233 772.0075147317822 59.56857029311233 771.9559768973866 C59.62010998928938 771.0638130831921 60.22061270519218 770.4633103672894 61.33591475101655 769.7425514632758 C63.03454271698715 768.6274430427235 64.13266610527347 767.6493803554944 64.13266610527347 765.6590931530136 C64.13266610527347 762.7935862094124 61.55905484442795 761.1635611667064 58.52198660100305 761.1635611667064 C55.570815368831276 761.1635611667064 53.58033267929713 762.5019064933061 53.04854831710942 764.1146933014675 C52.94547078653679 764.4065498868124 52.894128439194574 764.6982109851041 52.894128439194574 765.0070526027152 C52.894128439194574 765.8304980631946 53.528990331954915 766.3452992548977 54.232375091376966 766.3452992548977 C54.850056464817804 766.3452992548977 55.279154270539635 766.0879954716821 55.622159577954946 765.6247339761561 L55.87965698644243 765.2815350434688 C56.46298104480718 764.3378315330973 57.28662199233991 763.8402108607138 58.31602702691116 763.8402108607138 C59.70581151348914 763.8402108607138 60.63233450454112 764.6638518082466 60.63233450454112 765.8304980631946 C60.63233450454112 766.9116382809963 59.91177108758103 767.443422643184 58.45326824728796 768.455842645489 C57.23508415794433 769.296468625288 56.36009900128792 770.1888279265357 56.36009900128792 771.7502128103481 L56.36009900128792 771.9387982398486 C56.36009900128792 772.8996804077581 56.92624254033318 773.3973010801417 57.97282623244246 773.3973010801417 Z M57.9386625426383 778.6649752769968 C59.03678593092462 778.6649752769968 59.94613026443857 777.8585111252206 59.94613026443857 776.7775682562537 C59.94613026443857 775.696625387287 59.05396645024413 774.9073417548303 57.9386625426383 774.9073417548303 C56.84053915435196 774.9073417548303 55.9310011955661 775.7136085577716 55.9310011955661 776.7775682562537 C55.9310011955661 777.8585111252206 56.85771967367146 778.6649752769968 57.9386625426383 778.6649752769968 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_40-c2b5a" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_25" class="path firer commentable non-processed" customid="Envelope"   datasizewidth="36.0px" datasizeheight="28.1px" dataX="40.3" dataY="702.9"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="36.0" height="28.14960479736328" viewBox="40.34179687499946 702.9251989222884 36.0 28.14960479736328" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_25-c2b5a" d="M45.61284412176548 731.07480107771 L71.4553964308885 731.07480107771 C74.54735793933983 731.07480107771 76.34179687499946 729.2803621420504 76.34179687499946 725.8517119046436 L76.34179687499946 708.1481577130904 C76.34179687499946 704.7195830973969 74.53149997913076 702.9251989222884 71.07076875096556 702.9251989222884 L45.22832683215971 702.9251989222884 C42.13620017284016 702.9251989222884 40.34179687499946 704.7035782398367 40.34179687499946 708.1481577130904 L40.34179687499946 725.8517119046436 C40.34179687499946 729.2803621420504 42.15222328391745 731.07480107771 45.61284412176548 731.07480107771 Z M56.53934551458609 717.5527051953654 L44.875854895493426 706.0173255816079 C45.10016019705843 705.969256248376 45.3564925980459 705.9372100262215 45.628848979325745 705.9372100262215 L71.05472651715615 705.9372100262215 C71.3431042710831 705.9372100262215 71.59958530785197 705.969256248376 71.83983983721112 706.0333486926852 L60.19220804754262 717.5527051953654 C59.51938341043268 718.2096701338361 58.9586666595278 718.498047887763 58.36586717943432 718.498047887763 C57.773069437771035 718.498047887763 57.212352686866154 718.1936279000267 56.53934551458609 717.5527051953654 Z M43.337803121372296 708.3724638838705 L52.05343071060713 716.9438634814626 L43.337803121372296 725.5633341507166 L43.337803121372296 708.3724638838705 Z M64.6783071251219 716.9438634814626 L73.3459010189438 708.4205332171024 L73.3459010189438 725.5314339566982 L64.6783071251219 716.9438634814626 Z M45.628848979325745 728.0466399572956 C45.34046948696861 728.0466399572956 45.06811397490385 728.0147362864168 44.82778556226157 727.966613061849 L54.00810075703963 718.8664507987064 L54.873237495680854 719.7315892757779 C56.042794222058404 720.8690632729669 57.164227723868166 721.3497548668553 58.36586717943432 721.3497548668553 C59.551466139621276 721.3497548668553 60.68894187524043 720.8690632729669 61.84245810623878 719.7315892757779 L62.72363707868939 718.8664507987064 L71.88796306177892 727.9505743049 C71.63148550187043 728.0147362864168 71.3591465048925 728.0466399572956 71.05472651715615 728.0466399572956 L45.628848979325745 728.0466399572956 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_25-c2b5a" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 5"   datasizewidth="349.0px" datasizeheight="40.0px" datasizewidthpx="349.0" datasizeheightpx="39.99999999999997" dataX="54.3" dataY="56.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0">Recibo</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;