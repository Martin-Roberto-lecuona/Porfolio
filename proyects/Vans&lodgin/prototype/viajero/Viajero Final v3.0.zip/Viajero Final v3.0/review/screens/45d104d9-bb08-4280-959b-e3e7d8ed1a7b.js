var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668171217937.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-45d104d9-bb08-4280-959b-e3e7d8ed1a7b" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Recibo with menu" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/45d104d9-bb08-4280-959b-e3e7d8ed1a7b-1668171217937.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_8" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="386.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_9" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="406.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_10" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="426.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_10_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_11" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="446.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_11_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_12" class="richtext autofit firer commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="31.0" dataY="466.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_12_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="434.0px" datasizeheight="125.0px" datasizewidthpx="434.00000000000114" datasizeheightpx="125.00000000000006" dataX="-3.0" dataY="-5.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_16" class="group firer ie-background commentable non-processed" customid="Search Field" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Input_15" class="text firer focusin focusout commentable non-processed" customid="Search Input"  datasizewidth="349.7px" datasizeheight="36.0px" dataX="52.0" dataY="58.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
        <div id="s-Path_123" class="path firer commentable non-processed" customid="Search icon"   datasizewidth="16.8px" datasizeheight="16.9px" dataX="60.0" dataY="68.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="16.76076889038086" height="16.91897964477539" viewBox="60.0 68.0 16.76076889038086 16.91897964477539" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_123-45d10" d="M66.91696977615356 81.83397912979126 C68.31446981430054 81.83397912979126 69.62406969070435 81.41207933425903 70.71386957168579 80.6913800239563 L74.56346940994263 84.54978036880493 C74.81836938858032 84.79587984085083 75.14357042312622 84.91898012161255 75.49516916275024 84.91898012161255 C76.22456979751587 84.91898012161255 76.76076936721802 84.34767961502075 76.76076936721802 83.62698030471802 C76.76076936721802 83.29298067092896 76.6464695930481 82.96777963638306 76.4003701210022 82.72168016433716 L72.57716989517212 78.88087892532349 C73.36817026138306 77.7558798789978 73.8339695930481 76.39357995986938 73.8339695930481 74.91698026657104 C73.8339695930481 71.11132955551147 70.72267007827759 68.0 66.91696977615356 68.0 C63.12011957168579 68.0 60.0 71.11132955551147 60.0 74.91698026657104 C60.0 78.72267961502075 63.111329555511475 81.83397912979126 66.91696977615356 81.83397912979126 Z M66.91696977615356 79.98827981948853 C64.13085985183716 79.98827981948853 61.845709800720215 77.70307970046997 61.845709800720215 74.91698026657104 C61.845709800720215 72.13085985183716 64.13085985183716 69.84569978713989 66.91696977615356 69.84569978713989 C69.70317029953003 69.84569978713989 71.98827028274536 72.13085985183716 71.98827028274536 74.91698026657104 C71.98827028274536 77.70307970046997 69.70317029953003 79.98827981948853 66.91696977615356 79.98827981948853 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_123-45d10" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_113" class="path firer commentable non-processed" customid="Microphone icon"   datasizewidth="12.0px" datasizeheight="17.3px" dataX="379.2" dataY="68.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="12.0" height="17.269668579101562" viewBox="379.2098968491515 68.00000000000026 12.0 17.269668579101562" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_113-45d10" d="M385.20991474433947 79.16755463251761 C386.80417913778706 79.16755463251761 387.98214181041345 77.97386720265146 387.98214181041345 76.23037995034537 L387.98214181041345 70.93718362976642 C387.98214181041345 69.19372364631806 386.80417913778706 68.00000000000026 385.20991474433947 68.00000000000026 C383.6156503508919 68.00000000000026 382.43768853041723 69.19372364631806 382.43768853041723 70.93718362976642 L382.43768853041723 76.23037995034537 C382.43768853041723 77.97386720265146 383.6156503508919 79.16755463251761 385.20991474433947 79.16755463251761 Z M379.2098968491515 76.41105488013872 C379.2098968491515 79.66231141348007 381.36958867697314 81.88482728090173 384.47953032019734 82.18327299861878 L384.47953032019734 83.77753653991455 L381.5973356202691 83.77753653991455 C381.18110377589585 83.77753653991455 380.835551958604 84.10743347641461 380.835551958604 84.52364827775176 C380.835551958604 84.93199771793772 381.18110377589585 85.26966968749772 381.5973356202691 85.26966968749772 L388.82252028511573 85.26966968749772 C389.2387350864529 85.26966968749772 389.5842690085568 84.93199771793772 389.5842690085568 84.52364827775176 C389.5842690085568 84.10743347641461 389.2387350864529 83.77753653991455 388.82252028511573 83.77753653991455 L385.94029916848154 83.77753653991455 L385.94029916848154 82.18327299861878 C389.05028512359956 81.88482728090173 391.2098968491516 79.66231141348007 391.2098968491516 76.41105488013872 L391.2098968491516 74.86388039538164 C391.2098968491516 74.44766644619631 390.8800885364392 74.12572179033143 390.4638754394056 74.12572179033143 C390.0476623423721 74.12572179033143 389.7020380921769 74.44766644619631 389.7020380921769 74.86388039538164 L389.7020380921769 76.35601269081302 C389.7020380921769 79.0340590873542 387.88796199303243 80.7932719490518 385.20991474433947 80.7932719490518 C382.53186834779825 80.7932719490518 380.7177556061262 79.0340590873542 380.7177556061262 76.35601269081302 L380.7177556061262 74.86388039538164 C380.7177556061262 74.44766644619631 380.3800580720121 74.12572179033143 379.96382622763883 74.12572179033143 C379.54759480934155 74.12572179033143 379.2098968491515 74.44766644619631 379.2098968491515 74.86388039538164 L379.2098968491515 76.41105488013872 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_113-45d10" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Subtraction_4" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.0px" datasizeheight="18.0px" dataX="376.6" dataY="67.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="376.5851760891218 67.00000000000014 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_4-45d10" d="M382.8431584349996 72.84066289211594 C382.94335773909995 72.84066289211594 383.04363194923394 72.8786696571309 383.1200610720478 72.95477018760405 L385.58234723548384 75.41160055854604 L388.0501764453964 72.95477018760405 C388.12653066217666 72.87874422893938 388.2267049975994 72.84073746392437 388.3268793330221 72.84073746392437 C388.4270286997668 72.84073746392437 388.5271780665117 72.87874422893938 388.60355725196985 72.95477018760405 C388.75574134329617 73.10627524500529 388.75629065420816 73.35362993347118 388.60355725196985 73.50568185080061 L386.13517873114523 75.96305908167088 L388.597489863259 78.42098317246939 C388.7496489859075 78.57248822987063 388.7502232654974 78.8198429183364 388.5969155836691 78.97134797573761 C388.52053639821105 79.04737393440243 388.4203870314662 79.08538069941739 388.32023766472133 79.08538069941739 C388.2200633292987 79.08538069941739 388.11988899387603 79.04737393440243 388.0435347770958 78.97134797573761 L385.58179792457173 76.51397074486741 L383.1200610720478 78.9647359420594 C383.04375679262307 79.04068732891574 382.9435574885227 79.07856980758345 382.84343309045556 79.07856980758345 C382.74310894296616 79.07856980758345 382.64283473283206 79.04055061393373 382.5666802654745 78.9647359420594 C382.41394686323605 78.81268402472998 382.41394686323605 78.56587619619242 382.5666802654745 78.41382427886288 L385.0289664289105 75.9625122217426 L382.56610598588435 73.50513499087234 C382.41394686323605 73.35253621361463 382.41394686323605 73.10571595644231 382.56722957638647 72.9542233276758 C382.643259200355 72.8785329421489 382.7431588803216 72.84066289211594 382.8431584349996 72.84066289211594 Z M385.58524360211123 67.00000000000014 C380.6357275660947 67.00000000000014 376.56313646387173 71.06778029055772 376.58530864977774 75.99990998365564 C376.56321136990505 80.91508701897715 380.6077626469338 84.97775914065923 385.544969124784 84.99973296686804 C385.5584022734523 84.99979511004167 385.5718104534429 84.99981996731114 385.58521863343344 84.99981996731114 C390.5347097007721 84.99981996731114 394.6072758343173 80.93202724811886 394.58512861708897 75.99990998365564 C394.6072009282838 71.08473294833419 390.56267461993303 67.02207325528684 385.6254681420828 67.0000870004433 C385.6120599620922 67.00002485726961 385.59865178210185 67.00000000000014 385.58524360211123 67.00000000000014 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_4-45d10" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_147" class="path firer commentable non-processed" customid="Menu"   datasizewidth="27.0px" datasizeheight="18.0px" dataX="12.0" dataY="67.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="27.0" height="18.0" viewBox="11.999999999998522 66.99999999999991 27.0 18.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_147-45d10" d="M11.999999999998522 84.99999999999991 L38.99999999999852 84.99999999999991 L38.99999999999852 81.99999999999991 L11.999999999998522 81.99999999999991 L11.999999999998522 84.99999999999991 Z M11.999999999998522 77.49999999999991 L38.99999999999852 77.49999999999991 L38.99999999999852 74.49999999999991 L11.999999999998522 74.49999999999991 L11.999999999998522 77.49999999999991 Z M11.999999999998522 66.99999999999991 L11.999999999998522 69.99999999999991 L38.99999999999852 69.99999999999991 L38.99999999999852 66.99999999999991 L11.999999999998522 66.99999999999991 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_147-45d10" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_9" class="image firer ie-background commentable non-processed" customid="Image 9"   datasizewidth="229.9px" datasizeheight="405.0px" dataX="-448.0" dataY="206.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/ffdd20cd-039b-4c3a-afe9-430c6ff7b5b9.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="434.0px" datasizeheight="827.8px" datasizewidthpx="434.000000000001" datasizeheightpx="827.8147940831027" dataX="-4.7" dataY="120.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="406.5px" datasizeheight="759.0px" datasizewidthpx="406.5000000000008" datasizeheightpx="759.0000000000018" dataX="10.7" dataY="129.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Total"   datasizewidth="115.6px" datasizeheight="41.0px" dataX="39.0" dataY="179.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Total</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Subtotal"   datasizewidth="88.1px" datasizeheight="27.0px" dataX="39.0" dataY="237.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Subtotal</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_13" class="richtext manualfit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="123.6px" datasizeheight="18.0px" dataX="39.0" dataY="445.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_13_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_14" class="richtext autofit firer ie-background commentable non-processed" customid="Mas Acciones"   datasizewidth="224.1px" datasizeheight="41.0px" dataX="32.4" dataY="579.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_14_0">Mas Acciones</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_15" class="richtext manualfit firer ie-background commentable non-processed" customid="Descargar PDF"   datasizewidth="163.6px" datasizeheight="18.0px" dataX="92.8" dataY="654.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_15_0">Descargar PDF</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_16" class="richtext manualfit firer ie-background commentable non-processed" customid="Reenviar por Mail"   datasizewidth="163.6px" datasizeheight="18.0px" dataX="92.8" dataY="708.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_16_0">Reenviar por Mail</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_17" class="richtext autofit firer ie-background commentable non-processed" customid="Mas informacion sobre las"   datasizewidth="306.8px" datasizeheight="18.0px" dataX="92.8" dataY="761.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_17_0">Mas informacion sobre las tarifas aplicadas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_18" class="richtext manualfit firer ie-background commentable non-processed" customid="$121.00"   datasizewidth="203.6px" datasizeheight="41.0px" dataX="198.0" dataY="179.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_18_0">$121.00</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_19" class="richtext manualfit firer ie-background commentable non-processed" customid="$100"   datasizewidth="125.1px" datasizeheight="27.0px" dataX="276.6" dataY="237.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_19_0">$100</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="IVA"   datasizewidth="38.7px" datasizeheight="27.0px" dataX="39.0" dataY="278.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">IVA</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_20" class="richtext manualfit firer ie-background commentable non-processed" customid="$21"   datasizewidth="125.1px" datasizeheight="27.0px" dataX="276.6" dataY="278.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_20_0">$21</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="Metodo de pago"   datasizewidth="173.5px" datasizeheight="27.0px" dataX="39.0" dataY="386.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Metodo de pago</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_21" class="richtext manualfit firer ie-background commentable non-processed" customid="Tarjeta &nbsp;**** 2949"   datasizewidth="169.0px" datasizeheight="31.0px" dataX="39.0" dataY="424.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_21_0">Tarjeta &nbsp;**** 2949</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_22" class="richtext manualfit firer ie-background commentable non-processed" customid="$121.00"   datasizewidth="193.7px" datasizeheight="31.0px" dataX="208.0" dataY="424.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_22_0">$121.00</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_14" class="path firer commentable non-processed" customid="Download"   datasizewidth="35.9px" datasizeheight="32.2px" dataX="40.4" dataY="646.9"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="35.921409606933594" height="32.21124267578125" viewBox="40.381093749999636 646.8943777069911 35.921409606933594 32.21124267578125" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_14-45d10" d="M62.60012658097726 667.6939894141556 L62.60012658097726 670.5047225915848 L69.19139474338564 670.5047225915848 C73.60417565458232 670.5047225915848 76.30249999999948 667.8906659844126 76.30249999999948 664.3210443341541 C76.30249999999948 661.3416140374508 74.60195386325128 658.9384661902034 71.80529275763753 657.8282760996585 C71.81936177958917 651.4759007229536 67.23788679898229 646.8943777069911 61.349385039721206 646.8943777069911 C57.61106627018857 646.8943777069911 54.80033156782739 648.8197422702294 53.043501718612994 651.3634743542244 C49.684692757567845 650.5343093935736 45.72152125057674 653.0780414775686 45.5809842867189 657.0412450081301 C42.36267950349519 657.5892247210346 40.381093749999636 660.2595665656049 40.381093749999636 663.6604941464533 C40.381093749999636 667.4410276065005 43.262120951967574 670.5047225915848 47.94201427662911 670.5047225915848 L54.02737102318258 670.5047225915848 L54.02737102318258 667.6939894141556 L47.94201427662911 667.6939894141556 C44.87830099236159 667.6939894141556 43.21995505927465 665.8669654234437 43.21995505927465 663.6043690269074 C43.21995505927465 660.9762418728517 44.9485614683979 659.1351442853924 47.815532610335566 659.1351442853924 C48.02634606201495 659.1351442853924 48.11066183561557 659.0227339284484 48.09660653805126 658.8260558332594 C48.01229076445064 654.6380010901713 51.00574433514782 653.2888389174627 54.02737102318258 654.1742250683708 C54.20997857148796 654.2163909610638 54.32238892843197 654.1882803659352 54.406815259597245 654.0336888669789 C55.755898135845655 651.5742878059039 57.849957530960154 649.6910731235732 61.33531296790571 649.6910731235732 C65.74809235417047 649.6910731235732 68.896216720284 653.1904686087638 69.10696841222037 657.2801362689016 C69.149181577803 658.0249541948474 69.09289634040486 658.8541984519584 69.03676969592706 659.5286605936225 C69.00862860215992 659.7254972817318 69.09289634040486 659.8379076386758 69.27566248163058 659.8660502573748 C71.84750592322018 660.3579048507335 73.46362267893925 661.847540702625 73.46362267893925 664.1945619053946 C73.46362267893925 666.2464081349265 72.0301104216617 667.6939894141556 69.1351095059875 667.6939894141556 L62.60012658097726 667.6939894141556 Z M58.31366950561976 679.1056222930105 C58.66497112333534 679.1056222930105 58.960147621505065 678.9791413891829 59.31144923922066 678.6559808652345 L64.0336388382548 674.2149002673503 C64.28660064590996 673.9900795534624 64.41308154973754 673.7230456739917 64.41308154973754 673.3858161280916 C64.41308154973754 672.7252644154588 63.879013790796236 672.2473233009954 63.232534149979 672.2473233009954 C62.909215033110215 672.2473233009954 62.58605755902562 672.3878732267746 62.347164773322106 672.6408380842936 L60.39365835385068 674.6084150506485 L59.49421690537829 675.648409474764 L59.63476988102136 673.5684206265331 L59.63476988102136 661.5103096317929 C59.63476988102136 660.8216168253931 59.044575477602265 660.2173518750905 58.31366950561976 660.2173518750905 C57.596994198373075 660.2173518750905 56.99257065515007 660.8216168253931 56.99257065515007 661.5103096317929 L56.99257065515007 673.5684206265331 L57.14719417767672 675.648409474764 L56.23368065738883 674.6084150506485 L54.28033435576966 672.6408380842936 C54.04128297714582 672.3878732267746 53.7181239781293 672.2473233009954 53.39480486126051 672.2473233009954 C52.74848533829553 672.2473233009954 52.2284881262378 672.7252644154588 52.2284881262378 673.3858161280916 C52.2284881262378 673.7230456739917 52.34089848318181 673.9900795534624 52.59386181576889 674.2149002673503 L57.315889772018856 678.6559808652345 C57.66719138973445 678.9791413891829 57.97643843478774 679.1056222930105 58.31366950561976 679.1056222930105 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-45d10" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_40" class="path firer commentable non-processed" customid="Questionmark"   datasizewidth="32.0px" datasizeheight="31.9px" dataX="42.3" dataY="754.1"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="32.0" height="31.879840850830078" viewBox="42.34179687499968 754.0600801531828 32.0 31.879840850830078" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_40-45d10" d="M72.24843214194627 756.1705267311382 C70.48128130931397 754.4032409193501 68.04471578179187 754.0600801531828 64.9219460141672 754.0600801531828 L51.71010803965511 754.0600801531828 C48.63885562682997 754.0600801531828 46.18522873400185 754.4204009590735 44.435102961937076 756.1705267311382 C42.6678180810396 757.9378311607411 42.34179687499968 760.3571193563077 42.34179687499968 763.4456677189029 L42.34179687499968 776.5372495053043 C42.34179687499968 779.6600192729289 42.6678180810396 782.0794042811316 44.41794292221364 783.8467487390358 C46.20238877372529 785.5967190523486 48.63885562682997 785.9399198468172 51.76164587405069 785.9399198468172 L64.9219460141672 785.9399198468172 C68.04471578179187 785.9399198468172 70.48128130931397 785.5967190523486 72.24843214194627 783.8467487390358 C74.01577659985048 782.0794042811316 74.34179687499969 779.6600192729289 74.34179687499969 776.5372495053043 L74.34179687499969 763.4798314087071 C74.34179687499969 760.3571193563077 74.01577659985048 757.9206720519084 72.24843214194627 756.1705267311382 Z M70.9789019816975 763.0165699131811 L70.9789019816975 777.0005128626118 C70.9789019816975 778.7850341162726 70.73858323074808 780.4321223860661 69.7948834439395 781.3758258964376 C68.83399941424851 782.3367099261286 67.16973062513546 782.5770249535151 65.40238989079415 782.5770249535151 L51.2812038592052 782.5770249535151 C49.51391897830772 782.5770249535151 47.84957385615479 782.3367099261286 46.88873078565593 781.3758258964376 C45.92786816645173 780.4321223860661 45.70480719875242 778.7850341162726 45.70480719875242 777.0005128626118 L45.70480719875242 763.0509290900386 C45.70480719875242 761.2322013256 45.92786816645173 759.584997625356 46.871570745932495 758.6241536239663 C47.832413816431355 757.6632910047622 49.51391897830772 757.4230699973394 51.31556303606274 757.4230699973394 L65.40238989079415 757.4230699973394 C67.16973062513546 757.4230699973394 68.83399941424851 757.6804510444856 69.7948834439395 758.6241536239663 C70.75576375006757 759.584997625356 70.9789019816975 761.2322013256 70.9789019816975 763.0165699131811 Z M57.97282623244246 773.3973010801417 C58.91652974281395 773.3973010801417 59.517227945770124 772.8655167179539 59.55139163557429 772.1619364714785 C59.56857029311233 772.0934136048168 59.56857029311233 772.0075147317822 59.56857029311233 771.9559768973866 C59.62010998928938 771.0638130831921 60.22061270519218 770.4633103672894 61.33591475101655 769.7425514632758 C63.03454271698715 768.6274430427235 64.13266610527347 767.6493803554944 64.13266610527347 765.6590931530136 C64.13266610527347 762.7935862094124 61.55905484442795 761.1635611667064 58.52198660100305 761.1635611667064 C55.570815368831276 761.1635611667064 53.58033267929713 762.5019064933061 53.04854831710942 764.1146933014675 C52.94547078653679 764.4065498868124 52.894128439194574 764.6982109851041 52.894128439194574 765.0070526027152 C52.894128439194574 765.8304980631946 53.528990331954915 766.3452992548977 54.232375091376966 766.3452992548977 C54.850056464817804 766.3452992548977 55.279154270539635 766.0879954716821 55.622159577954946 765.6247339761561 L55.87965698644243 765.2815350434688 C56.46298104480718 764.3378315330973 57.28662199233991 763.8402108607138 58.31602702691116 763.8402108607138 C59.70581151348914 763.8402108607138 60.63233450454112 764.6638518082466 60.63233450454112 765.8304980631946 C60.63233450454112 766.9116382809963 59.91177108758103 767.443422643184 58.45326824728796 768.455842645489 C57.23508415794433 769.296468625288 56.36009900128792 770.1888279265357 56.36009900128792 771.7502128103481 L56.36009900128792 771.9387982398486 C56.36009900128792 772.8996804077581 56.92624254033318 773.3973010801417 57.97282623244246 773.3973010801417 Z M57.9386625426383 778.6649752769968 C59.03678593092462 778.6649752769968 59.94613026443857 777.8585111252206 59.94613026443857 776.7775682562537 C59.94613026443857 775.696625387287 59.05396645024413 774.9073417548303 57.9386625426383 774.9073417548303 C56.84053915435196 774.9073417548303 55.9310011955661 775.7136085577716 55.9310011955661 776.7775682562537 C55.9310011955661 777.8585111252206 56.85771967367146 778.6649752769968 57.9386625426383 778.6649752769968 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_40-45d10" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_25" class="path firer commentable non-processed" customid="Envelope"   datasizewidth="36.0px" datasizeheight="28.1px" dataX="40.3" dataY="702.9"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="36.0" height="28.14960479736328" viewBox="40.34179687499946 702.9251989222884 36.0 28.14960479736328" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_25-45d10" d="M45.61284412176548 731.07480107771 L71.4553964308885 731.07480107771 C74.54735793933983 731.07480107771 76.34179687499946 729.2803621420504 76.34179687499946 725.8517119046436 L76.34179687499946 708.1481577130904 C76.34179687499946 704.7195830973969 74.53149997913076 702.9251989222884 71.07076875096556 702.9251989222884 L45.22832683215971 702.9251989222884 C42.13620017284016 702.9251989222884 40.34179687499946 704.7035782398367 40.34179687499946 708.1481577130904 L40.34179687499946 725.8517119046436 C40.34179687499946 729.2803621420504 42.15222328391745 731.07480107771 45.61284412176548 731.07480107771 Z M56.53934551458609 717.5527051953654 L44.875854895493426 706.0173255816079 C45.10016019705843 705.969256248376 45.3564925980459 705.9372100262215 45.628848979325745 705.9372100262215 L71.05472651715615 705.9372100262215 C71.3431042710831 705.9372100262215 71.59958530785197 705.969256248376 71.83983983721112 706.0333486926852 L60.19220804754262 717.5527051953654 C59.51938341043268 718.2096701338361 58.9586666595278 718.498047887763 58.36586717943432 718.498047887763 C57.773069437771035 718.498047887763 57.212352686866154 718.1936279000267 56.53934551458609 717.5527051953654 Z M43.337803121372296 708.3724638838705 L52.05343071060713 716.9438634814626 L43.337803121372296 725.5633341507166 L43.337803121372296 708.3724638838705 Z M64.6783071251219 716.9438634814626 L73.3459010189438 708.4205332171024 L73.3459010189438 725.5314339566982 L64.6783071251219 716.9438634814626 Z M45.628848979325745 728.0466399572956 C45.34046948696861 728.0466399572956 45.06811397490385 728.0147362864168 44.82778556226157 727.966613061849 L54.00810075703963 718.8664507987064 L54.873237495680854 719.7315892757779 C56.042794222058404 720.8690632729669 57.164227723868166 721.3497548668553 58.36586717943432 721.3497548668553 C59.551466139621276 721.3497548668553 60.68894187524043 720.8690632729669 61.84245810623878 719.7315892757779 L62.72363707868939 718.8664507987064 L71.88796306177892 727.9505743049 C71.63148550187043 728.0147362864168 71.3591465048925 728.0466399572956 71.05472651715615 728.0466399572956 L45.628848979325745 728.0466399572956 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_25-45d10" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 17" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 8"   datasizewidth="236.8px" datasizeheight="943.0px" datasizewidthpx="236.82858276367233" datasizeheightpx="943.0000000000008" dataX="-8.0" dataY="-5.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_1" class="path firer click commentable non-processed" customid="Menu"   datasizewidth="27.0px" datasizeheight="18.0px" dataX="7.0" dataY="70.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="27.0" height="18.0" viewBox="6.999999999998522 70.50000000000034 27.0 18.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-45d10" d="M6.999999999998522 88.50000000000034 L33.99999999999852 88.50000000000034 L33.99999999999852 85.50000000000034 L6.999999999998522 85.50000000000034 L6.999999999998522 88.50000000000034 Z M6.999999999998522 81.00000000000034 L33.99999999999852 81.00000000000034 L33.99999999999852 78.00000000000034 L6.999999999998522 78.00000000000034 L6.999999999998522 81.00000000000034 Z M6.999999999998522 70.50000000000034 L6.999999999998522 73.50000000000034 L33.99999999999852 73.50000000000034 L33.99999999999852 70.50000000000034 L6.999999999998522 70.50000000000034 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-45d10" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_2" class="richtext manualfit firer click ie-background commentable non-processed" customid="Inicio"   datasizewidth="156.8px" datasizeheight="24.0px" dataX="34.0" dataY="115.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_2_0">Inicio</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_2" class="path firer click commentable non-processed" customid="Home"   datasizewidth="22.0px" datasizeheight="19.2px" dataX="5.2" dataY="117.4"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="19.201934814453125" viewBox="5.1714172363279545 117.39903298858196 22.0 19.201934814453125" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_2-45d10" d="M5.1714172363279545 126.46512758166895 C5.1714172363279545 126.93162288405323 5.531186290149544 127.3352523130636 6.1068206800346365 127.3352523130636 C6.3856426116925915 127.3352523130636 6.637478753496771 127.18278174201555 6.862339352844865 127.00336795860979 L7.887685181999775 126.14222462242654 L7.887685181999775 134.48413339941777 C7.887685181999775 135.81156764992784 8.68818017123296 136.600966884831 10.064310038322555 136.600966884831 L22.23354762993743 136.600966884831 C23.60074371812856 136.600966884831 24.41021396382228 135.81156764992784 24.41021396382228 134.48413339941777 L24.41021396382228 126.09742178695123 L25.48954015616847 127.00336795860979 C25.705365966555174 127.18278174201555 25.957211867785723 127.3352523130636 26.236073813091796 127.3352523130636 C26.766682113479444 127.3352523130636 27.171417236326306 127.00336795860979 27.171417236326306 126.48308939881528 C27.171417236326306 126.17814825671918 27.054550057439112 125.9359698206918 26.820612703596243 125.73859519341616 L24.41021396382228 123.71146762642938 L24.41021396382228 119.89036962893677 C24.41021396382228 119.48672998052352 24.14936206393813 119.2355818286023 23.744626941091273 119.2355818286023 L22.50340552847517 119.2355818286023 C22.10767640428191 119.2355818286023 21.837818505744163 119.48672998052352 21.837818505744163 119.89036962893677 L21.837818505744163 121.55874165157037 L17.45757324381846 117.89012395789045 C16.67512001814289 117.23533615755599 15.685745482699978 117.23533615755599 14.903189783047539 117.89012395789045 L5.531186290149544 125.73859519341616 C5.288335164232268 125.9359698206918 5.1714172363279545 126.20509049580043 5.1714172363279545 126.46512758166895 Z M18.761731245204953 128.9407886338937 C18.761731245204953 128.519197387737 18.49197484470145 128.25017890665708 18.06922967643267 128.25017890665708 L14.291635824410207 128.25017890665708 C13.868889680198789 128.25017890665708 13.590026758950081 128.519197387737 13.590026758950081 128.9407886338937 L13.590026758950081 134.81601678059513 L10.54100629150351 134.81601678059513 C9.983352668761233 134.81601678059513 9.67755519464719 134.50199302253537 9.67755519464719 133.93691260054203 L9.67755519464719 124.64435701044565 L15.784703138256855 119.53158342637497 C16.036550015430045 119.31630781173203 16.324315485412832 119.31630781173203 16.576162362586018 119.53158342637497 L22.61136820674301 124.59047155900667 L22.61136820674301 133.93691260054203 C22.61136820674301 134.50199302253537 22.30549021736142 134.81601678059513 21.74786587289825 134.81601678059513 L18.761731245204953 134.81601678059513 L18.761731245204953 128.9407886338937 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-45d10" fill="#007EFF" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group 24" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Favoritos"   datasizewidth="152.8px" datasizeheight="24.0px" dataX="38.0" dataY="230.9" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_4_0">Favoritos</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_3" class="path firer commentable non-processed" customid="Favorites"   datasizewidth="22.0px" datasizeheight="19.2px" dataX="5.2" dataY="233.3"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="19.200000762939453" viewBox="5.1714172363279545 233.29054870605458 22.0 19.200000762939453" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_3-45d10" d="M5.1714172363279545 239.69399906756132 C5.1714172363279545 244.06878138473655 9.073596330630016 248.39238858927925 15.138770399585004 252.0806853357474 C15.475776081657989 252.285617020901 15.888839416117046 252.4905487060546 16.171429915158775 252.4905487060546 C16.454019234774382 252.4905487060546 16.867083748659564 252.285617020901 17.204088251306423 252.0806853357474 C23.280207394681725 248.39238858927925 27.171417236327954 244.06878138473655 27.171417236327954 239.69399906756132 C27.171417236327954 235.91338967956068 24.399685646586722 233.29054870605458 20.84535764727057 233.29054870605458 C18.769279891030127 233.29054870605458 17.14967306827517 234.18189481280027 16.171429915158775 235.53430163658402 C15.214951891713982 234.19214139705792 13.584462504123223 233.29054870605458 11.50838474788278 233.29054870605458 C7.94316179975654 233.29054870605458 5.1714172363279545 235.91338967956068 5.1714172363279545 239.69399906756132 Z M7.410556551186989 239.68374136625445 C7.410556551186989 237.1018633839757 9.21490337441211 235.3498870216016 11.63885758330011 235.3498870216016 C13.595346248385148 235.3498870216016 14.693180851509196 236.46664630911454 15.377950940748063 237.43996508992166 C15.682307748887515 237.8600272411749 15.888839416117046 237.9932206077706 16.171429915158775 237.9932206077706 C16.464902979036307 237.9932206077706 16.64966833716811 237.84978065691723 16.96490771014337 237.43996508992166 C17.70409416183961 236.48712724887577 18.758396146768206 235.3498870216016 20.704001067591317 235.3498870216016 C23.13885081500247 235.3498870216016 24.94322181646311 237.1018633839757 24.94322181646311 239.68374136625445 C24.94322181646311 243.29008878446453 20.964949097278225 247.28589978767977 16.377961582388306 250.15458763425522 C16.28013644147838 250.21602044819463 16.214961353928103 250.25705347683203 16.171429915158775 250.25705347683203 C16.128021136706224 250.25705347683203 16.062722209413046 250.21602044819463 15.975780812765047 250.15458763425522 C11.388793297875129 247.28589978767977 7.410556551186989 243.29008878446453 7.410556551186989 239.68374136625445 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-45d10" fill="#007EFF" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Group 25" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Perfil"   datasizewidth="152.8px" datasizeheight="24.0px" dataX="38.0" dataY="269.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_5_0">Perfil</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_4" class="path firer commentable non-processed" customid="Person"   datasizewidth="20.8px" datasizeheight="19.2px" dataX="5.2" dataY="271.4"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="20.828582763671875" height="19.19999885559082" viewBox="5.171417236328124 271.40000000000015 20.828582763671875 19.19999885559082" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_4-45d10" d="M15.591623404395637 281.0462683028776 C18.457242576226346 281.0462683028776 20.778028155715628 278.8478271035696 20.778028155715628 276.1563295918399 C20.778028155715628 273.50592855911464 18.457242576226346 271.40000000000015 15.591623404395637 271.40000000000015 C12.7378607867834 271.40000000000015 10.393362098857175 273.536750500364 10.405218653075647 276.1768775526728 C10.417073922448626 278.8581133454361 12.726005517410417 281.0462683028776 15.591623404395637 281.0462683028776 Z M15.591623404395637 279.2485000783614 C13.957533777929417 279.2485000783614 12.572147839196965 277.9027167675011 12.572147839196965 276.1768775526728 C12.56029256982399 274.4921231127376 13.945678508556437 273.19774481629366 15.591623404395637 273.19774481629366 C17.24942485445331 273.19774481629366 18.61109768474881 274.4715874133547 18.61109768474881 276.1563295918399 C18.61109768474881 277.88214539844546 17.237568300234837 279.2485000783614 15.591623404395637 279.2485000783614 Z M8.202748070899773 290.6000000000002 L22.9686691654284 290.6000000000002 C25.01717542721482 290.6000000000002 26.00000000000005 290.03499015499057 26.00000000000005 288.8228031445396 C26.00000000000005 285.99775614884595 21.938420945460265 282.23788394427294 15.591623404395637 282.23788394427294 C9.244770614974762 282.23788394427294 5.171417236328125 285.99775614884595 5.171417236328125 288.8228031445396 C5.171417236328125 290.03499015499057 6.154241809113352 290.6000000000002 8.202748070899773 290.6000000000002 Z M7.835674137496356 288.80223289016124 C7.551497150519217 288.80223289016124 7.44491536225686 288.7200633403751 7.44491536225686 288.53515621577884 C7.44491536225686 286.9634389686474 10.36965027526572 284.03565216878917 15.591623404395637 284.03565216878917 C20.80174126415257 284.03565216878917 23.72650187407131 286.9634389686474 23.72650187407131 288.53515621577884 C23.72650187407131 288.7200633403751 23.61993421910939 288.80223289016124 23.335662153565696 288.80223289016124 L7.835674137496356 288.80223289016124 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-45d10" fill="#007EFF" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Group 23" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_23" class="richtext manualfit firer click ie-background commentable non-processed" customid="Historial"   datasizewidth="152.8px" datasizeheight="24.0px" dataX="38.0" dataY="192.4" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_23_0">Historial</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_5" class="path firer click commentable non-processed" customid="Clock"   datasizewidth="22.0px" datasizeheight="19.2px" dataX="5.2" dataY="194.8"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="19.200000762939453" viewBox="5.171417236328125 194.79350891113253 22.0 19.200000762939453" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_5-45d10" d="M16.166082489311087 213.99350891113326 C22.195079839807914 213.99350891113326 27.171417236328125 209.64842334442756 27.171417236328125 204.39350286664865 C27.171417236328125 199.13857332214334 22.184432844301405 194.79350891113253 16.15543549380458 194.79350891113253 C10.137095522750062 194.79350891113253 5.171417236328125 199.13857332214334 5.171417236328125 204.39350286664865 C5.171417236328125 209.64842334442756 10.147729826779482 213.99350891113326 16.166082489311087 213.99350891113326 Z M16.166082489311087 212.08088096561457 C11.285478058239194 212.08088096561457 7.383118835892146 208.65503049041408 7.383118835892146 204.39350286664865 C7.383118835892146 200.1319963985781 11.285478058239194 196.71535822109072 16.15543549380458 196.71535822109072 C21.03607569176645 196.71535822109072 24.9597519805394 200.1319963985781 24.97039897604591 204.39350286664865 C24.980923671864115 208.65503049041408 21.046722687272958 212.08088096561457 16.166082489311087 212.08088096561457 Z M10.806982835282327 205.5633050010862 L16.15543549380458 205.5633050010862 C16.644563867020224 205.5633050010862 17.016703358205795 205.2383716609388 17.016703358205795 204.82058597589358 L17.016703358205795 198.74863155382317 C17.016703358205795 198.33083478722347 16.644563867020224 198.0058802913812 16.15543549380458 198.0058802913812 C15.687599957831306 198.0058802913812 15.315460466645735 198.33083478722347 15.315460466645735 198.74863155382317 L15.315460466645735 204.07786594328692 L10.806982835282327 204.07786594328692 C10.328501457573191 204.07786594328692 9.956337737204086 204.4027992834343 9.956337737204086 204.82058597589358 C9.956337737204086 205.2383716609388 10.328501457573191 205.5633050010862 10.806982835282327 205.5633050010862 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-45d10" fill="#007EFF" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Group 15" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_24" class="richtext manualfit firer ie-background commentable non-processed" customid="Ofertas"   datasizewidth="152.8px" datasizeheight="24.0px" dataX="38.0" dataY="153.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_24_0">Ofertas</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="icons8-discount-100"   datasizewidth="24.7px" datasizeheight="24.7px" dataX="3.8" dataY="153.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/67f77875-20f2-4601-8800-e48e4942f88b.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Dynamic Panel 1" datasizewidth="186.0px" datasizeheight="942.7px" dataX="242.0" dataY="-5.0" >\
        <div id="s-Panel_1" class="panel default firer click ie-background commentable non-processed" customid="Panel 1"  datasizewidth="186.0px" datasizeheight="942.7px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;