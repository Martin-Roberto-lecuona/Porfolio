	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_147", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_147", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Menu", "s-Path_147"]; 

	widgets.descriptionMap[["s-Path_33", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_33", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_33"]; 

	widgets.descriptionMap[["s-Path_1", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_131", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_131", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star half", "s-Path_131"]; 

	widgets.descriptionMap[["s-Image", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Button_1", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Filled button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Input-text_8", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Input-text_8", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Input text field", "s-Input-text_8"]; 

	widgets.descriptionMap[["s-Path_12", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Input 2", "s-List-item-4_7"]; 

	widgets.descriptionMap[["s-Input_1", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Input text field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Path_5", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Input 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_10", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star empty", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_9", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star empty", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_8", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star empty", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_6", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star empty", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star empty", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_16", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star empty", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_15", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star empty", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_14", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star empty", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_11", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star empty", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_13", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star empty", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_20", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_18", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_19", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_17", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_34", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_34", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_34"]; 

	widgets.descriptionMap[["s-Path_21", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_21"]; 

	widgets.descriptionMap[["s-Path_22", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_22"]; 

	widgets.descriptionMap[["s-Path_23", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_23", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_23"]; 

	widgets.descriptionMap[["s-Path_24", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_24", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_24"]; 

	widgets.descriptionMap[["s-Path_25", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "f420e4ef-60a8-467f-a2d4-285ebd85cc69"]] = ["Star", "s-Path_25"]; 

	widgets.descriptionMap[["s-Image", "9a0315af-db55-4ba9-a96c-c1f4392eb2b8"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "9a0315af-db55-4ba9-a96c-c1f4392eb2b8"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "9a0315af-db55-4ba9-a96c-c1f4392eb2b8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "9a0315af-db55-4ba9-a96c-c1f4392eb2b8"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Button_1", "9a0315af-db55-4ba9-a96c-c1f4392eb2b8"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "9a0315af-db55-4ba9-a96c-c1f4392eb2b8"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "9a0315af-db55-4ba9-a96c-c1f4392eb2b8"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "9a0315af-db55-4ba9-a96c-c1f4392eb2b8"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Path_147", "c2b5acc0-7c08-46fb-81c0-4745cda23714"]] = ""; 

			widgets.rootWidgetMap[["s-Path_147", "c2b5acc0-7c08-46fb-81c0-4745cda23714"]] = ["Menu", "s-Path_147"]; 

	widgets.descriptionMap[["s-Path_14", "c2b5acc0-7c08-46fb-81c0-4745cda23714"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "c2b5acc0-7c08-46fb-81c0-4745cda23714"]] = ["Download", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_40", "c2b5acc0-7c08-46fb-81c0-4745cda23714"]] = ""; 

			widgets.rootWidgetMap[["s-Path_40", "c2b5acc0-7c08-46fb-81c0-4745cda23714"]] = ["Question mark", "s-Path_40"]; 

	widgets.descriptionMap[["s-Path_25", "c2b5acc0-7c08-46fb-81c0-4745cda23714"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "c2b5acc0-7c08-46fb-81c0-4745cda23714"]] = ["Envelope", "s-Path_25"]; 

	widgets.descriptionMap[["s-Button_2", "7e8caab1-b88c-40c0-bd49-27906cb022da"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "7e8caab1-b88c-40c0-bd49-27906cb022da"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Path_117", "7e8caab1-b88c-40c0-bd49-27906cb022da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_117", "7e8caab1-b88c-40c0-bd49-27906cb022da"]] = ["Arrow back", "s-Path_117"]; 

	widgets.descriptionMap[["s-Path_1", "853f1b3c-08ab-46b6-8e05-e21b919639cd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "853f1b3c-08ab-46b6-8e05-e21b919639cd"]] = ["Chevron left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_147", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_147", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Menu", "s-Path_147"]; 

	widgets.descriptionMap[["s-Path_33", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_33", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_33"]; 

	widgets.descriptionMap[["s-Path_1", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_131", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_131", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star half", "s-Path_131"]; 

	widgets.descriptionMap[["s-Image", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Button_1", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Filled button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Input-text_8", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Input-text_8", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Input text field", "s-Input-text_8"]; 

	widgets.descriptionMap[["s-Path_12", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Input 2", "s-List-item-4_7"]; 

	widgets.descriptionMap[["s-Input_1", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Input text field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Path_5", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Input 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_10", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star empty", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_9", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star empty", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_8", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star empty", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_6", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star empty", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star empty", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_16", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star empty", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_15", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star empty", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_14", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star empty", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_11", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star empty", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_13", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star empty", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_20", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_18", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_19", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_17", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_34", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_34", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_34"]; 

	widgets.descriptionMap[["s-Path_21", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_21"]; 

	widgets.descriptionMap[["s-Path_22", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_22"]; 

	widgets.descriptionMap[["s-Path_23", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_23", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_23"]; 

	widgets.descriptionMap[["s-Path_24", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_24", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_24"]; 

	widgets.descriptionMap[["s-Path_25", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Star", "s-Path_25"]; 

	widgets.descriptionMap[["s-Path_26", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_26", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Menu", "s-Path_26"]; 

	widgets.descriptionMap[["s-Path_27", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_27", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Home", "s-Path_27"]; 

	widgets.descriptionMap[["s-Path_28", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_28", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Favorites", "s-Path_28"]; 

	widgets.descriptionMap[["s-Path_29", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_29", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Person", "s-Path_29"]; 

	widgets.descriptionMap[["s-Path_30", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_30", "b580119b-c119-4ce0-b18c-612d3a13b66f"]] = ["Clock", "s-Path_30"]; 

	widgets.descriptionMap[["s-Image", "7039ddf3-b6fd-48f9-a207-006468e745f3"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "7039ddf3-b6fd-48f9-a207-006468e745f3"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "7039ddf3-b6fd-48f9-a207-006468e745f3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "7039ddf3-b6fd-48f9-a207-006468e745f3"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Button_1", "7039ddf3-b6fd-48f9-a207-006468e745f3"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "7039ddf3-b6fd-48f9-a207-006468e745f3"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_2", "7039ddf3-b6fd-48f9-a207-006468e745f3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "7039ddf3-b6fd-48f9-a207-006468e745f3"]] = ["Arrow left", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_53", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ""; 

			widgets.rootWidgetMap[["s-Path_53", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ["Person circle", "s-Path_53"]; 

	widgets.descriptionMap[["s-Button_1", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_5", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ["Arrow left", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_25", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ["Envelope", "s-Path_25"]; 

	widgets.descriptionMap[["s-Path_63", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ""; 

			widgets.rootWidgetMap[["s-Path_63", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ["Person", "s-Path_63"]; 

	widgets.descriptionMap[["s-Path_103", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ""; 

			widgets.rootWidgetMap[["s-Path_103", "4d70f526-7fa5-4819-bdcc-bb6aa2d77497"]] = ["Lock", "s-Path_103"]; 

	widgets.descriptionMap[["s-Image_1", "0fcc96a7-2332-4057-9c4c-f566f7138565"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "0fcc96a7-2332-4057-9c4c-f566f7138565"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Path_17", "7b51f7df-04e9-4c48-befd-d85d513a996b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "7b51f7df-04e9-4c48-befd-d85d513a996b"]] = ["Chevron left", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_6", "ffe6c059-b262-42d7-b6d7-40a397de123b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "ffe6c059-b262-42d7-b6d7-40a397de123b"]] = ["Airplane", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_1", "3df00100-9f44-4710-9231-36acf193c3c0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "3df00100-9f44-4710-9231-36acf193c3c0"]] = ["Chevron left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_16", "3df00100-9f44-4710-9231-36acf193c3c0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "3df00100-9f44-4710-9231-36acf193c3c0"]] = ["Trash", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_33", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_33", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_33"]; 

	widgets.descriptionMap[["s-Path_1", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_131", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_131", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star half", "s-Path_131"]; 

	widgets.descriptionMap[["s-Image", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Button_1", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Circle_25", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Circle_25", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Circle", "s-Circle_25"]; 

	widgets.descriptionMap[["s-Path_9", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_10", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_12", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star half", "s-Path_13"]; 

	widgets.descriptionMap[["s-Image_7", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Image_7", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Image", "s-Image_7"]; 

	widgets.descriptionMap[["s-Button_5", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Filled button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Ellipse_4", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Circle", "s-Ellipse_4"]; 

	widgets.descriptionMap[["s-Path_29", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_29", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_29"]; 

	widgets.descriptionMap[["s-Path_30", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_30", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_30"]; 

	widgets.descriptionMap[["s-Path_31", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_31", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_31"]; 

	widgets.descriptionMap[["s-Path_32", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_32", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_32"]; 

	widgets.descriptionMap[["s-Path_34", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_34", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star half", "s-Path_34"]; 

	widgets.descriptionMap[["s-Button_6", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Filled button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Ellipse_5", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_5", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Circle", "s-Ellipse_5"]; 

	widgets.descriptionMap[["s-Image_10", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Image_10", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Image", "s-Image_10"]; 

	widgets.descriptionMap[["s-Path_36", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_36", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_36"]; 

	widgets.descriptionMap[["s-Path_37", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_37", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_37"]; 

	widgets.descriptionMap[["s-Path_38", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_38", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_38"]; 

	widgets.descriptionMap[["s-Path_39", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_39", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star", "s-Path_39"]; 

	widgets.descriptionMap[["s-Path_40", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_40", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Star half", "s-Path_40"]; 

	widgets.descriptionMap[["s-Path_5", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Home", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_19", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Clock", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_20", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Favorites", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_21", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Person", "s-Path_21"]; 

	widgets.descriptionMap[["s-Path_70", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_70", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Favorite outline", "s-Path_70"]; 

	widgets.descriptionMap[["s-Path_68", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_68", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Favorite", "s-Path_68"]; 

	widgets.descriptionMap[["s-Path_47", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_47", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Favorite outline", "s-Path_47"]; 

	widgets.descriptionMap[["s-Path_48", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_48", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Favorite", "s-Path_48"]; 

	widgets.descriptionMap[["s-Path_6", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "a6b869e2-2688-4946-8329-8f52d58f2246"]] = ["Chevron left", "s-Path_6"]; 

	widgets.descriptionMap[["s-Input_15", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_123", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_123", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_113", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_113", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Subtraction_4", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_4", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_147", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_147", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ["Menu", "s-Path_147"]; 

	widgets.descriptionMap[["s-Button_3", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ["Filled button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Image_4", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ["Hearth", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_5", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "538d83dc-4fe7-45d8-902a-fff77e5e9c17"]] = ["Hearth filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Path_1", "0f3b92ae-5567-40ad-a1ab-bceaf748bb7d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "0f3b92ae-5567-40ad-a1ab-bceaf748bb7d"]] = ["Menu", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "0f3b92ae-5567-40ad-a1ab-bceaf748bb7d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "0f3b92ae-5567-40ad-a1ab-bceaf748bb7d"]] = ["Home", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "0f3b92ae-5567-40ad-a1ab-bceaf748bb7d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "0f3b92ae-5567-40ad-a1ab-bceaf748bb7d"]] = ["Favorites", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "0f3b92ae-5567-40ad-a1ab-bceaf748bb7d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "0f3b92ae-5567-40ad-a1ab-bceaf748bb7d"]] = ["Person", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "0f3b92ae-5567-40ad-a1ab-bceaf748bb7d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "0f3b92ae-5567-40ad-a1ab-bceaf748bb7d"]] = ["Clock", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_1", "80c2f224-f237-4fb8-bf16-24a842008216"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "80c2f224-f237-4fb8-bf16-24a842008216"]] = ["Chevron left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_3", "80c2f224-f237-4fb8-bf16-24a842008216"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "80c2f224-f237-4fb8-bf16-24a842008216"]] = ["Chevron left", "s-Path_3"]; 

	widgets.descriptionMap[["s-Input_15", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_123", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Path_123", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_113", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Path_113", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Subtraction_4", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_4", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_147", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Path_147", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Menu", "s-Path_147"]; 

	widgets.descriptionMap[["s-Image_11", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Image_11", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Image", "s-Image_11"]; 

	widgets.descriptionMap[["s-Image_13", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Image_13", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Image", "s-Image_13"]; 

	widgets.descriptionMap[["s-Image_12", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Image_12", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Image", "s-Image_12"]; 

	widgets.descriptionMap[["s-Image_14", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Image_14", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Image", "s-Image_14"]; 

	widgets.descriptionMap[["s-Button_2", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Image_3", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Hearth", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Hearth filled", "s-Image_4"]; 

	widgets.descriptionMap[["s-Path_128", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ""; 

			widgets.rootWidgetMap[["s-Path_128", "fa694501-ba0a-48a3-9e73-9cb32cd01635"]] = ["Search", "s-Path_128"]; 

	widgets.descriptionMap[["s-Input_15", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_123", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_123", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_113", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_113", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Subtraction_4", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_4", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_147", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_147", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Menu", "s-Path_147"]; 

	widgets.descriptionMap[["s-Image_11", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Image_11", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Image", "s-Image_11"]; 

	widgets.descriptionMap[["s-Image_13", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Image_13", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Image", "s-Image_13"]; 

	widgets.descriptionMap[["s-Image_12", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Image_12", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Image", "s-Image_12"]; 

	widgets.descriptionMap[["s-Image_14", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Image_14", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Image", "s-Image_14"]; 

	widgets.descriptionMap[["s-Button_2", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Image_3", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Hearth", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Hearth filled", "s-Image_4"]; 

	widgets.descriptionMap[["s-Path_128", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_128", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Search", "s-Path_128"]; 

	widgets.descriptionMap[["s-Path_7", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Menu", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_14", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Home", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Favorites", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Person", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_17", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "7b9c6bf2-a5f9-4da5-8313-e5705ad8bcd5"]] = ["Clock", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_17", "1040f7e4-536f-4bc9-8c4c-3f9e9eb438cf"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "1040f7e4-536f-4bc9-8c4c-3f9e9eb438cf"]] = ["Chevron left", "s-Path_17"]; 

	widgets.descriptionMap[["s-Input_15", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_123", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_123", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_113", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_113", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Subtraction_4", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_4", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_147", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_147", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Menu", "s-Path_147"]; 

	widgets.descriptionMap[["s-Button_3", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Filled button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Image_4", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Hearth", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_5", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Hearth filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Path_7", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Menu", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_14", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Home", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Favorites", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Person", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_17", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "1582feba-1257-4ccf-858d-e7bb8ae200f9"]] = ["Clock", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_35", "16fe3630-3d1f-4192-8865-804180ae3e3c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_35", "16fe3630-3d1f-4192-8865-804180ae3e3c"]] = ["Persons", "s-Path_35"]; 

	widgets.descriptionMap[["s-Path_6", "16fe3630-3d1f-4192-8865-804180ae3e3c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "16fe3630-3d1f-4192-8865-804180ae3e3c"]] = ["Bed", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_1", "16fe3630-3d1f-4192-8865-804180ae3e3c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "16fe3630-3d1f-4192-8865-804180ae3e3c"]] = ["Chevron left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Input_15", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_123", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_123", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_113", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_113", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Subtraction_4", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_4", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_147", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_147", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Menu", "s-Path_147"]; 

	widgets.descriptionMap[["s-Path_33", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_33", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_33"]; 

	widgets.descriptionMap[["s-Path_1", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_131", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_131", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star half", "s-Path_131"]; 

	widgets.descriptionMap[["s-Path_29", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_29", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_29"]; 

	widgets.descriptionMap[["s-Path_30", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_30", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_30"]; 

	widgets.descriptionMap[["s-Path_31", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_31", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_31"]; 

	widgets.descriptionMap[["s-Path_32", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_32", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_32"]; 

	widgets.descriptionMap[["s-Path_34", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_34", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star half", "s-Path_34"]; 

	widgets.descriptionMap[["s-Image", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Button_1", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_9", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_10", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_12", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star half", "s-Path_13"]; 

	widgets.descriptionMap[["s-Image_10", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_10", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Image", "s-Image_10"]; 

	widgets.descriptionMap[["s-Button_6", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Filled button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Path_35", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_35", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_35"]; 

	widgets.descriptionMap[["s-Path_36", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_36", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_36"]; 

	widgets.descriptionMap[["s-Path_37", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_37", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_37"]; 

	widgets.descriptionMap[["s-Path_38", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_38", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_38"]; 

	widgets.descriptionMap[["s-Path_39", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_39", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star half", "s-Path_39"]; 

	widgets.descriptionMap[["s-Image_1", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Button_2", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Path_5", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_19", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_20", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_21", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_21"]; 

	widgets.descriptionMap[["s-Path_22", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star half", "s-Path_22"]; 

	widgets.descriptionMap[["s-Image_2", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Button_7", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Filled button", "s-Button_7"]; 

	widgets.descriptionMap[["s-Path_23", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_23", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_23"]; 

	widgets.descriptionMap[["s-Path_24", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_24", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_24"]; 

	widgets.descriptionMap[["s-Path_25", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_25"]; 

	widgets.descriptionMap[["s-Path_26", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_26", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star", "s-Path_26"]; 

	widgets.descriptionMap[["s-Path_27", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_27", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Star half", "s-Path_27"]; 

	widgets.descriptionMap[["s-Path_6", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Menu", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Home", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Favorites", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_14", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Person", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "4d58454c-206b-4647-867d-530dfe8edc9c"]] = ["Clock", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_33", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_33", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_33"]; 

	widgets.descriptionMap[["s-Path_1", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_131", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_131", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star half", "s-Path_131"]; 

	widgets.descriptionMap[["s-Path_6", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Menu", "s-Path_6"]; 

	widgets.descriptionMap[["s-Image", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Button_1", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_9", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_10", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_12", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star half", "s-Path_13"]; 

	widgets.descriptionMap[["s-Image_3", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Button_3", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Filled button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Path_7", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_14", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star half", "s-Path_16"]; 

	widgets.descriptionMap[["s-Image_4", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Image", "s-Image_4"]; 

	widgets.descriptionMap[["s-Button_4", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Filled button", "s-Button_4"]; 

	widgets.descriptionMap[["s-Path_17", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_18", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_28", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_28", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_28"]; 

	widgets.descriptionMap[["s-Path_35", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_35", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_35"]; 

	widgets.descriptionMap[["s-Path_36", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_36", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star half", "s-Path_36"]; 

	widgets.descriptionMap[["s-Image_1", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Button_2", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Path_5", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_19", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_20", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_21", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star", "s-Path_21"]; 

	widgets.descriptionMap[["s-Path_22", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "22eef7c5-9d3c-401a-a013-db6e81ee1cc4"]] = ["Star half", "s-Path_22"]; 

	widgets.descriptionMap[["s-Image", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Button_1", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_1", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ["Person circle", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ["Arrow left", "s-Path_2"]; 

	widgets.descriptionMap[["s-Image_2", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "cbada341-247e-4b9e-a6f2-0183df91ba54"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Input_15", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_123", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_123", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_113", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_113", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Subtraction_4", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_4", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_147", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_147", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Menu", "s-Path_147"]; 

	widgets.descriptionMap[["s-Path_14", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Download", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_40", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_40", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Question mark", "s-Path_40"]; 

	widgets.descriptionMap[["s-Path_25", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Envelope", "s-Path_25"]; 

	widgets.descriptionMap[["s-Path_1", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Menu", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Home", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Favorites", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Person", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "45d104d9-bb08-4280-959b-e3e7d8ed1a7b"]] = ["Clock", "s-Path_5"]; 

	